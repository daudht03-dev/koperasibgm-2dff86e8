
# Panduan Setup Google Apps Script untuk Export ke Google Sheets

## Langkah 1: Buat Google Spreadsheet
1. Buka Google Sheets (sheets.google.com)
2. Buat spreadsheet baru
3. Salin URL spreadsheet, ambil ID dari URL
   - Contoh URL: `https://docs.google.com/spreadsheets/d/1ABC123DEF456/edit`
   - ID: `1ABC123DEF456`

## Langkah 2: Buat Google Apps Script
1. Buka Google Apps Script (script.google.com)
2. Klik "New project"
3. Hapus code default, copy-paste code dari file `google-apps-script/Code.gs`
4. Ganti `YOUR_SPREADSHEET_ID_HERE` dengan ID spreadsheet Anda
5. Simpan project (Ctrl+S) dan beri nama

## Langkah 3: Deploy sebagai Web App
1. Klik "Deploy" > "New deployment"
2. Pilih type: "Web app"
3. Description: "Data Panen Export API"
4. Execute as: "Me"
5. Who has access: "Anyone" (atau "Anyone with Google account" untuk lebih aman)
6. Klik "Deploy"
7. Salin "Web app URL" yang diberikan

## Langkah 4: Update React App
1. Buka file `src/utils/googleSheetsUtils.ts`
2. Ganti `YOUR_SCRIPT_ID` dengan URL Web App yang didapat dari langkah 3
3. Contoh:
   ```typescript
   const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbx.../exec';
   ```

## Langkah 5: Set Permissions (Otorisasi)
1. Kembali ke Apps Script
2. Klik "Run" pada function `doPost` atau `doGet`
3. Authorize access ketika diminta
4. Review permissions dan klik "Allow"

## Langkah 6: Test Export
1. Buka aplikasi React Anda
2. Generate data panen
3. Klik tombol "Export ke Google Sheets"
4. Cek Google Spreadsheet untuk melihat hasilnya

## Troubleshooting

### Error "Script function not found"
- Pastikan nama function di Apps Script adalah `doPost`
- Pastikan project sudah disimpan

### Error "Authorization required"
- Jalankan function manual di Apps Script editor untuk authorize
- Pastikan Google account memiliki akses ke spreadsheet

### Data tidak muncul di spreadsheet
- Cek ID spreadsheet sudah benar
- Pastikan spreadsheet tidak dalam mode "Protected"
- Cek console browser untuk error messages

### CORS Error
- Ini normal untuk Apps Script dengan mode 'no-cors'
- Apps Script tetap akan menerima data meskipun ada CORS error di browser

## Format Data yang Dikirim
```json
{
  "data": [
    ["NAMA PETANI", "RATA-RATA", "07/07/2025", "08/07/2025", "...", "TOTAL", "TGL AMBIL"],
    ["Sutardi", "11.2 kg", "11.2 kg", "11.4 kg", "...", "65.8 kg", "09/06/2025"]
  ],
  "sheetName": "Data Panen Gula Serbuk",
  "timestamp": "2025-07-01T10:30:00.000Z"
}
```

## Security Notes
- Untuk production, gunakan "Anyone with Google account" instead of "Anyone"
- Pertimbangkan validasi data di Apps Script
- Monitor usage melalui Apps Script dashboard
