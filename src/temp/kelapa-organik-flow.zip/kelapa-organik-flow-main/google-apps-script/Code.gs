
// Google Apps Script untuk menerima data dari React dan menulis ke Google Sheets

function doPost(e) {
  try {
    // Parse data dari request
    const data = JSON.parse(e.parameter.data);
    const sheetData = data.data; // 2D array
    const sheetName = data.sheetName;
    const timestamp = data.timestamp;
    
    // Buka spreadsheet (ganti dengan ID spreadsheet Anda)
    const SPREADSHEET_ID = 'YOUR_SPREADSHEET_ID_HERE';
    const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
    
    // Cek apakah sheet sudah ada, jika tidak buat baru
    let sheet = spreadsheet.getSheetByName(sheetName);
    if (!sheet) {
      sheet = spreadsheet.insertSheet(sheetName);
    }
    
    // Clear existing data
    sheet.clear();
    
    // Tulis data ke sheet
    if (sheetData.length > 0) {
      const range = sheet.getRange(1, 1, sheetData.length, sheetData[0].length);
      range.setValues(sheetData);
      
      // Format header row
      const headerRange = sheet.getRange(1, 1, 1, sheetData[0].length);
      headerRange.setBackground('#4CAF50');
      headerRange.setFontColor('white');
      headerRange.setFontWeight('bold');
      headerRange.setHorizontalAlignment('center');
      
      // Format numeric columns to prevent date interpretation
      if (sheetData.length > 1 && sheetData[0].length >= 3) {
        // Format columns C to K (3 to 11) as numbers with 0.0# pattern
        const numericRange = sheet.getRange(2, 3, sheetData.length - 1, Math.min(9, sheetData[0].length - 2));
        numericRange.setNumberFormat('0.0#');
      }
      
      // Auto resize columns
      sheet.autoResizeColumns(1, sheetData[0].length);
      
      // Add timestamp
      sheet.getRange(sheetData.length + 3, 1).setValue('Data diupdate pada:');
      sheet.getRange(sheetData.length + 3, 2).setValue(new Date(timestamp));
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({success: true, message: 'Data berhasil disimpan'}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({success: false, error: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput('Google Apps Script Web App is running!')
    .setMimeType(ContentService.MimeType.TEXT);
}
