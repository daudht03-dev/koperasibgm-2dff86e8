-- Create pengovenan table
CREATE TABLE public.pengovenan (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    nomor_lot TEXT NOT NULL,
    tanggal_pengovenan DATE NOT NULL,
    tanggal_bahan_baku DATE NOT NULL,
    batch_number INTEGER NOT NULL,
    kode_petani TEXT NOT NULL,
    nama_petani TEXT NOT NULL,
    jumlah_bahan_baku DECIMAL(10,2) NOT NULL DEFAULT 0,
    susut DECIMAL(10,2) NOT NULL DEFAULT 0,
    qc_off DECIMAL(10,2) NOT NULL DEFAULT 0,
    setelah_kering DECIMAL(10,2) NOT NULL DEFAULT 0,
    jenis_gula TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.pengovenan ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (adjust as needed based on your security requirements)
CREATE POLICY "Allow public read access to pengovenan" 
ON public.pengovenan 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert access to pengovenan" 
ON public.pengovenan 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update access to pengovenan" 
ON public.pengovenan 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete access to pengovenan" 
ON public.pengovenan 
FOR DELETE 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_pengovenan_updated_at
    BEFORE UPDATE ON public.pengovenan
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_pengovenan_tanggal_pengovenan ON public.pengovenan(tanggal_pengovenan);
CREATE INDEX idx_pengovenan_nomor_lot ON public.pengovenan(nomor_lot);
CREATE INDEX idx_pengovenan_kode_petani ON public.pengovenan(kode_petani);