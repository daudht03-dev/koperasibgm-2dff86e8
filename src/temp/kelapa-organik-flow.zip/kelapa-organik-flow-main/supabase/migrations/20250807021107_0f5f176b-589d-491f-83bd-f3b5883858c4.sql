-- Enable real-time updates for data_panen table
ALTER TABLE public.data_panen REPLICA IDENTITY FULL;
ALTER publication supabase_realtime ADD TABLE public.data_panen;

-- Enable real-time updates for catatan_penjualan table  
ALTER TABLE public.catatan_penjualan REPLICA IDENTITY FULL;
ALTER publication supabase_realtime ADD TABLE public.catatan_penjualan;