/*
  # Create Pengovenan System

  1. New Tables
    - `pengovenan`
      - `id` (uuid, primary key)
      - `nomor_lot` (text, auto-generated)
      - `tanggal_pengovenan` (date)
      - `tanggal_bahan_baku` (date)
      - `batch_number` (integer)
      - `kode_petani` (text)
      - `nama_petani` (text)
      - `jumlah_bahan_baku` (numeric)
      - `susut` (numeric)
      - `qc_off` (numeric)
      - `setelah_kering` (numeric)
      - `jenis_gula` (text, default 'Gula Serbuk')
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `pengovenan` table
    - Add policy for authenticated users to manage data
    - Add policy for public read access (for Excel integration)
*/

CREATE TABLE IF NOT EXISTS pengovenan (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nomor_lot text NOT NULL,
  tanggal_pengovenan date NOT NULL,
  tanggal_bahan_baku date NOT NULL,
  batch_number integer NOT NULL,
  kode_petani text NOT NULL,
  nama_petani text NOT NULL,
  jumlah_bahan_baku numeric(10,2) NOT NULL,
  susut numeric(10,2) NOT NULL,
  qc_off numeric(10,2) NOT NULL,
  setelah_kering numeric(10,2) NOT NULL,
  jenis_gula text DEFAULT 'Gula Serbuk',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE pengovenan ENABLE ROW LEVEL SECURITY;

-- Policy for authenticated users (full access)
CREATE POLICY "Authenticated users can manage pengovenan"
  ON pengovenan
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policy for public read access (for Excel integration)
CREATE POLICY "Public can read pengovenan"
  ON pengovenan
  FOR SELECT
  TO anon
  USING (true);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_pengovenan_tanggal_pengovenan ON pengovenan(tanggal_pengovenan);
CREATE INDEX IF NOT EXISTS idx_pengovenan_tanggal_bahan_baku ON pengovenan(tanggal_bahan_baku);
CREATE INDEX IF NOT EXISTS idx_pengovenan_batch_number ON pengovenan(batch_number);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to automatically update updated_at
CREATE TRIGGER update_pengovenan_updated_at 
    BEFORE UPDATE ON pengovenan 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();