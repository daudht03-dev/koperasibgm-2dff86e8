-- Update RLS policies to allow public access for management application
-- Since this is an internal management system, we'll allow public access

-- Drop the current restrictive policies
DROP POLICY IF EXISTS "Authenticated users can view petani data" ON public.data_petani;
DROP POLICY IF EXISTS "Authenticated users can insert petani data" ON public.data_petani;
DROP POLICY IF EXISTS "Authenticated users can update petani data" ON public.data_petani;
DROP POLICY IF EXISTS "Authenticated users can delete petani data" ON public.data_petani;

DROP POLICY IF EXISTS "Authenticated users can view pengepul data" ON public.data_pengepul;
DROP POLICY IF EXISTS "Authenticated users can insert pengepul data" ON public.data_pengepul;
DROP POLICY IF EXISTS "Authenticated users can update pengepul data" ON public.data_pengepul;
DROP POLICY IF EXISTS "Authenticated users can delete pengepul data" ON public.data_pengepul;

-- Create new public access policies for data_petani
CREATE POLICY "Allow public read access to data_petani" 
ON public.data_petani 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert access to data_petani" 
ON public.data_petani 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update access to data_petani" 
ON public.data_petani 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete access to data_petani" 
ON public.data_petani 
FOR DELETE 
USING (true);

-- Create new public access policies for data_pengepul
CREATE POLICY "Allow public read access to data_pengepul" 
ON public.data_pengepul 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert access to data_pengepul" 
ON public.data_pengepul 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update access to data_pengepul" 
ON public.data_pengepul 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete access to data_pengepul" 
ON public.data_pengepul 
FOR DELETE 
USING (true);