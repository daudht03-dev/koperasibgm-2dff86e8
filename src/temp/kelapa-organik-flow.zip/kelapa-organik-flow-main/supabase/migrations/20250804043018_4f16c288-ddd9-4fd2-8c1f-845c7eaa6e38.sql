-- Create data_petani table
CREATE TABLE public.data_petani (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    kode_petani TEXT NOT NULL UNIQUE,
    nama_petani TEXT NOT NULL,
    alamat TEXT NOT NULL,
    nomor_telepon TEXT,
    rata_rata_panen DECIMAL(10,2) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create data_pengepul table
CREATE TABLE public.data_pengepul (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    kode_pengepul TEXT NOT NULL UNIQUE,
    nama_pengepul TEXT NOT NULL,
    alamat TEXT NOT NULL,
    nomor_telepon TEXT,
    petani_kodes TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create generate_panen table
CREATE TABLE public.generate_panen (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    kode_petani TEXT NOT NULL,
    nama_petani TEXT NOT NULL,
    tanggal_panen DATE NOT NULL,
    rata_rata DECIMAL(10,2) NOT NULL DEFAULT 0,
    jumlah_panen TEXT NOT NULL,
    jenis_panen TEXT NOT NULL DEFAULT 'serbuk',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    
    -- Foreign key constraint to data_petani
    CONSTRAINT fk_generate_panen_petani 
        FOREIGN KEY (kode_petani) 
        REFERENCES public.data_petani(kode_petani) 
        ON DELETE CASCADE
);

-- Enable Row Level Security for all tables
ALTER TABLE public.data_petani ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.data_pengepul ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generate_panen ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (adjust as needed)
-- Data Petani policies
CREATE POLICY "Allow public read access to data_petani" 
ON public.data_petani FOR SELECT USING (true);

CREATE POLICY "Allow public insert access to data_petani" 
ON public.data_petani FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public update access to data_petani" 
ON public.data_petani FOR UPDATE USING (true);

CREATE POLICY "Allow public delete access to data_petani" 
ON public.data_petani FOR DELETE USING (true);

-- Data Pengepul policies
CREATE POLICY "Allow public read access to data_pengepul" 
ON public.data_pengepul FOR SELECT USING (true);

CREATE POLICY "Allow public insert access to data_pengepul" 
ON public.data_pengepul FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public update access to data_pengepul" 
ON public.data_pengepul FOR UPDATE USING (true);

CREATE POLICY "Allow public delete access to data_pengepul" 
ON public.data_pengepul FOR DELETE USING (true);

-- Generate Panen policies
CREATE POLICY "Allow public read access to generate_panen" 
ON public.generate_panen FOR SELECT USING (true);

CREATE POLICY "Allow public insert access to generate_panen" 
ON public.generate_panen FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public update access to generate_panen" 
ON public.generate_panen FOR UPDATE USING (true);

CREATE POLICY "Allow public delete access to generate_panen" 
ON public.generate_panen FOR DELETE USING (true);

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_data_petani_updated_at
    BEFORE UPDATE ON public.data_petani
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_data_pengepul_updated_at
    BEFORE UPDATE ON public.data_pengepul
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_generate_panen_updated_at
    BEFORE UPDATE ON public.generate_panen
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_data_petani_kode ON public.data_petani(kode_petani);
CREATE INDEX idx_data_pengepul_kode ON public.data_pengepul(kode_pengepul);
CREATE INDEX idx_generate_panen_kode_petani ON public.generate_panen(kode_petani);
CREATE INDEX idx_generate_panen_tanggal ON public.generate_panen(tanggal_panen);