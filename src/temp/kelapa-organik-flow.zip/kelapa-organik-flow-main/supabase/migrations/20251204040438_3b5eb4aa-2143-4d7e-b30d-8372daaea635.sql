-- Create enum for jenis panen/type
CREATE TYPE public.jenis_type AS ENUM ('serbuk', 'cetak');

-- Create enum for payment method
CREATE TYPE public.metode_pembayaran AS ENUM ('tunai', 'transfer', 'tempo');

-- Create enum for payment status
CREATE TYPE public.status_pembayaran AS ENUM ('lunas', 'belum_lunas');

-- =====================
-- PETANI TABLE
-- =====================
CREATE TABLE public.petani (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kode TEXT NOT NULL UNIQUE,
  nama TEXT NOT NULL,
  alamat TEXT NOT NULL,
  telepon TEXT NOT NULL,
  rata_rata_panen NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.petani ENABLE ROW LEVEL SECURITY;

-- Public read access for petani (master data)
CREATE POLICY "Anyone can view petani" ON public.petani
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert petani" ON public.petani
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update petani" ON public.petani
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete petani" ON public.petani
  FOR DELETE USING (true);

-- =====================
-- PENGEPUL TABLE
-- =====================
CREATE TABLE public.pengepul (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kode TEXT NOT NULL UNIQUE,
  nama TEXT NOT NULL,
  alamat TEXT NOT NULL,
  telepon TEXT NOT NULL,
  email TEXT,
  bank_account TEXT,
  harga_per_kg NUMERIC NOT NULL DEFAULT 0,
  petani_terkait TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.pengepul ENABLE ROW LEVEL SECURITY;

-- Public read access for pengepul (master data)
CREATE POLICY "Anyone can view pengepul" ON public.pengepul
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert pengepul" ON public.pengepul
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update pengepul" ON public.pengepul
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete pengepul" ON public.pengepul
  FOR DELETE USING (true);

-- =====================
-- DATA PANEN TABLE
-- =====================
CREATE TABLE public.data_panen (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  petani_id UUID REFERENCES public.petani(id) ON DELETE CASCADE,
  kode_petani TEXT NOT NULL,
  nama_petani TEXT NOT NULL,
  rata_rata_panen NUMERIC DEFAULT 0,
  tanggal_mulai DATE NOT NULL,
  hari1 NUMERIC DEFAULT 0,
  hari2 NUMERIC DEFAULT 0,
  hari3 NUMERIC DEFAULT 0,
  hari4 NUMERIC DEFAULT 0,
  hari5 NUMERIC DEFAULT 0,
  hari6 NUMERIC DEFAULT 0,
  hari7 NUMERIC DEFAULT 0,
  total_panen NUMERIC DEFAULT 0,
  tanggal_pengambilan DATE,
  hari_libur INTEGER[] DEFAULT '{}',
  type public.jenis_type NOT NULL DEFAULT 'serbuk',
  week_number INTEGER,
  dynamic_data JSONB DEFAULT '{}',
  dynamic_hari_libur JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.data_panen ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view data_panen" ON public.data_panen
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert data_panen" ON public.data_panen
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update data_panen" ON public.data_panen
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete data_panen" ON public.data_panen
  FOR DELETE USING (true);

-- =====================
-- PENJUALAN TABLE
-- =====================
CREATE TABLE public.penjualan (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  petani_id UUID REFERENCES public.petani(id) ON DELETE SET NULL,
  pengepul_id UUID REFERENCES public.pengepul(id) ON DELETE SET NULL,
  kode_petani TEXT NOT NULL,
  nama_petani TEXT NOT NULL,
  nama_pengepul TEXT NOT NULL,
  jumlah_jual NUMERIC NOT NULL DEFAULT 0,
  harga_per_kg NUMERIC NOT NULL DEFAULT 0,
  total_harga NUMERIC NOT NULL DEFAULT 0,
  tanggal_jual DATE NOT NULL,
  type public.jenis_type NOT NULL DEFAULT 'serbuk',
  metode_pembayaran public.metode_pembayaran NOT NULL DEFAULT 'tunai',
  status_pembayaran public.status_pembayaran NOT NULL DEFAULT 'belum_lunas',
  tanggal_jatuh_tempo DATE,
  keterangan TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.penjualan ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view penjualan" ON public.penjualan
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert penjualan" ON public.penjualan
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update penjualan" ON public.penjualan
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete penjualan" ON public.penjualan
  FOR DELETE USING (true);

-- =====================
-- INDEXES
-- =====================
CREATE INDEX idx_petani_kode ON public.petani(kode);
CREATE INDEX idx_pengepul_kode ON public.pengepul(kode);
CREATE INDEX idx_data_panen_petani_id ON public.data_panen(petani_id);
CREATE INDEX idx_data_panen_tanggal ON public.data_panen(tanggal_mulai);
CREATE INDEX idx_penjualan_tanggal ON public.penjualan(tanggal_jual);
CREATE INDEX idx_penjualan_petani ON public.penjualan(petani_id);
CREATE INDEX idx_penjualan_pengepul ON public.penjualan(pengepul_id);

-- Enable realtime for all tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.petani;
ALTER PUBLICATION supabase_realtime ADD TABLE public.pengepul;
ALTER PUBLICATION supabase_realtime ADD TABLE public.data_panen;
ALTER PUBLICATION supabase_realtime ADD TABLE public.penjualan;