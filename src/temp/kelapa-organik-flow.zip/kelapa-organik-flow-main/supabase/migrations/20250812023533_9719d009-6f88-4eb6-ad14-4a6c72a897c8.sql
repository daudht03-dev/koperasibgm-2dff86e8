-- Remove existing public policies for data_petani
DROP POLICY IF EXISTS "Allow public delete access to data_petani" ON public.data_petani;
DROP POLICY IF EXISTS "Allow public insert access to data_petani" ON public.data_petani;
DROP POLICY IF EXISTS "Allow public read access to data_petani" ON public.data_petani;
DROP POLICY IF EXISTS "Allow public update access to data_petani" ON public.data_petani;

-- Remove existing public policies for data_pengepul
DROP POLICY IF EXISTS "Allow public delete access to data_pengepul" ON public.data_pengepul;
DROP POLICY IF EXISTS "Allow public insert access to data_pengepul" ON public.data_pengepul;
DROP POLICY IF EXISTS "Allow public read access to data_pengepul" ON public.data_pengepul;
DROP POLICY IF EXISTS "Allow public update access to data_pengepul" ON public.data_pengepul;

-- Create secure policies for data_petani (authenticated users only)
CREATE POLICY "Authenticated users can view petani data"
ON public.data_petani
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can insert petani data"
ON public.data_petani
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update petani data"
ON public.data_petani
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete petani data"
ON public.data_petani
FOR DELETE
TO authenticated
USING (true);

-- Create secure policies for data_pengepul (authenticated users only)
CREATE POLICY "Authenticated users can view pengepul data"
ON public.data_pengepul
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can insert pengepul data"
ON public.data_pengepul
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update pengepul data"
ON public.data_pengepul
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete pengepul data"
ON public.data_pengepul
FOR DELETE
TO authenticated
USING (true);