-- Create sales data table for storing penjualan data
CREATE TABLE public.data_penjualan (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  petani_id UUID NOT NULL,
  pengepul_id UUID NOT NULL,
  kode_petani TEXT NOT NULL,
  nama_petani TEXT NOT NULL,
  nama_pengepul TEXT NOT NULL,
  jumlah_jual NUMERIC NOT NULL DEFAULT 0,
  harga_per_kg NUMERIC NOT NULL DEFAULT 0,
  total_harga NUMERIC NOT NULL DEFAULT 0,
  tanggal_jual DATE NOT NULL,
  type TEXT NOT NULL DEFAULT 'serbuk',
  metode_pembayaran TEXT NOT NULL DEFAULT 'tunai',
  status_pembayaran TEXT NOT NULL DEFAULT 'lunas',
  tanggal_jatuh_tempo DATE,
  keterangan TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.data_penjualan ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (matching existing tables)
CREATE POLICY "Allow public read access to data_penjualan" 
ON public.data_penjualan 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert access to data_penjualan" 
ON public.data_penjualan 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update access to data_penjualan" 
ON public.data_penjualan 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete access to data_penjualan" 
ON public.data_penjualan 
FOR DELETE 
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_data_penjualan_updated_at
BEFORE UPDATE ON public.data_penjualan
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.data_penjualan;