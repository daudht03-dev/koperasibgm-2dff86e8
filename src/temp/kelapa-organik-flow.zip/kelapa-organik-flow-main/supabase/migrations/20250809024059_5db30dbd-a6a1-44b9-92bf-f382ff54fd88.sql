-- Create bahan baku data table
CREATE TABLE public.data_bahan_baku (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  petani_id UUID NOT NULL,
  pengepul_id UUID NOT NULL,
  kode_petani TEXT NOT NULL,
  nama_petani TEXT NOT NULL,
  nama_pengepul TEXT NOT NULL,
  jumlah_masuk NUMERIC NOT NULL DEFAULT 0,
  tanggal_masuk DATE NOT NULL,
  type TEXT NOT NULL DEFAULT 'serbuk',
  no_lot TEXT NOT NULL,
  total_per_pengepul NUMERIC NOT NULL DEFAULT 0,
  total_keseluruhan NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.data_bahan_baku ENABLE ROW LEVEL SECURITY;

-- Create policies for public access
CREATE POLICY "Allow public read access to data_bahan_baku" 
ON public.data_bahan_baku 
FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert access to data_bahan_baku" 
ON public.data_bahan_baku 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update access to data_bahan_baku" 
ON public.data_bahan_baku 
FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete access to data_bahan_baku" 
ON public.data_bahan_baku 
FOR DELETE 
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_data_bahan_baku_updated_at
BEFORE UPDATE ON public.data_bahan_baku
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.data_bahan_baku;