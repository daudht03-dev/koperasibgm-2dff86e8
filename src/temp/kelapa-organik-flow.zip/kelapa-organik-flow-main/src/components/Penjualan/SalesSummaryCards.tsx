
import React from 'react';
import { FileText, ShoppingCart } from 'lucide-react';
import { Penjualan } from '../../types';

interface SalesSummaryCardsProps {
  salesList: Penjualan[];
  filteredSales: Penjualan[];
}

const SalesSummaryCards: React.FC<SalesSummaryCardsProps> = ({ salesList, filteredSales }) => {
  if (salesList.length === 0) return null;

  const totalTransactions = filteredSales.length;
  const totalValue = filteredSales.reduce((sum, sale) => sum + sale.totalHarga, 0);
  const totalQuantity = filteredSales.reduce((sum, sale) => sum + sale.jumlahJual, 0);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center">
          <div className="p-3 bg-blue-100 rounded-lg">
            <FileText className="w-6 h-6 text-blue-600" />
          </div>
          <div className="ml-4">
            <p className="text-gray-600 text-sm">Total Transaksi</p>
            <p className="text-2xl font-bold text-gray-800">{totalTransactions}</p>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center">
          <div className="p-3 bg-green-100 rounded-lg">
            <ShoppingCart className="w-6 h-6 text-green-600" />
          </div>
          <div className="ml-4">
            <p className="text-gray-600 text-sm">Total Kuantitas</p>
            <p className="text-2xl font-bold text-gray-800">{totalQuantity.toFixed(1)} kg</p>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center">
          <div className="p-3 bg-yellow-100 rounded-lg">
            <FileText className="w-6 h-6 text-yellow-600" />
          </div>
          <div className="ml-4">
            <p className="text-gray-600 text-sm">Total Nilai</p>
            <p className="text-2xl font-bold text-gray-800">Rp {totalValue.toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesSummaryCards;
