
import React from 'react';
import { Search } from 'lucide-react';

interface SalesSearchBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
}

const SalesSearchBar: React.FC<SalesSearchBarProps> = ({ searchTerm, onSearchChange }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Cari berdasarkan nama petani, pengepul, atau kode petani..."
          className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
    </div>
  );
};

export default SalesSearchBar;
