
import React, { useState } from 'react';
import { ShoppingCart, FileText } from 'lucide-react';
import { Penjualan } from '../../types';
import { useDataContext } from '../../contexts/DataContext';
import { usePenjualan } from '../../hooks/usePenjualan';
import SalesSummaryCards from './SalesSummaryCards';
import SalesSearchBar from './SalesSearchBar';
import SalesTable from './SalesTable';
import EmptySalesState from './EmptySalesState';

const DataPenjualan: React.FC = () => {
  const { penjualanData } = useDataContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortColumn, setSortColumn] = useState<keyof Penjualan | null>('tanggalJual');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const {
    saveSales,
    generateSalesFromHarvest,
    deleteSales,
    groupSalesByPengepul
  } = usePenjualan();

  // Use real-time data instead of hook state
  const salesList = penjualanData;

  const handleSort = (column: keyof Penjualan) => {
    if (sortColumn === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortOrder('asc');
    }
  };

  const sortedSales = React.useMemo(() => {
    if (!sortColumn) return salesList;

    return [...salesList].sort((a, b) => {
      const aValue = a[sortColumn];
      const bValue = b[sortColumn];

      if (aValue === undefined || bValue === undefined) {
        return 0;
      }

      let comparison = 0;
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        comparison = aValue - bValue;
      } else if (typeof aValue === 'string' && typeof bValue === 'string') {
        comparison = aValue.localeCompare(bValue);
      } else {
        comparison = String(aValue).localeCompare(String(bValue));
      }

      return sortOrder === 'asc' ? comparison : -comparison;
    });
  }, [salesList, sortColumn, sortOrder]);

  const filteredSales = sortedSales.filter(sales =>
    sales.namaPetani.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sales.namaPengepul.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sales.kodePetani.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleGenerateSalesData = async () => {
    try {
      const salesData = generateSalesFromHarvest();
      await saveSales(salesData);
      alert(`Data penjualan berhasil di-generate! ${salesData.length} record dibuat.`);
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Terjadi kesalahan saat generate data');
    }
  };

  const groupedSales = groupSalesByPengepul(filteredSales);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-green-100 rounded-lg">
            <ShoppingCart className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Data Penjualan</h1>
            <p className="text-gray-600">Kelola data penjualan gula kelapa berdasarkan hasil panen</p>
          </div>
        </div>
        <button
          onClick={handleGenerateSalesData}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
        >
          <FileText className="w-4 h-4" />
          <span>Generate Data Penjualan</span>
        </button>
      </div>

      <SalesSummaryCards salesList={salesList} filteredSales={filteredSales} />

      <SalesSearchBar searchTerm={searchTerm} onSearchChange={setSearchTerm} />

      {Object.keys(groupedSales).length > 0 ? (
        <SalesTable 
          groupedSales={groupedSales} 
          onSort={handleSort} 
          onDelete={deleteSales} 
        />
      ) : (
        <EmptySalesState />
      )}
    </div>
  );
};

export default DataPenjualan;
