
import React from 'react';
import { Penjualan } from '../../types';

interface SalesTableProps {
  groupedSales: Record<string, Penjualan[]>;
  onSort: (column: keyof Penjualan) => void;
  onDelete: (id: string) => void;
}

const SalesTable: React.FC<SalesTableProps> = ({ groupedSales, onSort, onDelete }) => {
  return (
    <div className="space-y-6">
      {Object.entries(groupedSales).map(([pengepulName, sales]) => {
        const pengepulTotal = sales.reduce((sum, sale) => sum + sale.totalHarga, 0);
        const pengepulQuantity = sales.reduce((sum, sale) => sum + sale.jumlahJual, 0);
        
        return (
          <div key={pengepulName} className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="bg-green-50 px-6 py-4 border-b border-green-200">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-semibold text-green-800">
                    Pengepul: {pengepulName}
                  </h3>
                  <p className="text-sm text-green-600">
                    {sales.length} transaksi | {pengepulQuantity.toFixed(1)} kg
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-green-800">
                    Rp {pengepulTotal.toLocaleString()}
                  </p>
                  <p className="text-sm text-green-600">Total Nilai</p>
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th 
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                      onClick={() => onSort('kodePetani')}
                    >
                      Kode Petani
                    </th>
                    <th 
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                      onClick={() => onSort('namaPetani')}
                    >
                      Nama Petani
                    </th>
                    <th 
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                      onClick={() => onSort('jumlahJual')}
                    >
                      Total Panen
                    </th>
                    <th 
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                      onClick={() => onSort('hargaPerKg')}
                    >
                      Harga/Kg
                    </th>
                    <th 
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                      onClick={() => onSort('totalHarga')}
                    >
                      Total Harga
                    </th>
                    <th 
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                      onClick={() => onSort('tanggalJual')}
                    >
                      Tanggal Jual
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Jenis
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Aksi
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {sales.map((sale) => (
                    <tr key={sale.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                          {sale.kodePetani}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {sale.namaPetani}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sale.jumlahJual.toFixed(1)} kg
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        Rp {sale.hargaPerKg.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                        Rp {sale.totalHarga.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(sale.tanggalJual).toLocaleDateString('id-ID')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          sale.type === 'serbuk' 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {sale.type === 'serbuk' ? 'Serbuk' : 'Cetak'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => onDelete(sale.id)}
                          className="text-red-600 hover:text-red-900 px-2 py-1 hover:bg-red-50 rounded transition-colors"
                        >
                          Hapus
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default SalesTable;
