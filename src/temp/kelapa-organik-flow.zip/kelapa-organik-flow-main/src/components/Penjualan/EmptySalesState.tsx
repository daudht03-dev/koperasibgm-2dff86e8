
import React from 'react';
import { ShoppingCart } from 'lucide-react';

const EmptySalesState: React.FC = () => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-12 text-center">
      <ShoppingCart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
      <h3 className="text-lg font-medium text-gray-900 mb-2">Belum Ada Data Penjualan</h3>
      <p className="text-gray-500 mb-6">
        Klik tombol "Generate Data Penjualan" untuk membuat data berdasarkan hasil panen dan pengepul terkait
      </p>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-left">
        <h4 className="font-semibold text-blue-800 mb-2">Langkah untuk Generate Data Penjualan:</h4>
        <ol className="text-sm text-blue-700 space-y-1">
          <li>1. Pastikan sudah ada data petani</li>
          <li>2. Tambahkan data pengepul dan pilih petani terkait</li>
          <li>3. Generate data panen terlebih dahulu</li>
          <li>4. Klik tombol "Generate Data Penjualan"</li>
        </ol>
      </div>
    </div>
  );
};

export default EmptySalesState;
