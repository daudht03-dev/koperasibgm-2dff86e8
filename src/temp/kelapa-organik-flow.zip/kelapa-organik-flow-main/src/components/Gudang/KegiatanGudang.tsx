
import KegiatanGudangUpdated from './KegiatanGudangUpdated';

const KegiatanGudang: React.FC = () => {
  return <KegiatanGudangUpdated />;
};

export default KegiatanGudang;
