import React, { useState } from 'react';
import { Package, Plus } from 'lucide-react';
import { StokGudang } from '../../types';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';

interface PackingFormProps {
  stokGudang: StokGudang[];
  onCreatePacking: (
    stokId: string,
    ukuranKemasan: number,
    jumlahKemasan: number,
    operator: string,
    keterangan?: string
  ) => void;
  onClose: () => void;
}

const PackingForm: React.FC<PackingFormProps> = ({
  stokGudang,
  onCreatePacking,
  onClose
}) => {
  const [formData, setFormData] = useState({
    stokId: '',
    ukuranKemasan: 10,
    jumlahKemasan: 1,
    operator: '',
    keterangan: ''
  });
  const [error, setError] = useState('');

  const availableStok = stokGudang.filter(s => s.stokSisa > 0 && s.status === 'tersedia');
  const selectedStok = stokGudang.find(s => s.id === formData.stokId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedStok) {
      setError('Pilih stok yang valid');
      return;
    }

    const totalBerat = formData.ukuranKemasan * formData.jumlahKemasan;
    if (totalBerat > selectedStok.stokSisa) {
      setError('Jumlah kemasan melebihi stok yang tersedia');
      return;
    }

    try {
      onCreatePacking(
        formData.stokId,
        formData.ukuranKemasan,
        formData.jumlahKemasan,
        formData.operator,
        formData.keterangan
      );
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Terjadi kesalahan');
    }
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="w-5 h-5" />
          Form Packing Barang
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Pilih Stok Gudang *
            </label>
            <select
              value={formData.stokId}
              onChange={(e) => setFormData({ ...formData, stokId: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              <option value="">Pilih Stok</option>
              {availableStok.map(stok => (
                <option key={stok.id} value={stok.id}>
                  {stok.kodeLot} - {stok.namaLot} (Tersedia: {stok.stokSisa} kg)
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ukuran Kemasan *
              </label>
              <select
                value={formData.ukuranKemasan}
                onChange={(e) => setFormData({ ...formData, ukuranKemasan: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value={10}>10 Kg</option>
                <option value={25}>25 Kg</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Jumlah Kemasan *
              </label>
              <input
                type="number"
                min="1"
                value={formData.jumlahKemasan}
                onChange={(e) => setFormData({ ...formData, jumlahKemasan: parseInt(e.target.value) || 1 })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Operator *
            </label>
            <input
              type="text"
              value={formData.operator}
              onChange={(e) => setFormData({ ...formData, operator: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Nama operator"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Keterangan
            </label>
            <textarea
              value={formData.keterangan}
              onChange={(e) => setFormData({ ...formData, keterangan: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Keterangan tambahan"
              rows={3}
            />
          </div>

          {selectedStok && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-2">Detail Packing:</h4>
              <div className="text-sm text-blue-800">
                <p>Total Berat: {formData.ukuranKemasan * formData.jumlahKemasan} kg</p>
                <p>Sisa Stok: {selectedStok.stokSisa - (formData.ukuranKemasan * formData.jumlahKemasan)} kg</p>
              </div>
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <Button type="submit" className="flex-1">
              <Plus className="w-4 h-4 mr-2" />
              Buat Packing
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Batal
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default PackingForm;