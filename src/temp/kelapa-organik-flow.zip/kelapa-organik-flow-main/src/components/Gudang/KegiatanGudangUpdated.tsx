import React, { useState, useEffect } from 'react';
import { Plus, Package, TrendingUp, TrendingDown, Warehouse, Search, ArrowRight, Box } from 'lucide-react';
import { useDataContext } from '../../contexts/DataContext';
import { useGudangPacking } from '../../hooks/useGudangPacking';
import PackingForm from './PackingForm';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';

const KegiatanGudangUpdated: React.FC = () => {
  const { pengovenanData } = useDataContext();
  const { stokGudang, packingList, addStokMasuk, createPacking, deletePacking } = useGudangPacking();
  const [showPackingForm, setShowPackingForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'stok' | 'packing'>('stok');
  const [searchTerm, setSearchTerm] = useState('');

  // Auto import from pengovenan on mount
  useEffect(() => {
    if (pengovenanData.length > 0) {
      pengovenanData.forEach(item => {
        const existingStok = stokGudang.find(s => s.lotPengovenan === item.nomor_lot);
        if (!existingStok && item.setelah_kering > 0) {
          addStokMasuk({
            lotId: item.id,
            lotPengovenan: item.nomor_lot,
            kodeLot: `GDG-${item.nomor_lot}`,
            namaLot: `${item.nama_petani} - ${item.jenis_gula}`,
            jumlahMasuk: item.setelah_kering,
            jumlahKeluar: 0,
            stokSisa: item.setelah_kering,
            tanggalMasukGudang: new Date().toISOString().split('T')[0],
            status: 'tersedia'
          });
        }
      });
    }
  }, [pengovenanData]);

  const totalStokMasuk = stokGudang.reduce((sum, stok) => sum + stok.jumlahMasuk, 0);
  const totalStokTerpacking = packingList.reduce((sum, pack) => sum + pack.totalBerat, 0);
  const totalStokSisa = stokGudang.reduce((sum, stok) => sum + stok.stokSisa, 0);

  const filteredStok = stokGudang.filter(stok => 
    stok.namaLot.toLowerCase().includes(searchTerm.toLowerCase()) ||
    stok.kodeLot.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredPacking = packingList.filter(pack => 
    pack.lotAsal.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pack.lotPacking.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-purple-100 rounded-lg">
            <Warehouse className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Kegiatan Gudang & Packing</h1>
            <p className="text-gray-600">Kelola stok gudang dan proses packing otomatis dari pengovenan</p>
          </div>
        </div>
        <Button
          onClick={() => setShowPackingForm(true)}
          className="bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Buat Packing
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Masuk</p>
                <p className="text-2xl font-bold text-green-600">{totalStokMasuk.toFixed(1)} kg</p>
                <p className="text-xs text-gray-500">Dari pengovenan</p>
              </div>
              <div className="p-3 bg-green-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Terpacking</p>
                <p className="text-2xl font-bold text-blue-600">{totalStokTerpacking.toFixed(1)} kg</p>
                <p className="text-xs text-gray-500">{packingList.length} kemasan</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-lg">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Stok Tersisa</p>
                <p className="text-2xl font-bold text-orange-600">{totalStokSisa.toFixed(1)} kg</p>
                <p className="text-xs text-gray-500">Belum dikemas</p>
              </div>
              <div className="p-3 bg-orange-100 rounded-lg">
                <Warehouse className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs and Search */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="flex space-x-2">
            <Button
              variant={activeTab === 'stok' ? 'default' : 'outline'}
              onClick={() => setActiveTab('stok')}
            >
              <Warehouse className="w-4 h-4 mr-2" />
              Stok Gudang ({stokGudang.length})
            </Button>
            <Button
              variant={activeTab === 'packing' ? 'default' : 'outline'}
              onClick={() => setActiveTab('packing')}
            >
              <Package className="w-4 h-4 mr-2" />
              Data Packing ({packingList.length})
            </Button>
          </div>
          
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Cari berdasarkan lot atau nama..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Stok Gudang Table */}
        {activeTab === 'stok' && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lot Pengovenan</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kode Gudang</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Produk</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Masuk (kg)</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sisa (kg)</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal Masuk</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredStok.map((stok, index) => (
                  <tr key={stok.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-900">{index + 1}</td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="text-purple-600">
                        {stok.lotPengovenan}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="secondary">
                        {stok.kodeLot}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{stok.namaLot}</td>
                    <td className="px-6 py-4 text-sm text-green-600 font-medium">+{stok.jumlahMasuk}</td>
                    <td className="px-6 py-4 text-sm text-blue-600 font-medium">{stok.stokSisa}</td>
                    <td className="px-6 py-4">
                      <Badge variant={stok.status === 'tersedia' ? 'default' : 'secondary'}>
                        {stok.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {new Date(stok.tanggalMasukGudang).toLocaleDateString('id-ID')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredStok.length === 0 && (
              <div className="text-center py-12">
                <Warehouse className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Belum ada data stok gudang</p>
              </div>
            )}
          </div>
        )}

        {/* Packing Table */}
        {activeTab === 'packing' && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lot Asal</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lot Packing</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kemasan</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Berat</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Operator</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredPacking.map((pack, index) => (
                  <tr key={pack.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-900">{index + 1}</td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="text-purple-600">
                        {pack.lotAsal}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="default">
                        {pack.lotPacking}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {pack.jumlahKemasan} × {pack.ukuranKemasan}kg
                    </td>
                    <td className="px-6 py-4 text-sm text-blue-600 font-medium">{pack.totalBerat} kg</td>
                    <td className="px-6 py-4 text-sm text-gray-900">{pack.operator}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {new Date(pack.tanggalPacking).toLocaleDateString('id-ID')}
                    </td>
                    <td className="px-6 py-4">
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => deletePacking(pack.id)}
                      >
                        Hapus
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredPacking.length === 0 && (
              <div className="text-center py-12">
                <Box className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Belum ada data packing</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Packing Form Modal */}
      {showPackingForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <PackingForm
              stokGudang={stokGudang.filter(s => s.stokSisa > 0 && s.status === 'tersedia')}
              onCreatePacking={createPacking}
              onClose={() => setShowPackingForm(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default KegiatanGudangUpdated;