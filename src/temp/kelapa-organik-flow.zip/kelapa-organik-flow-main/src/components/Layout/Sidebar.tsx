
import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Users, 
  Wheat, 
  ShoppingCart, 
  Package, 
  Flame, 
  Warehouse,
  FileText,
  Download,
  LogOut,
  Truck
} from 'lucide-react';

interface SidebarProps {
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onLogout }) => {
  const menuItems = [
    { path: '/dashboard', icon: Home, label: 'Dashboard' },
    { path: '/petani', icon: Users, label: 'Data Petani' },
    { path: '/panen', icon: Wheat, label: 'Generate Panen' },
    { path: '/pengepul', icon: Truck, label: 'Data Pengepul' },
    { path: '/penjualan', icon: ShoppingCart, label: 'Penjualan' },
    { path: '/bahan-baku', icon: Package, label: 'Bahan Baku' },
    { path: '/pengovenan', icon: Flame, label: 'Pengovenan' },
    { path: '/gudang', icon: Warehouse, label: 'Kegiatan Gudang' },
    { path: '/surat-jalan', icon: FileText, label: 'Surat Jalan' },
    { path: '/export', icon: Download, label: 'Excel Integration' },
  ];

  return (
    <div className="w-64 bg-white shadow-lg h-screen flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
            <Wheat className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-800">Kelapa Organik</h1>
            <p className="text-xs text-gray-500">Management System</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-green-100 text-green-700 border-r-4 border-green-600'
                  : 'text-gray-600 hover:bg-gray-100'
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            <span className="font-medium">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-gray-200">
        <button
          onClick={onLogout}
          className="w-full flex items-center space-x-3 px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
