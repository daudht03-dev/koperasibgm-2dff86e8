import React from 'react';
import { Flame, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '../ui/alert';
import { useDataContext } from '../../contexts/DataContext';
import { usePengovenan } from '../../hooks/usePengovenan';
import PengovenanGenerationForm from './PengovenanGenerationForm';
import BatchPengovenanTable from './BatchPengovenanTable';

const DataPengovenan: React.FC = () => {
  const { bahanBakuData } = useDataContext();
  const {
    pengovenanData,
    loading,
    formData,
    setFormData,
    availableDates,
    farmersForDate,
    dataPanenSerbuk,
    generatePengovenan,
    generateNextBatch,
    deletePengovenan,
    exportToCSV,
    loadPengovenanData
  } = usePengovenan(undefined, bahanBakuData);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-red-100 rounded-lg">
            <Flame className="w-6 h-6 text-red-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Pengovenan Gula Serbuk</h1>
            <p className="text-gray-600">Kelola proses pengovenan khusus untuk Gula Serbuk dengan penyimpanan lokal</p>
          </div>
        </div>
      </div>

      {/* Info Alert */}
      <Alert className="border-blue-200 bg-blue-50">
        <AlertTriangle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800">
          ℹ️ Menu Pengovenan ini khusus untuk memproses <strong>Gula Serbuk</strong> saja. 
          Data disimpan secara lokal dan dapat diekspor ke CSV.
        </AlertDescription>
      </Alert>

      {/* Generation Form */}
      <PengovenanGenerationForm
        formData={formData}
        setFormData={setFormData}
        availableDates={availableDates}
        farmersForDate={farmersForDate}
        onGenerate={generatePengovenan}
        onNextBatch={generateNextBatch}
        loading={loading}
        hasDataSerbuk={dataPanenSerbuk.length > 0}
      />

      {/* Batch Table */}
      <BatchPengovenanTable
        pengovenanData={pengovenanData}
        onDelete={deletePengovenan}
        onExport={exportToCSV}
        onRefresh={loadPengovenanData}
        loading={loading}
      />
    </div>
  );
};

export default DataPengovenan;