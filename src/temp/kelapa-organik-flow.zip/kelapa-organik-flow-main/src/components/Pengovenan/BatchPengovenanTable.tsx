import React from 'react';
import { Trash2, Download, Flame, RefreshCw } from 'lucide-react';
import { Button } from '../ui/button';
import { Alert, AlertDescription } from '../ui/alert';
import { PengovenanData } from '../../types/pengovenan';
import { formatNumber } from '../../utils/pengovenanCalculations';

interface BatchPengovenanTableProps {
  pengovenanData: PengovenanData[];
  onDelete: (id: string) => void;
  onExport: () => void;
  onRefresh: () => void;
  loading: boolean;
}

const BatchPengovenanTable: React.FC<BatchPengovenanTableProps> = ({ 
  pengovenanData, 
  onDelete, 
  onExport, 
  onRefresh,
  loading 
}) => {
  const handleDelete = (id: string, nomorLot: string) => {
    if (confirm(`Apakah Anda yakin ingin menghapus batch ${nomorLot}?`)) {
      onDelete(id);
    }
  };

  if (pengovenanData.length === 0 && !loading) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="text-center">
          <Flame className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Belum Ada Batch Pengovenan</h3>
          <Alert className="border-yellow-200 bg-yellow-50 mt-4">
            <AlertDescription className="text-yellow-800">
              ⚠️ Belum ada batch pengovenan Gula Serbuk. Silakan pilih tanggal, jumlah batch, dan petani untuk memulai proses.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">
            Data Batch Pengovenan Gula Serbuk ({pengovenanData.length})
          </h3>
          <p className="text-sm text-blue-600 mt-1">
            ✅ Data tersimpan secara lokal dan dapat diekspor ke CSV
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={onRefresh}
            variant="outline"
            disabled={loading}
            className="flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
          <Button
            onClick={onExport}
            className="bg-green-600 hover:bg-green-700 text-white flex items-center space-x-2"
            disabled={pengovenanData.length === 0}
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </Button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Nomor Lot
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tanggal Oven
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Batch
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Kode Petani
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Nama Petani
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Bahan Baku (kg)
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Susut (kg)
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                QC Off (kg)
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Setelah Kering (kg)
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Aksi
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {pengovenanData.map((batch) => (
              <tr key={batch.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">
                    {batch.nomor_lot}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {new Date(batch.tanggal_pengovenan).toLocaleDateString('id-ID')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                    Batch {batch.batch_number}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {batch.kode_petani}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {batch.nama_petani}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium mr-1">
                    Serbuk
                  </span>
                  {formatNumber(batch.jumlah_bahan_baku)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-medium">
                  {formatNumber(batch.susut)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 font-medium">
                  {formatNumber(batch.qc_off)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                  {formatNumber(batch.setelah_kering)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => handleDelete(batch.id, batch.nomor_lot)}
                    className="text-red-600 hover:text-red-900 p-1 hover:bg-red-50 rounded"
                    title="Hapus batch"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Summary */}
      <div className="bg-blue-50 px-6 py-4 border-t border-blue-200">
        <div className="mb-2">
          <span className="text-sm font-medium text-blue-800">
            📊 Ringkasan Pengovenan Gula Serbuk
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="font-medium text-gray-700">Total Bahan Baku: </span>
            <span className="text-gray-900">
              {formatNumber(pengovenanData.reduce((sum, b) => sum + b.jumlah_bahan_baku, 0))} kg
            </span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Total Susut: </span>
            <span className="text-gray-900">
              {formatNumber(pengovenanData.reduce((sum, b) => sum + b.susut, 0))} kg
            </span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Total QC Off: </span>
            <span className="text-gray-900">
              {formatNumber(pengovenanData.reduce((sum, b) => sum + b.qc_off, 0))} kg
            </span>
          </div>
          <div>
            <span className="font-medium text-gray-700">Total Setelah Kering: </span>
            <span className="text-green-600 font-medium">
              {formatNumber(pengovenanData.reduce((sum, b) => sum + b.setelah_kering, 0))} kg
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BatchPengovenanTable;