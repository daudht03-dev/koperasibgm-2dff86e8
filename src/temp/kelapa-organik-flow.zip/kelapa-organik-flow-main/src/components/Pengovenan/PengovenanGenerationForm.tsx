import React from 'react';
import { CalendarIcon, Flame, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Calendar } from '../ui/calendar';
import { Alert, AlertDescription } from '../ui/alert';
import { cn } from '@/lib/utils';
import { PengovenanFormData, PetaniForBatch } from '../../types/pengovenan';

interface PengovenanGenerationFormProps {
  formData: PengovenanFormData;
  setFormData: (data: PengovenanFormData) => void;
  availableDates: string[];
  farmersForDate: PetaniForBatch[];
  onGenerate: () => void;
  onNextBatch: () => void;
  loading: boolean;
  hasDataSerbuk: boolean;
}

const PengovenanGenerationForm: React.FC<PengovenanGenerationFormProps> = ({
  formData,
  setFormData,
  availableDates,
  farmersForDate,
  onGenerate,
  onNextBatch,
  loading,
  hasDataSerbuk
}) => {
  const handleTanggalBahanBakuChange = (value: string) => {
    setFormData({
      ...formData,
      tanggal_bahan_baku: value,
      selected_petani: [] // Reset selected petani when date changes
    });
  };

  const handlePetaniToggle = (kodePetani: string) => {
    const currentSelected = formData.selected_petani;
    
    if (currentSelected.includes(kodePetani)) {
      // Remove petani
      setFormData({
        ...formData,
        selected_petani: currentSelected.filter(k => k !== kodePetani)
      });
    } else {
      // Add petani (no batch limit anymore)
      setFormData({
        ...formData,
        selected_petani: [...currentSelected, kodePetani]
      });
    }
  };

  if (!hasDataSerbuk) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            ⚠️ Belum tersedia data Gula Serbuk untuk diproses pengovenan. 
            Silakan generate data bahan baku dari penjualan Gula Serbuk terlebih dahulu.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
        <Flame className="w-5 h-5 text-red-600" />
        <span>Generate Batch Pengovenan (Khusus Gula Serbuk)</span>
      </h3>

      {/* Info Badge */}
      <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-sm text-blue-800 flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4" />
          <span>Pengovenan hanya berlaku untuk data Gula Serbuk. Nomor lot akan dibuat otomatis.</span>
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* Tanggal Pengovenan */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tanggal Pengovenan *
          </label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !formData.tanggal_pengovenan && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {formData.tanggal_pengovenan ? format(formData.tanggal_pengovenan, "dd/MM/yyyy") : "Pilih tanggal"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={formData.tanggal_pengovenan}
                onSelect={(date) => setFormData({ ...formData, tanggal_pengovenan: date })}
                initialFocus
                className="p-3"
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Tanggal Bahan Baku */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tanggal Bahan Baku (Gula Serbuk) *
          </label>
          <Select value={formData.tanggal_bahan_baku} onValueChange={handleTanggalBahanBakuChange}>
            <SelectTrigger>
              <SelectValue placeholder="Pilih tanggal bahan baku" />
            </SelectTrigger>
            <SelectContent>
              {availableDates.length > 0 ? (
                availableDates.map(date => (
                  <SelectItem key={date} value={date}>
                    {new Date(date).toLocaleDateString('id-ID')} (Gula Serbuk)
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="" disabled>
                  Tidak ada data Gula Serbuk
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="flex justify-center space-x-4 mb-6">
        <Button 
          onClick={onGenerate}
          className="bg-red-600 hover:bg-red-700 px-8"
          disabled={
            loading ||
            !formData.tanggal_pengovenan || 
            !formData.tanggal_bahan_baku || 
            formData.selected_petani.length === 0
          }
        >
          {loading ? 'Generating...' : 'Generate Batch Oven'}
        </Button>
        
        <Button 
          onClick={onNextBatch}
          variant="outline"
          className="border-red-500 text-red-600 hover:bg-red-50 px-8"
          disabled={
            loading ||
            !formData.tanggal_bahan_baku ||
            farmersForDate.filter(f => f.available).length === 0
          }
        >
          Auto Next Batch
        </Button>
      </div>

      {/* Petani Selection */}
      {formData.tanggal_bahan_baku && farmersForDate.length > 0 && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Pilih Petani untuk Batch Pengovenan (Gula Serbuk) *
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {farmersForDate.map(farmer => (
              <div
                key={farmer.kode_petani}
                className={cn(
                  "p-3 border rounded-lg cursor-pointer transition-colors",
                  formData.selected_petani.includes(farmer.kode_petani)
                    ? "border-red-500 bg-red-50"
                    : farmer.available
                    ? "border-gray-300 hover:border-gray-400"
                    : "border-red-300 bg-red-50 opacity-50 cursor-not-allowed"
                )}
                onClick={() => farmer.available && handlePetaniToggle(farmer.kode_petani)}
              >
                <div className="font-medium">{farmer.kode_petani}</div>
                <div className="text-sm text-gray-600">{farmer.nama_petani}</div>
                <div className="text-sm text-blue-600 font-medium">
                  {farmer.jumlah_bahan_baku.toFixed(1)} kg (Gula Serbuk)
                </div>
                {!farmer.available && (
                  <div className="text-xs text-red-600 mt-1">
                    Sudah diproses dalam batch lain
                  </div>
                )}
              </div>
            ))}
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Dipilih: {formData.selected_petani.length} petani
          </p>
        </div>
      )}

      {formData.tanggal_bahan_baku && farmersForDate.length === 0 && (
        <Alert className="border-yellow-200 bg-yellow-50 mt-4">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            ⚠️ Tidak ada data petani Gula Serbuk untuk tanggal yang dipilih
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default PengovenanGenerationForm;