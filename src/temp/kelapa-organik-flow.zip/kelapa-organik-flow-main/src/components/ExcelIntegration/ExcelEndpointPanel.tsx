import React, { useState } from 'react';
import { Download, ExternalLink, Copy, FileSpreadsheet, Database, Flame } from 'lucide-react';
import { Button } from '../ui/button';
import { Alert, AlertDescription } from '../ui/alert';
import { usePanenData } from '../../hooks/usePanenData';
import { usePenjualan } from '../../hooks/usePenjualan';
import { LocalPengovenanService } from '../../services/localPengovenanService';
import { usePengovenan } from '../../hooks/usePengovenan';
import { 
  convertPanenDataToCSV, 
  convertPenjualanDataToCSV,
  convertPanenDataToJSON,
  convertPenjualanDataToJSON,
  createDataEndpoint,
  generatePublicEndpoints
} from '../../utils/apiEndpoints';

const ExcelEndpointPanel: React.FC = () => {
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const { panenData } = usePanenData();
  const { salesList } = usePenjualan();
  const { pengovenanData } = usePengovenan();
  
  const endpoints = generatePublicEndpoints();
  const supabasePengovenanEndpoint = LocalPengovenanService.getPublicEndpointUrl();
  const supabaseDataPanenEndpoint = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/data_panen?select=*&apikey=${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`;

  const handleCopyUrl = async (url: string, type: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedUrl(type);
      setTimeout(() => setCopiedUrl(null), 2000);
    } catch (err) {
      console.error('Failed to copy URL:', err);
    }
  };

  const handleDownloadData = (dataType: 'panen' | 'penjualan' | 'pengovenan' | 'generate-panen', format: 'csv' | 'json') => {
    let data: string;
    let filename: string;

    if (dataType === 'panen') {
      if (format === 'csv') {
        data = convertPanenDataToCSV(panenData);
        filename = `panen-data-${new Date().toISOString().split('T')[0]}.csv`;
      } else {
        data = JSON.stringify(convertPanenDataToJSON(panenData), null, 2);
        filename = `panen-data-${new Date().toISOString().split('T')[0]}.json`;
      }
    } else if (dataType === 'penjualan') {
      if (format === 'csv') {
        data = convertPenjualanDataToCSV(salesList);
        filename = `penjualan-data-${new Date().toISOString().split('T')[0]}.csv`;
      } else {
        data = JSON.stringify(convertPenjualanDataToJSON(salesList), null, 2);
        filename = `penjualan-data-${new Date().toISOString().split('T')[0]}.json`;
      }
    } else if (dataType === 'pengovenan') {
      if (format === 'csv') {
        data = LocalPengovenanService.convertToExcelCSV(pengovenanData);
        filename = `pengovenan-data-${new Date().toISOString().split('T')[0]}.csv`;
      } else {
        data = JSON.stringify(pengovenanData, null, 2);
        filename = `pengovenan-data-${new Date().toISOString().split('T')[0]}.json`;
      }
    } else if (dataType === 'generate-panen') {
      // For generate-panen, we'll use the latest data from Supabase
      if (format === 'csv') {
        // We'll use a placeholder as this requires async data fetching
        data = 'Tanggal Panen,Kode Petani,Nama Petani,Rata-rata,Jumlah Panen,Jenis Panen\nPlease use Supabase endpoint for real-time data';
        filename = `generate-panen-data-${new Date().toISOString().split('T')[0]}.csv`;
      } else {
        data = JSON.stringify([], null, 2);
        filename = `generate-panen-data-${new Date().toISOString().split('T')[0]}.json`;
      }
    }

    const url = createDataEndpoint(data, format);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const openInNewTab = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <div className="p-3 bg-green-100 rounded-lg">
          <FileSpreadsheet className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Excel Integration</h2>
          <p className="text-gray-600">Endpoint publik untuk import data ke Microsoft Excel</p>
        </div>
      </div>

      {/* Instructions */}
      <Alert className="border-blue-200 bg-blue-50">
        <Database className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800">
          <strong>Cara Import ke Excel:</strong>
          <ol className="mt-2 ml-4 list-decimal space-y-1">
            <li>Buka Microsoft Excel</li>
            <li>Klik <strong>Data → Get Data → From Web</strong></li>
            <li>Copy URL endpoint di bawah dan paste ke Excel</li>
            <li>Klik OK → Data akan otomatis ter-import sebagai tabel</li>
            <li>Set refresh otomatis: <strong>Data → Properties → Refresh every 5 minutes</strong></li>
          </ol>
        </AlertDescription>
      </Alert>

      {/* Supabase Pengovenan Endpoint */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
          <Flame className="w-5 h-5 text-red-600" />
          <span>Data Pengovenan (Supabase Direct)</span>
        </h3>
        
        <div className="border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium text-gray-800">Supabase REST API</h4>
            <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">
              Real-time Database
            </span>
          </div>
          
          <div className="bg-gray-50 p-3 rounded border text-sm font-mono break-all mb-3">
            {supabasePengovenanEndpoint || 'Supabase not configured'}
          </div>
          
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleCopyUrl(supabasePengovenanEndpoint, 'supabase-pengovenan')}
              className="flex items-center space-x-1"
              disabled={!supabasePengovenanEndpoint}
            >
              <Copy className="w-4 h-4" />
              <span>{copiedUrl === 'supabase-pengovenan' ? 'Copied!' : 'Copy URL'}</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleDownloadData('pengovenan', 'csv')}
              className="flex items-center space-x-1"
              disabled={pengovenanData.length === 0}
            >
              <Download className="w-4 h-4" />
              <span>Download CSV</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => openInNewTab(supabasePengovenanEndpoint)}
              className="flex items-center space-x-1"
              disabled={!supabasePengovenanEndpoint}
            >
              <ExternalLink className="w-4 h-4" />
              <span>Open API</span>
            </Button>
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-sm text-green-800">
            <strong>✅ Keunggulan Supabase Direct:</strong>
          </p>
          <ul className="mt-2 ml-4 list-disc space-y-1 text-sm text-green-700">
            <li>Data real-time langsung dari database</li>
            <li>Tidak perlu refresh manual</li>
            <li>Format JSON standar untuk Excel</li>
            <li>Public access tanpa autentikasi</li>
          </ul>
        </div>
      </div>

      {/* Supabase Generate Panen Endpoint */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
          <Database className="w-5 h-5 text-green-600" />
          <span>Data Generate Panen (Supabase Direct)</span>
        </h3>
        
        <div className="border border-gray-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium text-gray-800">Supabase REST API</h4>
            <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
              Real-time Database
            </span>
          </div>
          
          <div className="bg-gray-50 p-3 rounded border text-sm font-mono break-all mb-3">
            {supabaseDataPanenEndpoint || 'Supabase not configured'}
          </div>
          
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleCopyUrl(supabaseDataPanenEndpoint, 'supabase-data-panen')}
              className="flex items-center space-x-1"
              disabled={!supabaseDataPanenEndpoint}
            >
              <Copy className="w-4 h-4" />
              <span>{copiedUrl === 'supabase-data-panen' ? 'Copied!' : 'Copy URL'}</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleDownloadData('generate-panen', 'csv')}
              className="flex items-center space-x-1"
            >
              <Download className="w-4 h-4" />
              <span>Download CSV</span>
            </Button>
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => openInNewTab(supabaseDataPanenEndpoint)}
              className="flex items-center space-x-1"
              disabled={!supabaseDataPanenEndpoint}
            >
              <ExternalLink className="w-4 h-4" />
              <span>Open API</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Data Panen Endpoints */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
          <Database className="w-5 h-5 text-blue-600" />
          <span>Data Panen Endpoints</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* CSV Endpoint */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-800">CSV Format</h4>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                Recommended for Excel
              </span>
            </div>
            
            <div className="bg-gray-50 p-3 rounded border text-sm font-mono break-all mb-3">
              {endpoints.panenCSV}
            </div>
            
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopyUrl(endpoints.panenCSV, 'panen-csv')}
                className="flex items-center space-x-1"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedUrl === 'panen-csv' ? 'Copied!' : 'Copy URL'}</span>
              </Button>
              
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleDownloadData('panen', 'csv')}
                className="flex items-center space-x-1"
              >
                <Download className="w-4 h-4" />
                <span>Download</span>
              </Button>
            </div>
          </div>

          {/* JSON Endpoint */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-800">JSON Format</h4>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                For Advanced Use
              </span>
            </div>
            
            <div className="bg-gray-50 p-3 rounded border text-sm font-mono break-all mb-3">
              {endpoints.panenJSON}
            </div>
            
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopyUrl(endpoints.panenJSON, 'panen-json')}
                className="flex items-center space-x-1"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedUrl === 'panen-json' ? 'Copied!' : 'Copy URL'}</span>
              </Button>
              
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleDownloadData('panen', 'json')}
                className="flex items-center space-x-1"
              >
                <Download className="w-4 h-4" />
                <span>Download</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Data Penjualan Endpoints */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center space-x-2">
          <Database className="w-5 h-5 text-green-600" />
          <span>Data Penjualan Endpoints</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* CSV Endpoint */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-800">CSV Format</h4>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                Recommended for Excel
              </span>
            </div>
            
            <div className="bg-gray-50 p-3 rounded border text-sm font-mono break-all mb-3">
              {endpoints.penjualanCSV}
            </div>
            
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopyUrl(endpoints.penjualanCSV, 'penjualan-csv')}
                className="flex items-center space-x-1"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedUrl === 'penjualan-csv' ? 'Copied!' : 'Copy URL'}</span>
              </Button>
              
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleDownloadData('penjualan', 'csv')}
                className="flex items-center space-x-1"
              >
                <Download className="w-4 h-4" />
                <span>Download</span>
              </Button>
            </div>
          </div>

          {/* JSON Endpoint */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium text-gray-800">JSON Format</h4>
              <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                For Advanced Use
              </span>
            </div>
            
            <div className="bg-gray-50 p-3 rounded border text-sm font-mono break-all mb-3">
              {endpoints.penjualanJSON}
            </div>
            
            <div className="flex space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopyUrl(endpoints.penjualanJSON, 'penjualan-json')}
                className="flex items-center space-x-1"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedUrl === 'penjualan-json' ? 'Copied!' : 'Copy URL'}</span>
              </Button>
              
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleDownloadData('penjualan', 'json')}
                className="flex items-center space-x-1"
              >
                <Download className="w-4 h-4" />
                <span>Download</span>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Data Preview */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Preview Data Format</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Pengovenan Data Preview */}
          <div>
            <h4 className="font-medium text-gray-800 mb-2">Data Pengovenan (CSV)</h4>
            <div className="bg-gray-50 p-3 rounded border text-xs font-mono overflow-x-auto">
              <pre>{`Nomor Lot,Tanggal Pengovenan,Batch,Kode Petani,Nama Petani,Bahan Baku,Susut,QC Off,Setelah Kering
LOT-20250115-01,2025-01-15,1,PT001,Sutardi,65.8,3.2,1.8,60.8
LOT-20250115-02,2025-01-16,2,PT002,Slamet,58.3,2.9,1.6,53.8`}</pre>
            </div>
          </div>

          {/* Panen Data Preview */}
          <div>
            <h4 className="font-medium text-gray-800 mb-2">Data Panen (CSV)</h4>
            <div className="bg-gray-50 p-3 rounded border text-xs font-mono overflow-x-auto">
              <pre>{`Kode Petani,Nama Petani,Rata-rata,01/01/2024,02/01/2024,TOTAL,TGL AMBIL
PT001,Sutardi,11.2,11.2,11.4,65.8,09/01/2024
PT002,Slamet,9.8,9.8,10.1,58.3,09/01/2024`}</pre>
            </div>
          </div>

          {/* Penjualan Data Preview */}
          <div>
            <h4 className="font-medium text-gray-800 mb-2">Data Penjualan (CSV)</h4>
            <div className="bg-gray-50 p-3 rounded border text-xs font-mono overflow-x-auto">
              <pre>{`Tanggal Jual,Kode Petani,Nama Petani,Jumlah Jual,Total Harga
01/01/2024,PT001,Sutardi,65.8,658000
01/01/2024,PT002,Slamet,58.3,583000`}</pre>
            </div>
          </div>
        </div>
      </div>

      {/* Technical Notes */}
      <Alert className="border-yellow-200 bg-yellow-50">
        <AlertDescription className="text-yellow-800">
          <strong>📋 Catatan Teknis:</strong>
          <ul className="mt-2 ml-4 list-disc space-y-1">
            <li><strong>Data Pengovenan</strong> tersimpan real-time di Supabase dengan public access</li>
            <li>Semua angka diformat sebagai <strong>number</strong> (bukan string) agar tidak jadi tanggal di Excel</li>
            <li>Format desimal: 1 digit di belakang koma, bilangan bulat tanpa koma</li>
            <li>Tanggal dalam format <strong>dd/mm/yyyy</strong> untuk kompatibilitas Excel</li>
            <li>Data diperbarui real-time sesuai perubahan di aplikasi</li>
            <li>Endpoint Supabase dapat diakses publik tanpa autentikasi</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default ExcelEndpointPanel;