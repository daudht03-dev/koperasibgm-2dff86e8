import React from 'react';
import { Package } from 'lucide-react';
import { GeneratedBahanBaku } from '../../hooks/useBahanBaku';

interface BahanBakuTableProps {
  data: GeneratedBahanBaku[];
}

const BahanBakuTable: React.FC<BahanBakuTableProps> = ({ data }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden animate-fade-in">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800">
          Daftar Bahan Baku ({data.length})
        </h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Tanggal Masuk
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                No. Lot
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Nama Pengepul
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Kode Petani
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Nama Petani
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                Jumlah Barang Petani
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                Total per Pengepul
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                Total Keseluruhan
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Jenis
              </th>
            </tr>
          </thead>
          
          <tbody className="bg-white divide-y divide-gray-200">
            {data.map((bahan) => (
              <tr key={bahan.id} className="hover:bg-gray-50 transition-colors duration-150">
                <td className="px-4 py-4 text-sm text-gray-900">
                  {new Date(bahan.tanggalMasuk).toLocaleDateString('id-ID')}
                </td>
                <td className="px-4 py-4 text-sm font-medium text-purple-600">
                  {bahan.noLot}
                </td>
                <td className="px-4 py-4 text-sm text-gray-900">
                  {bahan.namaPengepul}
                </td>
                <td className="px-4 py-4 text-sm font-medium text-gray-900">
                  {bahan.kodePetani}
                </td>
                <td className="px-4 py-4 text-sm text-gray-900">
                  {bahan.namaPetani}
                </td>
                <td className="px-4 py-4 text-sm font-bold text-green-600 text-right">
                  {bahan.jumlahMasuk.toFixed(1)} kg
                </td>
                <td className="px-4 py-4 text-sm font-bold text-blue-600 text-right">
                  {bahan.totalPerPengepul.toFixed(1)} kg
                </td>
                <td className="px-4 py-4 text-sm font-bold text-purple-600 text-right">
                  {bahan.totalKeseluruhan.toFixed(1)} kg
                </td>
                <td className="px-4 py-4 text-sm">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full transition-colors duration-200 ${
                    bahan.type === 'serbuk' 
                      ? 'bg-blue-100 text-blue-800 hover:bg-blue-200' 
                      : 'bg-green-100 text-green-800 hover:bg-green-200'
                  }`}>
                    {bahan.type === 'serbuk' ? 'Serbuk' : 'Cetak'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        {data.length === 0 && (
          <div className="text-center py-12 animate-fade-in">
            <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">
              Belum ada data bahan baku. Generate dari data penjualan terlebih dahulu.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BahanBakuTable;