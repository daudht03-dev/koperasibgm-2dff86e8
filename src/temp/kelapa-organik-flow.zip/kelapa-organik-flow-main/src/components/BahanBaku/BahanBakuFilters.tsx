import React from 'react';
import { Search } from 'lucide-react';

interface BahanBakuFiltersProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  filterType: 'all' | 'serbuk' | 'cetak';
  setFilterType: (value: 'all' | 'serbuk' | 'cetak') => void;
}

const BahanBakuFilters: React.FC<BahanBakuFiltersProps> = ({
  searchTerm,
  setSearchTerm,
  filterType,
  setFilterType
}) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Cari berdasarkan petani atau pengepul..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
          />
        </div>
        
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value as 'all' | 'serbuk' | 'cetak')}
          className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
        >
          <option value="all">Semua Jenis</option>
          <option value="serbuk">Gula Serbuk</option>
          <option value="cetak">Gula Cetak</option>
        </select>
      </div>
    </div>
  );
};

export default BahanBakuFilters;