import React from 'react';
import { Package, Calendar, Search } from 'lucide-react';

interface BahanBakuStatsProps {
  totalBahanBaku: number;
  totalEntries: number;
}

const BahanBakuStats: React.FC<BahanBakuStatsProps> = ({
  totalBahanBaku,
  totalEntries
}) => {
  const averagePerEntry = totalEntries > 0 ? totalBahanBaku / totalEntries : 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-white p-6 rounded-xl shadow-lg animate-fade-in">
        <div className="flex items-center">
          <div className="p-3 bg-blue-100 rounded-lg">
            <Package className="w-6 h-6 text-blue-600" />
          </div>
          <div className="ml-4">
            <p className="text-gray-600 text-sm">Total Bahan Baku</p>
            <p className="text-2xl font-bold text-gray-800">{totalBahanBaku.toFixed(1)} kg</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-lg animate-fade-in">
        <div className="flex items-center">
          <div className="p-3 bg-green-100 rounded-lg">
            <Calendar className="w-6 h-6 text-green-600" />
          </div>
          <div className="ml-4">
            <p className="text-gray-600 text-sm">Total Entri</p>
            <p className="text-2xl font-bold text-gray-800">{totalEntries}</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-lg animate-fade-in">
        <div className="flex items-center">
          <div className="p-3 bg-yellow-100 rounded-lg">
            <Search className="w-6 h-6 text-yellow-600" />
          </div>
          <div className="ml-4">
            <p className="text-gray-600 text-sm">Rata-rata per Entri</p>
            <p className="text-2xl font-bold text-gray-800">
              {averagePerEntry.toFixed(1)} kg
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BahanBakuStats;