import React from 'react';
import { Package, FileText, Download } from 'lucide-react';
import { useDataContext } from '../../contexts/DataContext';
import { useBahanBaku } from '../../hooks/useBahanBaku';
import { exportBahanBakuToCSV } from '../../utils/bahanBakuUtils';
import BahanBakuStats from './BahanBakuStats';
import BahanBakuGenerationForm from './BahanBakuGenerationForm';
import BahanBakuFilters from './BahanBakuFilters';
import BahanBakuTable from './BahanBakuTable';

const DataBahanBaku: React.FC = () => {
  const { bahanBakuData, penjualanData } = useDataContext();
  const {
    filteredBahanBaku,
    searchTerm,
    filterType,
    noLot,
    selectedDate,
    selectedPengepul,
    availableDates,
    groupedSalesForDate,
    selectedPengepulData,
    totalBahanBaku,
    setSearchTerm,
    setFilterType,
    setNoLot,
    setSelectedDate,
    setSelectedPengepul,
    generateBahanBaku
  } = useBahanBaku(bahanBakuData, penjualanData);

  const handleExport = () => {
    exportBahanBakuToCSV(filteredBahanBaku);
  };

  const handleGenerate = async () => {
    await generateBahanBaku();
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between animate-fade-in">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-purple-100 rounded-lg">
            <Package className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Data Bahan Baku</h1>
            <p className="text-gray-600">Generate dan kelola data bahan baku dari hasil penjualan</p>
          </div>
        </div>
        
        <div className="flex space-x-3">
          <button
            onClick={handleGenerate}
            disabled={!selectedDate || !noLot}
            className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-all duration-200 flex items-center space-x-2 disabled:bg-gray-400 disabled:cursor-not-allowed hover-scale"
          >
            <FileText className="w-4 h-4" />
            <span>Generate Data Bahan Baku</span>
          </button>
          
          {filteredBahanBaku.length > 0 && (
            <button
              onClick={handleExport}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-all duration-200 flex items-center space-x-2 hover-scale"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
          )}
        </div>
      </div>

      {/* Stats */}
      <BahanBakuStats 
        totalBahanBaku={totalBahanBaku}
        totalEntries={filteredBahanBaku.length}
      />

      {/* Generation Form */}
      <BahanBakuGenerationForm
        noLot={noLot}
        setNoLot={setNoLot}
        selectedDate={selectedDate}
        setSelectedDate={setSelectedDate}
        selectedPengepul={selectedPengepul}
        setSelectedPengepul={setSelectedPengepul}
        availableDates={availableDates}
        groupedSalesForDate={groupedSalesForDate}
        selectedPengepulData={selectedPengepulData}
      />

      {/* Filters */}
      <BahanBakuFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        filterType={filterType}
        setFilterType={setFilterType}
      />

      {/* Table */}
      <BahanBakuTable data={filteredBahanBaku} />
    </div>
  );
};

export default DataBahanBaku;