import React from 'react';

interface BahanBakuGenerationFormProps {
  noLot: string;
  setNoLot: (value: string) => void;
  selectedDate: string;
  setSelectedDate: (value: string) => void;
  selectedPengepul: string;
  setSelectedPengepul: (value: string) => void;
  availableDates: string[];
  groupedSalesForDate: Record<string, any[]>;
  selectedPengepulData: any[];
}

const BahanBakuGenerationForm: React.FC<BahanBakuGenerationFormProps> = ({
  noLot,
  setNoLot,
  selectedDate,
  setSelectedDate,
  selectedPengepul,
  setSelectedPengepul,
  availableDates,
  groupedSalesForDate,
  selectedPengepulData
}) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 animate-fade-in">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Generate Data Bahan Baku</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Nomor Lot *</label>
          <input
            type="text"
            value={noLot}
            onChange={(e) => setNoLot(e.target.value)}
            placeholder="Masukkan nomor lot"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Tanggal Masuk *</label>
          <select
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
          >
            <option value="">Pilih Tanggal</option>
            {availableDates.map(date => (
              <option key={date} value={date}>
                {new Date(date).toLocaleDateString('id-ID')}
              </option>
            ))}
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Pengepul (Preview)</label>
          <select
            value={selectedPengepul}
            onChange={(e) => setSelectedPengepul(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
            disabled={!selectedDate}
          >
            <option value="">Pilih Pengepul</option>
            <option value="ALL_PENGEPUL" className="font-semibold text-purple-600">
              🌟 Semua Pengepul
            </option>
            {Object.keys(groupedSalesForDate).map(pengepulName => (
              <option key={pengepulName} value={pengepulName}>
                {pengepulName}
              </option>
            ))}
          </select>
        </div>
        
        <div className="flex items-end">
          <div className="w-full">
            <p className="text-sm font-medium text-gray-700 mb-2">
              {selectedPengepul === 'ALL_PENGEPUL' ? 'Total Semua Pengepul' : 'Total Pengepul'}
            </p>
            <p className="text-lg font-bold text-purple-600">
              {selectedPengepulData.length > 0 ? 
                selectedPengepulData.reduce((sum, sale) => sum + sale.jumlahJual, 0).toFixed(1) + ' kg'
                : '0 kg'
              }
            </p>
          </div>
        </div>
      </div>
      
      {selectedPengepulData.length > 0 && (
        <div className="mt-4 p-4 bg-gray-50 rounded-lg animate-scale-in">
          <h4 className="font-medium text-gray-800 mb-2">
            {selectedPengepul === 'ALL_PENGEPUL' 
              ? `Preview Data untuk Semua Pengepul (${Object.keys(groupedSalesForDate).length} pengepul)`
              : `Preview Data untuk ${selectedPengepul}`
            }
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {selectedPengepulData.map(sale => (
              <div key={sale.id} className="bg-white p-3 rounded border hover-scale">
                <p className="text-sm font-medium">{sale.kodePetani} - {sale.namaPetani}</p>
                <p className="text-lg font-bold text-purple-600">{sale.jumlahJual} kg</p>
                <p className="text-xs text-gray-500">
                  {sale.type === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'}
                </p>
                <p className="text-xs font-medium text-blue-600">
                  Pengepul: {sale.namaPengepul}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BahanBakuGenerationForm;