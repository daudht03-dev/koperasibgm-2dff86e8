
import React, { useMemo } from 'react';
import { TrendingUp, Users, Package, Truck, AlertCircle } from 'lucide-react';
import { useDataContext } from '../../contexts/DataContext';

const DashboardOverview: React.FC = () => {
  const { 
    petaniData, 
    panenData, 
    penjualanData, 
    bahanBakuData, 
    loading,
    error 
  } = useDataContext();

  // Calculate real-time statistics
  const stats = useMemo(() => {
    const totalPetani = petaniData.length;
    
    // Calculate this week's harvest
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const thisWeekPanen = panenData.filter(panen => 
      new Date(panen.tanggalMulai) >= oneWeekAgo
    );
    
    const totalPanenThisWeek = thisWeekPanen.reduce((total, panen) => 
      total + (panen.totalPanen || 0), 0
    );
    
    // Calculate total stock in warehouse (from bahan baku)
    const totalStokGudang = bahanBakuData.reduce((total, item) => 
      total + (item.jumlahMasuk || 0), 0
    );
    
    // Calculate recent sales
    const recentSales = penjualanData.filter(sale => 
      new Date(sale.tanggalJual) >= oneWeekAgo
    );
    
    return [
      {
        title: 'Total Petani',
        value: totalPetani.toString(),
        change: 'Petani terdaftar',
        icon: Users,
        color: 'bg-blue-500',
        trend: 'up'
      },
      {
        title: 'Panen Minggu Ini',
        value: `${totalPanenThisWeek.toFixed(1)} kg`,
        change: `${thisWeekPanen.length} batch panen`,
        icon: Package,
        color: 'bg-green-500',
        trend: 'up'
      },
      {
        title: 'Stok Bahan Baku',
        value: `${totalStokGudang.toFixed(1)} kg`,
        change: `${bahanBakuData.length} lot masuk`,
        icon: Package,
        color: 'bg-yellow-500',
        trend: 'stable'
      },
      {
        title: 'Penjualan Minggu Ini',
        value: recentSales.length.toString(),
        change: `${recentSales.reduce((total, sale) => total + (sale.jumlahJual || 0), 0).toFixed(1)} kg terjual`,
        icon: TrendingUp,
        color: 'bg-purple-500',
        trend: 'up'
      }
    ];
  }, [petaniData, panenData, penjualanData, bahanBakuData]);

  // Recent activities from real data
  const recentActivities = useMemo(() => {
    const activities = [];
    
    // Recent panen data
    const recentPanen = panenData.slice(0, 2);
    recentPanen.forEach(panen => {
      activities.push({
        id: `panen-${panen.id}`,
        type: 'panen',
        message: `Data panen ${panen.namaPetani} (${panen.kodePetani}) - ${panen.totalPanen}kg`,
        time: new Date().toLocaleDateString('id-ID'),
        icon: Package
      });
    });
    
    // Recent sales data
    const recentSales = penjualanData.slice(0, 2);
    recentSales.forEach(sale => {
      activities.push({
        id: `sale-${sale.id}`,
        type: 'penjualan',
        message: `Penjualan ${sale.namaPetani} ke ${sale.namaPengepul} - ${sale.jumlahJual}kg`,
        time: new Date(sale.tanggalJual).toLocaleDateString('id-ID'),
        icon: TrendingUp
      });
    });
    
    // Recent bahan baku
    const recentBahanBaku = bahanBakuData.slice(0, 1);
    recentBahanBaku.forEach(item => {
      activities.push({
        id: `bahan-${item.id}`,
        type: 'bahan_baku',
        message: `Bahan baku masuk: ${item.namaPetani} - ${item.jumlahMasuk}kg`,
        time: new Date(item.tanggalMasuk).toLocaleDateString('id-ID'),
        icon: AlertCircle
      });
    });
    
    return activities.slice(0, 3); // Limit to 3 activities
  }, [panenData, penjualanData, bahanBakuData]);

  if (loading) {
    return (
      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-6 text-white">
          <h1 className="text-3xl font-bold mb-2">Memuat Dashboard...</h1>
          <p className="text-green-100">Sedang mengambil data dari database</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 space-y-6">
        <div className="bg-gradient-to-r from-red-600 to-red-800 rounded-2xl p-6 text-white">
          <h1 className="text-3xl font-bold mb-2">Error Dashboard</h1>
          <p className="text-red-100">Gagal memuat data: {error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Dashboard Real-Time</h1>
        <p className="text-green-100">Sistem Manajemen Panen dan Distribusi Gula Kelapa Organik - Data Terintegrasi</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg ${stat.color}`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className={`text-sm font-medium ${
                stat.trend === 'up' ? 'text-green-600' : 
                stat.trend === 'down' ? 'text-red-600' : 'text-gray-600'
              }`}>
                {stat.change}
              </div>
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</h3>
            <p className="text-gray-600 text-sm">{stat.title}</p>
          </div>
        ))}
      </div>

      {/* Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Aktivitas Terbaru</h3>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className="p-2 bg-green-100 rounded-lg">
                  <activity.icon className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-800">{activity.message}</p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Aksi Cepat</h3>
          <div className="space-y-3">
            <button className="w-full bg-green-600 text-white px-4 py-3 rounded-lg hover:bg-green-700 transition-colors text-left">
              Generate Data Panen Baru
            </button>
            <button className="w-full bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors text-left">
              Input Penjualan Baru
            </button>
            <button className="w-full bg-purple-600 text-white px-4 py-3 rounded-lg hover:bg-purple-700 transition-colors text-left">
              Proses Pengovenan
            </button>
            <button className="w-full bg-orange-600 text-white px-4 py-3 rounded-lg hover:bg-orange-700 transition-colors text-left">
              Export Data Excel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;
