import React, { useState } from 'react';
import { Plus, Edit, Trash2, Search, Users } from 'lucide-react';
import { useToast } from '../ui/use-toast';
import { useDataContext } from '../../contexts/DataContext';
import { SupabasePetaniService } from '../../services/supabasePetaniService';

const DataPetani: React.FC = () => {
  const { petaniData, loading: contextLoading, refreshData } = useDataContext();
  const [showForm, setShowForm] = useState(false);
  const [editingPetani, setEditingPetani] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    nama: '',
    kode: '',
    alamat: '',
    telepon: '',
    rataRataPanen: 0
  });

  // Use real-time data from context
  const petaniList = petaniData;

  // Generate unique kode
  const generateKode = () => {
    const prefix = 'PT';
    const number = String(petaniList.length + 1).padStart(3, '0');
    return `${prefix}${number}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (editingPetani) {
        // Update existing petani
        await SupabasePetaniService.updatePetani(editingPetani.id, formData);
        
        toast({
          title: "Berhasil",
          description: "Data petani berhasil diperbarui",
        });
      } else {
        // Add new petani
        await SupabasePetaniService.addPetani({
          ...formData,
          kode: formData.kode || generateKode()
        });
        
        toast({
          title: "Berhasil",
          description: "Data petani berhasil ditambahkan",
        });
      }

      // Reset form and refresh data
      setFormData({ nama: '', kode: '', alamat: '', telepon: '', rataRataPanen: 0 });
      setShowForm(false);
      setEditingPetani(null);
      refreshData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Gagal menyimpan data: " + error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (petani: any) => {
    setEditingPetani(petani);
    setFormData({
      nama: petani.nama,
      kode: petani.kode,
      alamat: petani.alamat,
      telepon: petani.telepon || '',
      rataRataPanen: petani.rataRataPanen
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus data petani ini?')) {
      try {
        setLoading(true);
        await SupabasePetaniService.deletePetani(id);
        
        toast({
          title: "Berhasil",
          description: "Data petani berhasil dihapus",
        });
        
        refreshData();
      } catch (error: any) {
        toast({
          title: "Error",
          description: "Gagal menghapus data: " + error.message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    }
  };

  const filteredPetani = petaniList.filter(petani =>
    petani.nama.toLowerCase().includes(searchTerm.toLowerCase()) ||
    petani.kode.toLowerCase().includes(searchTerm.toLowerCase()) ||
    petani.alamat.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-blue-100 rounded-lg">
            <Users className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Data Petani</h1>
            <p className="text-gray-600">Kelola data petani gula kelapa organik</p>
          </div>
        </div>
        <button
          onClick={() => {
            setShowForm(true);
            setEditingPetani(null);
            setFormData({ nama: '', kode: '', alamat: '', telepon: '', rataRataPanen: 0 });
          }}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
          disabled={loading}
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Petani</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Cari berdasarkan nama, kode, atau alamat petani..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Form */}
      {showForm && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            {editingPetani ? 'Edit Data Petani' : 'Tambah Data Petani Baru'}
          </h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nama Petani *
              </label>
              <input
                type="text"
                value={formData.nama}
                onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Masukkan nama petani"
                required
                disabled={loading}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Kode Petani
              </label>
              <input
                type="text"
                value={formData.kode}
                onChange={(e) => setFormData({ ...formData, kode: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Otomatis jika kosong"
                disabled={loading}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Alamat *
              </label>
              <input
                type="text"
                value={formData.alamat}
                onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Masukkan alamat"
                required
                disabled={loading}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nomor Telepon
              </label>
              <input
                type="text"
                value={formData.telepon}
                onChange={(e) => setFormData({ ...formData, telepon: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Nomor telepon (opsional)"
                disabled={loading}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rata-rata Panen Harian (kg) *
              </label>
              <input
                type="number"
                step="0.1"
                value={formData.rataRataPanen}
                onChange={(e) => setFormData({ ...formData, rataRataPanen: parseFloat(e.target.value) || 0 })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="0.0"
                required
                disabled={loading}
              />
            </div>
            <div className="lg:col-span-3 flex space-x-3">
              <button
                type="submit"
                className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                disabled={loading}
              >
                {loading ? 'Menyimpan...' : (editingPetani ? 'Update' : 'Simpan')}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingPetani(null);
                  setFormData({ nama: '', kode: '', alamat: '', telepon: '', rataRataPanen: 0 });
                }}
                className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                disabled={loading}
              >
                Batal
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">
            Daftar Petani ({filteredPetani.length})
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  No
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Kode Petani
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Nama Petani
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Alamat
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Telepon
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rata-rata Panen (kg/hari)
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tanggal Daftar
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {(loading || contextLoading) ? (
                <tr>
                  <td colSpan={8} className="px-6 py-4 text-center text-gray-500">
                    Memuat data...
                  </td>
                </tr>
              ) : filteredPetani.map((petani, index) => (
                <tr key={petani.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {index + 1}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                      {petani.kode}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {petani.nama}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {petani.alamat}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {petani.telepon || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {petani.rataRataPanen} kg
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(petani.createdAt).toLocaleDateString('id-ID')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => handleEdit(petani)}
                      className="text-blue-600 hover:text-blue-900 p-1 hover:bg-blue-50 rounded"
                      disabled={loading}
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(petani.id)}
                      className="text-red-600 hover:text-red-900 p-1 hover:bg-red-50 rounded"
                      disabled={loading}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredPetani.length === 0 && !loading && !contextLoading && (
            <div className="text-center py-12">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Belum ada data petani</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DataPetani;