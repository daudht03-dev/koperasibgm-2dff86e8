
import React from 'react';
import { Edit, Trash2, Truck } from 'lucide-react';
import { Pengepul } from '../../types';
import { usePenjualan } from '../../hooks/usePenjualan';

interface PengepulTableProps {
  pengepulList: Pengepul[];
  onEdit: (pengepul: Pengepul) => void;
  onDelete: (id: string) => void;
}

const PengepulTable: React.FC<PengepulTableProps> = ({ pengepulList, onEdit, onDelete }) => {
  const { getTotalSalesByPengepul } = usePenjualan();

  const handleDelete = (id: string, nama: string) => {
    if (confirm(`Apakah Anda yakin ingin menghapus pengepul "${nama}"?`)) {
      onDelete(id);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-800">
          Daftar Pengepul ({pengepulList.length})
        </h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kode</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Alamat</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Telepon</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Harga/Kg</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Petani Terkait</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Penjualan</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {pengepulList.map((pengepul, index) => {
              const salesStats = getTotalSalesByPengepul(pengepul.id);
              
              return (
                <tr key={pengepul.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{index + 1}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-medium bg-orange-100 text-orange-800 rounded-full">
                      {pengepul.kode}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{pengepul.nama}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{pengepul.alamat}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{pengepul.telepon}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                    Rp {(pengepul.hargaPerKg || 0).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    <div className="flex flex-wrap gap-1">
                      {(pengepul.petaniTerkait || []).map((kodePetani, idx) => (
                        <span key={idx} className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">
                          {kodePetani}
                        </span>
                      ))}
                      {(!pengepul.petaniTerkait || pengepul.petaniTerkait.length === 0) && (
                        <span className="text-gray-400 text-xs">Belum ada petani</span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div className="space-y-1">
                      <div className="text-xs text-gray-500">
                        {salesStats.totalTransactions} transaksi
                      </div>
                      <div className="text-xs font-medium text-blue-600">
                        {salesStats.totalQuantity.toFixed(1)} kg
                      </div>
                      <div className="text-xs font-semibold text-green-600">
                        Rp {salesStats.totalValue.toLocaleString()}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => onEdit(pengepul)}
                      className="text-blue-600 hover:text-blue-900 p-1 hover:bg-blue-50 rounded"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(pengepul.id, pengepul.nama)}
                      className="text-red-600 hover:text-red-900 p-1 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {pengepulList.length === 0 && (
          <div className="text-center py-12">
            <Truck className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">Belum ada data pengepul</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PengepulTable;
