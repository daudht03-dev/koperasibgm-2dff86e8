
import React, { useState, useMemo } from 'react';
import { Plus, Truck } from 'lucide-react';
import { Pengepul } from '../../types';
import { useDataContext } from '../../contexts/DataContext';
import { usePengepul } from '../../hooks/usePengepul';
import PengepulSearch from './PengepulSearch';
import PengepulForm from './PengepulForm';
import PengepulTable from './PengepulTable';

const DataPengepul: React.FC = () => {
  const { pengepulData, petaniData, refreshData } = useDataContext();
  const { 
    searchTerm, 
    setSearchTerm, 
    addPengepul, 
    updatePengepul, 
    deletePengepul,
    getPetaniTerkaitPengepul
  } = usePengepul();

  // Transform data to component format
  const pengepulList = useMemo(() => pengepulData.map(item => ({
    id: item.id,
    nama: item.nama,
    kode: item.kode,
    alamat: item.alamat,
    telepon: item.telepon || '',
    hargaPerKg: item.hargaPerKg || 0,
    petaniTerkait: item.petaniTerkait || [],
    email: '',
    bankAccount: '',
    createdAt: item.createdAt
  })), [pengepulData]);

  const petaniList = useMemo(() => petaniData.map(item => ({
    id: item.id,
    nama: item.nama,
    kode: item.kode,
    alamat: item.alamat,
    telepon: item.telepon || '',
    rataRataPanen: item.rataRataPanen || 0,
    createdAt: item.createdAt
  })), [petaniData]);
  
  const [showForm, setShowForm] = useState(false);
  const [editingPengepul, setEditingPengepul] = useState<Pengepul | null>(null);
  const [formData, setFormData] = useState({
    nama: '',
    kode: '',
    alamat: '',
    telepon: '',
    hargaPerKg: 0,
    petaniTerkait: [] as string[]
  });

  const generateKode = () => {
    const prefix = 'PG';
    const number = String(pengepulList.length + 1).padStart(3, '0');
    return `${prefix}${number}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const pengepulData = {
        ...formData,
        kode: formData.kode || generateKode(),
        email: '',
        bankAccount: ''
      };
      
      if (editingPengepul) {
        await updatePengepul(editingPengepul.id, pengepulData);
      } else {
        await addPengepul(pengepulData);
      }

      refreshData();
      resetForm();
    } catch (error) {
      // Error handling is done in the hook
      console.error('Error submitting form:', error);
    }
  };

  const handleEdit = (pengepul: Pengepul) => {
    setEditingPengepul(pengepul);
    setFormData({
      nama: pengepul.nama,
      kode: pengepul.kode,
      alamat: pengepul.alamat,
      telepon: pengepul.telepon,
      hargaPerKg: pengepul.hargaPerKg || 0,
      petaniTerkait: pengepul.petaniTerkait || []
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({ 
      nama: '', 
      kode: '', 
      alamat: '', 
      telepon: '', 
      hargaPerKg: 0,
      petaniTerkait: []
    });
    setShowForm(false);
    setEditingPengepul(null);
  };

  const handleAddNew = () => {
    setShowForm(true);
    setEditingPengepul(null);
    setFormData({ 
      nama: '', 
      kode: '', 
      alamat: '', 
      telepon: '', 
      hargaPerKg: 0,
      petaniTerkait: []
    });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-orange-100 rounded-lg">
            <Truck className="w-6 h-6 text-orange-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Data Pengepul</h1>
            <p className="text-gray-600">Kelola data pengepul gula kelapa</p>
          </div>
        </div>
        <button
          onClick={handleAddNew}
          className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Pengepul</span>
        </button>
      </div>

      <PengepulSearch searchTerm={searchTerm} onSearchChange={setSearchTerm} />

      {showForm && (
        <PengepulForm
          formData={formData}
          editingPengepul={editingPengepul}
          onFormDataChange={setFormData}
          onSubmit={handleSubmit}
          onCancel={resetForm}
          petaniList={petaniList}
          getPetaniTerkaitPengepul={(petaniKodes) => getPetaniTerkaitPengepul(petaniList, petaniKodes)}
        />
      )}

      <PengepulTable
        pengepulList={pengepulList}
        onEdit={handleEdit}
        onDelete={async (id) => {
          await deletePengepul(id);
          refreshData();
        }}
      />
    </div>
  );
};

export default DataPengepul;
