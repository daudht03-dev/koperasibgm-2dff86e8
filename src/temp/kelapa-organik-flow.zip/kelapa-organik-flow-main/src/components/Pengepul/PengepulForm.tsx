
import React from 'react';
import { Pengepul, Petani } from '../../types';

interface PengepulFormProps {
  formData: {
    nama: string;
    kode: string;
    alamat: string;
    telepon: string;
    hargaPerKg: number;
    petaniTerkait: string[];
  };
  editingPengepul: Pengepul | null;
  onFormDataChange: (data: { 
    nama: string; 
    kode: string; 
    alamat: string; 
    telepon: string;
    hargaPerKg: number;
    petaniTerkait: string[];
  }) => void;
  onSubmit: (e: React.FormEvent) => void;
  onCancel: () => void;
  petaniList: Petani[];
  getPetaniTerkaitPengepul: (petaniKodes: string[]) => Petani[];
}

const PengepulForm: React.FC<PengepulFormProps> = ({
  formData,
  editingPengepul,
  onFormDataChange,
  onSubmit,
  onCancel,
  petaniList,
  getPetaniTerkaitPengepul
}) => {
  const selectedPetani = getPetaniTerkaitPengepul(formData.petaniTerkait);

  const handlePetaniSelection = (kodePetani: string) => {
    const updatedPetaniTerkait = formData.petaniTerkait.includes(kodePetani)
      ? formData.petaniTerkait.filter(kode => kode !== kodePetani)
      : [...formData.petaniTerkait, kodePetani];
    
    onFormDataChange({ ...formData, petaniTerkait: updatedPetaniTerkait });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">
        {editingPengepul ? 'Edit Data Pengepul' : 'Tambah Data Pengepul Baru'}
      </h3>
      <form onSubmit={onSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nama Pengepul *
            </label>
            <input
              type="text"
              value={formData.nama}
              onChange={(e) => onFormDataChange({ ...formData, nama: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Kode Pengepul
            </label>
            <input
              type="text"
              value={formData.kode}
              onChange={(e) => onFormDataChange({ ...formData, kode: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              placeholder="Otomatis jika kosong"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Alamat *
            </label>
            <input
              type="text"
              value={formData.alamat}
              onChange={(e) => onFormDataChange({ ...formData, alamat: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Telepon *
            </label>
            <input
              type="tel"
              value={formData.telepon}
              onChange={(e) => onFormDataChange({ ...formData, telepon: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Harga per Kg *
            </label>
            <input
              type="number"
              value={formData.hargaPerKg}
              onChange={(e) => onFormDataChange({ ...formData, hargaPerKg: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Daftar Kode Petani *
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-48 overflow-y-auto border border-gray-300 rounded-lg p-3">
            {petaniList.map((petani) => (
              <label key={petani.id} className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.petaniTerkait.includes(petani.kode)}
                  onChange={() => handlePetaniSelection(petani.kode)}
                  className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                />
                <span className="text-sm">{petani.kode} - {petani.nama}</span>
              </label>
            ))}
          </div>
        </div>

        {selectedPetani.length > 0 && (
          <div>
            <h4 className="text-md font-semibold text-gray-800 mb-3">Preview Petani Terkait</h4>
            <div className="overflow-x-auto">
              <table className="w-full border border-gray-300 rounded-lg">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Kode Petani</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Nama Petani</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Harga per Kg</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Nama Pengepul</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {selectedPetani.map((petani) => (
                    <tr key={petani.id}>
                      <td className="px-4 py-2 text-sm font-medium text-gray-900">{petani.kode}</td>
                      <td className="px-4 py-2 text-sm text-gray-900">{petani.nama}</td>
                      <td className="px-4 py-2 text-sm text-gray-900">Rp {formData.hargaPerKg.toLocaleString()}</td>
                      <td className="px-4 py-2 text-sm text-gray-900">{formData.nama}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <div className="flex space-x-3">
          <button
            type="submit"
            className="bg-orange-600 text-white px-6 py-2 rounded-lg hover:bg-orange-700 transition-colors"
          >
            {editingPengepul ? 'Update' : 'Simpan'}
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-colors"
          >
            Batal
          </button>
        </div>
      </form>
    </div>
  );
};

export default PengepulForm;
