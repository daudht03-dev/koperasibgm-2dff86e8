
import React from 'react';
import { PanenData } from '../../types';
import PanenTabs from './PanenTabs';
import GenerateActions from './GenerateActions';
import DataDisplay from './DataDisplay';

interface PanenContainerProps {
  currentWeekData: PanenData[];
  currentSalesData: PanenData[];
  displayData: PanenData[];
  viewMode: 'panen' | 'penjualan';
  setViewMode: (mode: 'panen' | 'penjualan') => void;
  activeTab: 'serbuk' | 'cetak';
  setActiveTab: (tab: 'serbuk' | 'cetak') => void;
  tanggalMulai: string;
  dynamicColumns: string[];
  onGenerateNextWeek: () => void;
  onGenerateCatatanPenjualan: () => void;
  onResetDynamicColumns: () => void;
}

const PanenContainer: React.FC<PanenContainerProps> = ({
  currentWeekData,
  currentSalesData,
  displayData,
  viewMode,
  setViewMode,
  activeTab,
  setActiveTab,
  tanggalMulai,
  dynamicColumns,
  onGenerateNextWeek,
  onGenerateCatatanPenjualan,
  onResetDynamicColumns
}) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <PanenTabs activeTab={activeTab} setActiveTab={setActiveTab} />
      
      {/* Generate Actions */}
      <GenerateActions
        onGenerateNextWeek={onGenerateNextWeek}
        onGenerateCatatanPenjualan={onGenerateCatatanPenjualan}
        onResetDynamicColumns={onResetDynamicColumns}
        hasCurrentWeekData={currentWeekData.length > 0}
        activeTab={activeTab}
        hasDynamicColumns={dynamicColumns.length > 0}
      />

      {/* Data Display */}
      <DataDisplay
        currentWeekData={currentWeekData}
        currentSalesData={currentSalesData}
        displayData={displayData}
        viewMode={viewMode}
        setViewMode={setViewMode}
        activeTab={activeTab}
        tanggalMulai={tanggalMulai}
        dynamicColumns={dynamicColumns}
        onResetDynamicColumns={onResetDynamicColumns}
      />
    </div>
  );
};

export default PanenContainer;
