
import React from 'react';

interface ViewModeToggleProps {
  viewMode: 'panen' | 'penjualan';
  setViewMode: (mode: 'panen' | 'penjualan') => void;
}

const ViewModeToggle: React.FC<ViewModeToggleProps> = ({
  viewMode,
  setViewMode
}) => {
  return (
    <div className="flex bg-gray-100 rounded-lg p-1">
      <button
        onClick={() => setViewMode('panen')}
        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
          viewMode === 'panen' 
            ? 'bg-white text-gray-900 shadow-sm' 
            : 'text-gray-500 hover:text-gray-700'
        }`}
      >
        Data Panen
      </button>
      <button
        onClick={() => setViewMode('penjualan')}
        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
          viewMode === 'penjualan' 
            ? 'bg-white text-gray-900 shadow-sm' 
            : 'text-gray-500 hover:text-gray-700'
        }`}
      >
        Catatan Penjualan
      </button>
    </div>
  );
};

export default ViewModeToggle;
