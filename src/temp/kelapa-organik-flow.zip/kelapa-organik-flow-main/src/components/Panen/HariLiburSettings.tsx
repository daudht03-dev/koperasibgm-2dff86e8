
import React from 'react';
import { Settings } from 'lucide-react';
import { Petani } from '../../types';

interface HariLiburSettingsProps {
  selectedPetani: string[];
  petaniList: Petani[];
  hariLiburSettings: {[key: string]: number[]};
  setHariLiburSettings: (settings: {[key: string]: number[]}) => void;
  showSettings: boolean;
  setShowSettings: (show: boolean) => void;
}

const HariLiburSettings: React.FC<HariLiburSettingsProps> = ({
  selectedPetani,
  petaniList,
  hariLiburSettings,
  setHariLiburSettings,
  showSettings,
  setShowSettings
}) => {
  if (selectedPetani.length === 0) return null;

  return (
    <div className="mt-6">
      <button
        onClick={() => setShowSettings(!showSettings)}
        className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
      >
        <Settings className="w-4 h-4" />
        <span>Pengaturan Hari Libur (Opsional)</span>
      </button>
      
      {showSettings && (
        <div className="mt-4 p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600 mb-3">
            Jika tidak diatur, sistem akan generate hari libur secara otomatis dan acak
          </p>
          {selectedPetani.map(petaniId => {
            const petani = petaniList.find(p => p.id === petaniId);
            if (!petani) return null;
            
            return (
              <div key={petaniId} className="mb-3">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {petani.nama} ({petani.kode})
                </label>
                <div className="flex space-x-2">
                  {[1, 2, 3, 4, 5, 6, 7].map(hari => (
                    <label key={hari} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={hariLiburSettings[petaniId]?.includes(hari) || false}
                        onChange={(e) => {
                          const current = hariLiburSettings[petaniId] || [];
                          const updated = e.target.checked
                            ? [...current, hari]
                            : current.filter(h => h !== hari);
                          setHariLiburSettings({
                            ...hariLiburSettings,
                            [petaniId]: updated
                          });
                        }}
                        className="mr-1"
                      />
                      <span className="text-sm">H{hari}</span>
                    </label>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default HariLiburSettings;
