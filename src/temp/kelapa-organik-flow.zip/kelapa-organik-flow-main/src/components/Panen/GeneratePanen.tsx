
import React, { useState, useMemo } from 'react';
import PanenForm from './PanenForm';
import HariLiburSettings from './HariLiburSettings';
import PanenHeader from './PanenHeader';
import PanenContainer from './PanenContainer';
import { useDataContext } from '../../contexts/DataContext';
import { usePanenData } from '../../hooks/usePanenData';
import { usePanenGeneration } from '../../hooks/usePanenGeneration';

const GeneratePanen: React.FC = () => {
  const { petaniData, panenData: realtimePanenData, refreshData } = useDataContext();
  const [tanggalMulai, setTanggalMulai] = useState('');
  const [selectedPetani, setSelectedPetani] = useState<string[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [activeTab, setActiveTab] = useState<'serbuk' | 'cetak'>('serbuk');
  const [viewMode, setViewMode] = useState<'panen' | 'penjualan'>('panen');

  // Transform real-time data to component format
  const petaniList = useMemo(() => petaniData.map(item => ({
    id: item.id,
    nama: item.nama,
    kode: item.kode,
    alamat: item.alamat,
    telepon: item.telepon || '',
    rataRataPanen: item.rataRataPanen || 0,
    createdAt: item.createdAt
  })), [petaniData]);

  const {
    panenData,
    catatanPenjualanData,
    dynamicColumns,
    savePanenData,
    saveCatatanPenjualanData,
    saveDynamicColumns,
    resetAllData
  } = usePanenData();

  const {
    hariLiburSettings,
    setHariLiburSettings,
    handleGenerate,
    handleGenerateNextWeek,
    handleGenerateCatatanPenjualan,
    handleResetDynamicColumns
  } = usePanenGeneration({
    petaniList,
    panenData,
    savePanenData,
    saveCatatanPenjualanData,
    saveDynamicColumns,
    catatanPenjualanData,
    dynamicColumns,
    refreshData
  });

  const handleReset = async () => {
    if (confirm('Apakah Anda yakin ingin mereset semua data panen dan catatan penjualan?')) {
      try {
        await resetAllData();
        setHariLiburSettings({});
        alert('Data panen dan catatan penjualan berhasil direset!');
      } catch (error) {
        console.error('Error resetting data:', error);
        alert('Terjadi kesalahan saat mereset data. Silakan coba lagi.');
      }
    }
  };

  const getCurrentWeekData = () => {
    return panenData.filter(p => p.type === activeTab);
  };

  const getCurrentSalesData = () => {
    return catatanPenjualanData.filter(p => p.type === activeTab);
  };

  const getDisplayData = () => {
    return viewMode === 'panen' ? getCurrentWeekData() : getCurrentSalesData();
  };

  const onGenerate = () => handleGenerate(tanggalMulai, selectedPetani);
  const onGenerateNextWeek = () => handleGenerateNextWeek(tanggalMulai, selectedPetani, activeTab);
  const onGenerateCatatanPenjualan = () => handleGenerateCatatanPenjualan(activeTab);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <PanenHeader />

      {/* Form Generate */}
      <PanenForm
        tanggalMulai={tanggalMulai}
        setTanggalMulai={setTanggalMulai}
        selectedPetani={selectedPetani}
        setSelectedPetani={setSelectedPetani}
        petaniList={petaniList}
        onGenerate={onGenerate}
        onGenerateNextWeek={onGenerateNextWeek}
        onReset={handleReset}
        hasData={panenData.length > 0 || catatanPenjualanData.length > 0}
      />

      {/* Pengaturan Hari Libur */}
      <HariLiburSettings
        selectedPetani={selectedPetani}
        petaniList={petaniList}
        hariLiburSettings={hariLiburSettings}
        setHariLiburSettings={setHariLiburSettings}
        showSettings={showSettings}
        setShowSettings={setShowSettings}
      />

      {/* Hasil Generate */}
      {getCurrentWeekData().length > 0 && (
        <PanenContainer
          currentWeekData={getCurrentWeekData()}
          currentSalesData={getCurrentSalesData()}
          displayData={getDisplayData()}
          viewMode={viewMode}
          setViewMode={setViewMode}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          tanggalMulai={tanggalMulai}
          dynamicColumns={dynamicColumns}
          onGenerateNextWeek={onGenerateNextWeek}
          onGenerateCatatanPenjualan={onGenerateCatatanPenjualan}
          onResetDynamicColumns={handleResetDynamicColumns}
        />
      )}
    </div>
  );
};

export default GeneratePanen;
