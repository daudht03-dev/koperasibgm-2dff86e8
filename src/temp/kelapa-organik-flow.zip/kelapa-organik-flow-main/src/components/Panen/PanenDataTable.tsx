import React from 'react';
import { PanenData } from '../../types';

interface PanenDataTableProps {
  panenData: PanenData[];
  onResetDynamicColumns?: () => void;
}

const PanenDataTable: React.FC<PanenDataTableProps> = ({ 
  panenData, 
  onResetDynamicColumns 
}) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  // Fungsi untuk memformat angka dengan 1 desimal konsisten
  const formatNumber = (val: number): string => {
    return Number(val).toFixed(1);
  };

  // Group data by week
  const groupDataByWeek = () => {
    const weekGroups: { [week: number]: PanenData[] } = {};
    panenData.forEach(panen => {
      const week = panen.weekNumber || 1;
      if (!weekGroups[week]) weekGroups[week] = [];
      weekGroups[week].push(panen);
    });
    return weekGroups;
  };

  const getDateHeaders = (tanggalMulai: string) => {
    if (!tanggalMulai) return [];
    const headers = [];
    const startDate = new Date(tanggalMulai);
    
    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(startDate);
      currentDate.setDate(startDate.getDate() + i);
      headers.push(formatDate(currentDate.toISOString().split('T')[0]));
    }
    return headers;
  };

  const weekGroups = groupDataByWeek();
  const weeks = Object.keys(weekGroups).map(Number).sort();

  if (weeks.length === 0) {
    return (
      <div className="p-6 text-center text-gray-500">
        Belum ada data panen
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="overflow-x-auto" id="panen-data-table">
        {weeks.map((weekNumber, weekIndex) => {
          const weekData = weekGroups[weekNumber];
          if (!weekData || weekData.length === 0) return null;

          const dateHeaders = getDateHeaders(weekData[0].tanggalMulai);

          return (
            <div key={weekNumber} className={weekIndex > 0 ? 'mt-8' : ''}>
              {weekIndex > 0 && <div className="mb-4 border-t border-gray-300"></div>}
              
              <table className="w-full mb-6">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Kode Petani
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Nama Petani
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Rata-rata
                    </th>
                    {dateHeaders.map((date, index) => (
                      <th key={index} className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                        {date}
                      </th>
                    ))}
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                      Total
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Tgl Ambil
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {weekData.map((panen) => (
                    <tr key={panen.id} className="hover:bg-gray-50">
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                          {panen.kodePetani}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {panen.namaPetani}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatNumber(panen.rataRataPanen)}
                      </td>
                      
                      <td className={`px-4 py-4 whitespace-nowrap text-sm text-center ${panen.hariLibur.includes(1) ? 'bg-red-100 text-red-600' : 'text-gray-900'}`}>
                        {formatNumber(panen.hari1)}
                      </td>
                      <td className={`px-4 py-4 whitespace-nowrap text-sm text-center ${panen.hariLibur.includes(2) ? 'bg-red-100 text-red-600' : 'text-gray-900'}`}>
                        {formatNumber(panen.hari2)}
                      </td>
                      <td className={`px-4 py-4 whitespace-nowrap text-sm text-center ${panen.hariLibur.includes(3) ? 'bg-red-100 text-red-600' : 'text-gray-900'}`}>
                        {formatNumber(panen.hari3)}
                      </td>
                      <td className={`px-4 py-4 whitespace-nowrap text-sm text-center ${panen.hariLibur.includes(4) ? 'bg-red-100 text-red-600' : 'text-gray-900'}`}>
                        {formatNumber(panen.hari4)}
                      </td>
                      <td className={`px-4 py-4 whitespace-nowrap text-sm text-center ${panen.hariLibur.includes(5) ? 'bg-red-100 text-red-600' : 'text-gray-900'}`}>
                        {formatNumber(panen.hari5)}
                      </td>
                      <td className={`px-4 py-4 whitespace-nowrap text-sm text-center ${panen.hariLibur.includes(6) ? 'bg-red-100 text-red-600' : 'text-gray-900'}`}>
                        {formatNumber(panen.hari6)}
                      </td>
                      <td className={`px-4 py-4 whitespace-nowrap text-sm text-center ${panen.hariLibur.includes(7) ? 'bg-red-100 text-red-600' : 'text-gray-900'}`}>
                        {formatNumber(panen.hari7)}
                      </td>
                      
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-bold text-green-600 text-center">
                        {formatNumber(panen.totalPanen)}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatDate(panen.tanggalPengambilan)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PanenDataTable;