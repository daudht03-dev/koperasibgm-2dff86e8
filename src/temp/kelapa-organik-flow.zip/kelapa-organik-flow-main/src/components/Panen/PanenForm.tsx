
import React from 'react';
import { Calendar, Play, RotateCcw, Plus } from 'lucide-react';
import { Petani } from '../../types';

interface PanenFormProps {
  tanggalMulai: string;
  setTanggalMulai: (date: string) => void;
  selectedPetani: string[];
  setSelectedPetani: (petani: string[]) => void;
  petaniList: Petani[];
  onGenerate: () => void;
  onGenerateNextWeek: () => void;
  onReset: () => void;
  hasData: boolean;
}

const PanenForm: React.FC<PanenFormProps> = ({
  tanggalMulai,
  setTanggalMulai,
  selectedPetani,
  setSelectedPetani,
  petaniList,
  onGenerate,
  onGenerateNextWeek,
  onReset,
  hasData
}) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Pengaturan Generate Panen</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Tanggal Mulai */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tanggal Awal Panen *
          </label>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="date"
              value={tanggalMulai}
              onChange={(e) => setTanggalMulai(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              required
            />
          </div>
        </div>

        {/* Pilih Petani */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Pilih Petani *
          </label>
          <select
            multiple
            value={selectedPetani}
            onChange={(e) => {
              const selected = Array.from(e.target.selectedOptions, option => option.value);
              setSelectedPetani(selected);
            }}
            className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            size={5}
          >
            {petaniList.map(petani => (
              <option key={petani.id} value={petani.id}>
                {petani.kode} - {petani.nama} ({petani.rataRataPanen} kg/hari)
              </option>
            ))}
          </select>
          <p className="text-xs text-gray-500 mt-1">
            Gunakan Ctrl+Click untuk memilih multiple petani
          </p>
        </div>
      </div>

      {/* Tombol Generate */}
      <div className="mt-6 flex flex-wrap gap-3">
        <button
          onClick={onGenerate}
          disabled={!tanggalMulai || selectedPetani.length === 0}
          className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          <Play className="w-4 h-4" />
          <span>Generate Data Panen</span>
        </button>

        <button
          onClick={onGenerateNextWeek}
          disabled={!tanggalMulai || selectedPetani.length === 0}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" />
          <span>Generate Minggu Selanjutnya</span>
        </button>

        {hasData && (
          <button
            onClick={onReset}
            className="bg-red-600 text-white px-6 py-3 rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Semua Data</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default PanenForm;
