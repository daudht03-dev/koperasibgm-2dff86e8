
import React from 'react';
import { FileText, Plus, RotateCcw } from 'lucide-react';

interface GenerateActionsProps {
  onGenerateNextWeek: () => void;
  onGenerateCatatanPenjualan: () => void;
  onResetDynamicColumns?: () => void;
  hasCurrentWeekData: boolean;
  activeTab: 'serbuk' | 'cetak';
  hasDynamicColumns?: boolean;
}

const GenerateActions: React.FC<GenerateActionsProps> = ({
  onGenerateNextWeek,
  onGenerateCatatanPenjualan,
  onResetDynamicColumns,
  hasCurrentWeekData,
  activeTab,
  hasDynamicColumns = false
}) => {
  if (!hasCurrentWeekData) return null;

  return (
    <div className="px-6 pt-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <button
          onClick={onGenerateNextWeek}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Generate Minggu Selanjutnya</span>
        </button>
        
        <button
          onClick={onGenerateCatatanPenjualan}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <FileText className="w-4 h-4" />
          <span>Generate Catatan Penjualan</span>
        </button>

        {hasDynamicColumns && onResetDynamicColumns && (
          <button
            onClick={onResetDynamicColumns}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Header Minggu Berikutnya</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default GenerateActions;
