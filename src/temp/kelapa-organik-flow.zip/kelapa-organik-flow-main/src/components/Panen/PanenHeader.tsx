
import React from 'react';
import { Wheat } from 'lucide-react';

const PanenHeader: React.FC = () => {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <div className="p-3 bg-green-100 rounded-lg">
          <Wheat className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Generate Data Panen</h1>
          <p className="text-gray-600">Generate data panen otomatis untuk 7 hari</p>
        </div>
      </div>
    </div>
  );
};

export default PanenHeader;
