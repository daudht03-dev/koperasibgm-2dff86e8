
import React from 'react';
import { PanenData } from '../../types';
import PanenDataTable from './PanenDataTable';
import PanenExportActions from './PanenExportActions';
import CombinedExportActions from './CombinedExportActions';
import ViewModeToggle from './ViewModeToggle';

interface DataDisplayProps {
  currentWeekData: PanenData[];
  currentSalesData: PanenData[];
  displayData: PanenData[];
  viewMode: 'panen' | 'penjualan';
  setViewMode: (mode: 'panen' | 'penjualan') => void;
  activeTab: 'serbuk' | 'cetak';
  tanggalMulai: string;
  dynamicColumns: string[];
  onResetDynamicColumns?: () => void;
}

const DataDisplay: React.FC<DataDisplayProps> = ({
  currentWeekData,
  currentSalesData,
  displayData,
  viewMode,
  setViewMode,
  activeTab,
  tanggalMulai,
  dynamicColumns,
  onResetDynamicColumns
}) => {
  return (
    <>
      {/* View Mode Toggle */}
      <div className="px-6 pt-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <ViewModeToggle viewMode={viewMode} setViewMode={setViewMode} />
        </div>
      </div>

      {/* Combined Export Actions */}
      <div className="px-6 pt-4">
        <CombinedExportActions 
          panenData={currentWeekData}
          catatanPenjualanData={currentSalesData}
          activeTab={activeTab}
        />
      </div>

      {/* Regular Export Actions */}
      <div className="px-6 pt-2">
        <PanenExportActions 
          panenData={displayData} 
          activeTab={activeTab}
          isSalesNotes={viewMode === 'penjualan'}
        />
      </div>
      
      {/* Hidden Combined Print Content */}
      <div id="cetak-semua" style={{ display: 'none' }}>
        <div>
          <h3 className="text-lg font-bold mb-4">Data Panen {activeTab === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'}</h3>
          <PanenDataTable 
            panenData={currentWeekData}
          />
        </div>
        
        {currentSalesData.length > 0 && (
          <div>
            <hr className="my-6" />
            <h3 className="text-lg font-bold mb-4">=== Catatan Penjualan ===</h3>
            <PanenDataTable 
              panenData={currentSalesData}
            />
          </div>
        )}
      </div>
      
      <PanenDataTable 
        panenData={displayData}
        onResetDynamicColumns={viewMode === 'panen' ? onResetDynamicColumns : undefined}
      />
      
      {viewMode === 'penjualan' && currentSalesData.length === 0 && (
        <div className="px-6 pb-6">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-yellow-800 text-center">
              Belum ada catatan penjualan untuk {activeTab === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'}. 
              Klik tombol "Generate Catatan Penjualan" untuk membuat data.
            </p>
          </div>
        </div>
      )}
    </>
  );
};

export default DataDisplay;
