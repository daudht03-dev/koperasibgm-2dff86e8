import React, { useState } from 'react';
import { Printer, FileSpreadsheet, Download } from 'lucide-react';
import { Button } from '../ui/button';
import { PanenData } from '../../types';
import { printTable } from '../../utils/exportUtils';
import { exportCombinedToGoogleSheets, exportCombinedAsCSVBackup } from '../../utils/googleSheetsUtils';

interface CombinedExportActionsProps {
  panenData: PanenData[];
  catatanPenjualanData: PanenData[];
  activeTab: 'serbuk' | 'cetak';
}

const CombinedExportActions: React.FC<CombinedExportActionsProps> = ({ 
  panenData, 
  catatanPenjualanData,
  activeTab
}) => {
  const [isExporting, setIsExporting] = useState(false);

  const handlePrintSemua = () => {
    const content = document.getElementById('cetak-semua');
    if (!content) return;

    const title = `Data Lengkap ${activeTab === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'}`;
    
    const win = window.open('', '', 'width=1200,height=800');
    if (win) {
      win.document.write(`
        <html>
          <head>
            <title>${title}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              table { width: 100%; border-collapse: collapse; margin-top: 20px; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #f5f5f5; font-weight: bold; }
              .header { text-align: center; margin-bottom: 20px; }
              .print-date { text-align: right; font-size: 12px; color: #666; }
              hr { margin: 40px 0; border: 2px solid #ddd; }
              h3 { color: #333; margin: 20px 0; }
              @media print {
                body { margin: 0; }
                .no-print { display: none; }
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h2>${title}</h2>
            </div>
            <div class="print-date">
              Dicetak pada: ${new Date().toLocaleDateString('id-ID', { 
                day: '2-digit', 
                month: 'long', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </div>
            ${content.innerHTML}
          </body>
        </html>
      `);
      
      win.document.close();
      win.focus();
      win.print();
    }
  };

  const handleExportCombinedToGoogleSheets = async () => {
    if (panenData.length === 0 && catatanPenjualanData.length === 0) {
      alert('Tidak ada data untuk diekspor');
      return;
    }

    setIsExporting(true);

    try {
      const success = await exportCombinedToGoogleSheets(
        panenData, 
        catatanPenjualanData,
        activeTab
      );
      
      if (success) {
        alert('✅ Berhasil export data gabungan ke Google Sheets!');
      } else {
        alert('⚠️ Gagal export ke Google Sheets, akan download sebagai CSV...');
        exportCombinedAsCSVBackup(panenData, catatanPenjualanData, activeTab);
      }
    } catch (error) {
      alert('❌ Gagal export data. Silakan coba lagi.');
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCombinedCSV = () => {
    if (panenData.length === 0 && catatanPenjualanData.length === 0) {
      alert('Tidak ada data untuk diekspor');
      return;
    }

    exportCombinedAsCSVBackup(panenData, catatanPenjualanData, activeTab);
    alert('✅ File CSV gabungan berhasil didownload!');
  };

  const hasCombinedData = panenData.length > 0 || catatanPenjualanData.length > 0;

  return (
    <div className="flex space-x-3 mb-2 border-b border-gray-200 pb-4">
      <h4 className="text-sm font-medium text-gray-700 mr-4 self-center">Export Gabungan:</h4>
      
      <Button 
        onClick={handlePrintSemua}
        variant="outline"
        size="sm"
        className="flex items-center space-x-2"
        disabled={!hasCombinedData}
      >
        <Printer className="w-4 h-4" />
        <span>Print Semua</span>
      </Button>
      
      <Button 
        onClick={handleExportCombinedToGoogleSheets}
        variant="outline"
        size="sm"
        className="flex items-center space-x-2"
        disabled={isExporting || !hasCombinedData}
      >
        <FileSpreadsheet className="w-4 h-4" />
        <span>{isExporting ? 'Mengexport...' : 'Export Gabungan ke Google Sheets'}</span>
      </Button>

      <Button 
        onClick={handleExportCombinedCSV}
        variant="outline"
        size="sm"
        className="flex items-center space-x-2"
        disabled={!hasCombinedData}
      >
        <Download className="w-4 h-4" />
        <span>Download Gabungan CSV</span>
      </Button>
    </div>
  );
};

export default CombinedExportActions;