
import React from 'react';

interface PanenTabsProps {
  activeTab: 'serbuk' | 'cetak';
  setActiveTab: (tab: 'serbuk' | 'cetak') => void;
}

const PanenTabs: React.FC<PanenTabsProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="border-b border-gray-200">
      <nav className="flex space-x-8 px-6">
        <button
          onClick={() => setActiveTab('serbuk')}
          className={`py-4 px-1 border-b-2 font-medium text-sm ${
            activeTab === 'serbuk'
              ? 'border-green-500 text-green-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Data Gula Kelapa Serbuk
        </button>
        <button
          onClick={() => setActiveTab('cetak')}
          className={`py-4 px-1 border-b-2 font-medium text-sm ${
            activeTab === 'cetak'
              ? 'border-green-500 text-green-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Data Gula Kelapa Cetak
        </button>
      </nav>
    </div>
  );
};

export default PanenTabs;
