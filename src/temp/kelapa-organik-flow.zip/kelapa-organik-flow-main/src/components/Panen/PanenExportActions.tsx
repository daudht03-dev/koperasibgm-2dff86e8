import React, { useState } from 'react';
import { Printer, FileSpreadsheet, Download } from 'lucide-react';
import { Button } from '../ui/button';
import { PanenData } from '../../types';
import { printTable } from '../../utils/exportUtils';
import { exportToGoogleSheets, exportAsCSVBackup } from '../../utils/googleSheetsUtils';

interface PanenExportActionsProps {
  panenData: PanenData[];
  activeTab: 'serbuk' | 'cetak';
  isSalesNotes?: boolean;
}

const PanenExportActions: React.FC<PanenExportActionsProps> = ({ 
  panenData, 
  activeTab,
  isSalesNotes = false
}) => {
  const [isExporting, setIsExporting] = useState(false);

  const handlePrint = () => {
    const prefix = isSalesNotes ? 'Catatan Penjualan' : 'Data Panen';
    const title = `${prefix} ${activeTab === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'}`;
    printTable('panen-data-table', title);
  };

  const handleExportToGoogleSheets = async () => {
    if (panenData.length === 0) {
      alert('Tidak ada data untuk diekspor');
      return;
    }

    setIsExporting(true);

    try {
      const success = await exportToGoogleSheets(panenData, activeTab, isSalesNotes);
      
      if (success) {
        alert('✅ Berhasil export ke Google Sheets!');
      } else {
        // Fallback ke CSV jika Google Sheets gagal
        alert('⚠️ Gagal export ke Google Sheets, akan download sebagai CSV...');
        exportAsCSVBackup(panenData, activeTab, isSalesNotes);
      }
    } catch (error) {
      alert('❌ Gagal export data. Silakan coba lagi.');
      console.error('Export error:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportCSV = () => {
    if (panenData.length === 0) {
      alert('Tidak ada data untuk diekspor');
      return;
    }

    exportAsCSVBackup(panenData, activeTab, isSalesNotes);
    alert('✅ File CSV berhasil didownload!');
  };

  return (
    <div className="flex space-x-3 mb-4">
      <Button 
        onClick={handlePrint}
        variant="outline"
        size="sm"
        className="flex items-center space-x-2"
      >
        <Printer className="w-4 h-4" />
        <span>Print</span>
      </Button>
      
      <Button 
        onClick={handleExportToGoogleSheets}
        variant="outline"
        size="sm"
        className="flex items-center space-x-2"
        disabled={isExporting}
      >
        <FileSpreadsheet className="w-4 h-4" />
        <span>{isExporting ? 'Mengexport...' : 'Export ke Google Sheets'}</span>
      </Button>

      <Button 
        onClick={handleExportCSV}
        variant="outline"
        size="sm"
        className="flex items-center space-x-2"
      >
        <Download className="w-4 h-4" />
        <span>Download CSV</span>
      </Button>
    </div>
  );
};

export default PanenExportActions;