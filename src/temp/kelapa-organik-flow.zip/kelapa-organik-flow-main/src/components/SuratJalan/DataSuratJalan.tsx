import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Edit, Trash2, CheckCircle, XCircle, PackageCheck } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { LotPengovenan, SuratJalan } from '../../types';
import { useDataContext } from '../../contexts/DataContext';
import { useLotPengovenan } from '../../hooks/useLotPengovenan';

const DataSuratJalan: React.FC = () => {
  const { pengovenanData } = useDataContext();
  const [suratJalanList, setSuratJalanList] = useState<SuratJalan[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editSuratJalanId, setEditSuratJalanId] = useState<string | null>(null);
  
  // Transform pengovenan data to lot format
  const lotPengovenan = useMemo(() => pengovenanData.map(item => ({
    id: item.id,
    kodeLot: item.nomor_lot,
    namaLot: `${item.nama_petani} - ${item.jenis_gula}`,
    jumlahKering: item.setelah_kering || 0,
    tanggalProduksi: item.tanggal_pengovenan,
    status: 'aktif' as const
  })), [pengovenanData]);

  useEffect(() => {
    const savedSuratJalan = localStorage.getItem('suratJalanData');
    if (savedSuratJalan) {
      setSuratJalanList(JSON.parse(savedSuratJalan));
    }
  }, []);

  const [formData, setFormData] = useState({
    nomorSurat: '',
    tanggal: new Date().toISOString().split('T')[0],
    pengirim: '',
    penerima: '',
    alamatTujuan: '',
    driverName: '',
    vehicleNumber: '',
    items: [{ nama: '', jumlah: 0, satuan: '', kondisi: '' }]
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleItemChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => {
      const newItems = [...prevState.items];
      newItems[index][name] = value;
      return { ...prevState, items: newItems };
    });
  };

  const addItem = () => {
    setFormData(prevState => ({
      ...prevState,
      items: [...prevState.items, { nama: '', jumlah: 0, satuan: '', kondisi: '' }]
    }));
  };

  const removeItem = (index: number) => {
    setFormData(prevState => {
      const newItems = [...prevState.items];
      newItems.splice(index, 1);
      return { ...prevState, items: newItems };
    });
  };

  const generateSuratJalan = () => {
    const newSuratJalan: SuratJalan[] = lotPengovenan.map(lot => ({
      id: `sj-${lot.id}-${Date.now()}`,
      nomorSurat: `SJ-${lot.kodeLot}-${Date.now().toString().slice(-6)}`,
      tanggal: new Date().toISOString().split('T')[0],
      pengirim: 'PT. Kelapa Organik',
      penerima: 'Customer Default',
      alamatTujuan: 'Alamat Default',
      driverName: 'Driver Default',
      vehicleNumber: 'B 1234 XYZ',
      items: [{
        nama: lot.namaLot,
        jumlah: lot.jumlahKering,
        satuan: 'kg',
        kondisi: 'Baik'
      }],
      status: 'pending' as const,
      createdAt: new Date().toISOString()
    }));

    setSuratJalanList([...suratJalanList, ...newSuratJalan]);
    localStorage.setItem('suratJalanData', JSON.stringify([...suratJalanList, ...newSuratJalan]));
    alert('Surat jalan berhasil di-generate!');
  };

  const handleCreateSuratJalan = (formData: any) => {
    const newSuratJalan: SuratJalan = {
      id: Date.now().toString(),
      nomorSurat: formData.nomorSurat,
      tanggal: formData.tanggal,
      pengirim: formData.pengirim,
      penerima: formData.penerima,
      alamatTujuan: formData.alamatTujuan,
      driverName: formData.driverName,
      vehicleNumber: formData.vehicleNumber,
      items: formData.items.map((item: any) => ({
        nama: item.nama,
        jumlah: item.jumlah,
        satuan: item.satuan,
        kondisi: item.kondisi
      })),
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    setSuratJalanList([...suratJalanList, newSuratJalan]);
    localStorage.setItem('suratJalanData', JSON.stringify([...suratJalanList, newSuratJalan]));
    setIsCreating(false);
    setFormData({
      nomorSurat: '',
      tanggal: new Date().toISOString().split('T')[0],
      pengirim: '',
      penerima: '',
      alamatTujuan: '',
      driverName: '',
      vehicleNumber: '',
      items: [{ nama: '', jumlah: 0, satuan: '', kondisi: '' }]
    });
    alert('Surat jalan berhasil ditambahkan!');
  };

  const handleUpdateStatus = (id: string, newStatus: 'pending' | 'terkirim' | 'diterima') => {
    const updatedList = suratJalanList.map(sj =>
      sj.id === id ? { ...sj, status: newStatus } : sj
    );
    setSuratJalanList(updatedList);
    localStorage.setItem('suratJalanData', JSON.stringify(updatedList));
  };

  const handleDeleteSuratJalan = (id: string) => {
    if (confirm('Apakah Anda yakin ingin menghapus surat jalan ini?')) {
      const updatedList = suratJalanList.filter(sj => sj.id !== id);
      setSuratJalanList(updatedList);
      localStorage.setItem('suratJalanData', JSON.stringify(updatedList));
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'terkirim': return 'bg-blue-100 text-blue-800';
      case 'diterima': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Data Surat Jalan</h1>

      <div className="mb-4">
        <Button onClick={() => setIsCreating(true)} className="bg-green-500 text-white hover:bg-green-700">
          <Plus className="mr-2" /> Tambah Surat Jalan
        </Button>
        <Button onClick={generateSuratJalan} className="ml-2 bg-blue-500 text-white hover:bg-blue-700">
          Generate Surat Jalan
        </Button>
      </div>

      {isCreating && (
        <div className="mb-4">
          <h2 className="text-xl font-semibold mb-2">Tambah Surat Jalan Baru</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="nomorSurat">Nomor Surat</Label>
              <Input type="text" id="nomorSurat" name="nomorSurat" value={formData.nomorSurat} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="tanggal">Tanggal</Label>
              <Input type="date" id="tanggal" name="tanggal" value={formData.tanggal} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="pengirim">Pengirim</Label>
              <Input type="text" id="pengirim" name="pengirim" value={formData.pengirim} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="penerima">Penerima</Label>
              <Input type="text" id="penerima" name="penerima" value={formData.penerima} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="alamatTujuan">Alamat Tujuan</Label>
              <Input type="text" id="alamatTujuan" name="alamatTujuan" value={formData.alamatTujuan} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="driverName">Nama Driver</Label>
              <Input type="text" id="driverName" name="driverName" value={formData.driverName} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="vehicleNumber">Nomor Kendaraan</Label>
              <Input type="text" id="vehicleNumber" name="vehicleNumber" value={formData.vehicleNumber} onChange={handleInputChange} />
            </div>
          </div>

          <h3 className="text-lg font-semibold mt-4 mb-2">Items</h3>
          {formData.items.map((item, index) => (
            <div key={index} className="grid grid-cols-4 gap-4 mb-2">
              <div>
                <Label htmlFor={`nama-${index}`}>Nama</Label>
                <Input type="text" id={`nama-${index}`} name="nama" value={item.nama} onChange={(e) => handleItemChange(index, e)} />
              </div>
              <div>
                <Label htmlFor={`jumlah-${index}`}>Jumlah</Label>
                <Input type="number" id={`jumlah-${index}`} name="jumlah" value={item.jumlah} onChange={(e) => handleItemChange(index, e)} />
              </div>
              <div>
                <Label htmlFor={`satuan-${index}`}>Satuan</Label>
                <Input type="text" id={`satuan-${index}`} name="satuan" value={item.satuan} onChange={(e) => handleItemChange(index, e)} />
              </div>
              <div>
                <Label htmlFor={`kondisi-${index}`}>Kondisi</Label>
                <Input type="text" id={`kondisi-${index}`} name="kondisi" value={item.kondisi} onChange={(e) => handleItemChange(index, e)} />
              </div>
              <Button onClick={() => removeItem(index)} className="bg-red-500 text-white hover:bg-red-700">
                Hapus
              </Button>
            </div>
          ))}
          <Button onClick={addItem} className="mb-4">Tambah Item</Button>

          <Button onClick={() => handleCreateSuratJalan(formData)} className="bg-green-500 text-white hover:bg-green-700">
            Simpan Surat Jalan
          </Button>
          <Button onClick={() => setIsCreating(false)} className="ml-2">
            Batal
          </Button>
        </div>
      )}

      <Table>
        <TableCaption>A list of your recent surat jalan.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">Nomor Surat</TableHead>
            <TableHead>Tanggal</TableHead>
            <TableHead>Penerima</TableHead>
            <TableHead>Alamat Tujuan</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {suratJalanList.map((suratJalan) => (
            <TableRow key={suratJalan.id}>
              <TableCell className="font-medium">{suratJalan.nomorSurat}</TableCell>
              <TableCell>{suratJalan.tanggal}</TableCell>
              <TableCell>{suratJalan.penerima}</TableCell>
              <TableCell>{suratJalan.alamatTujuan}</TableCell>
              <TableCell>
                <div className={`rounded-full px-3 py-1 font-semibold text-sm ${getStatusColor(suratJalan.status)}`}>
                  {suratJalan.status}
                </div>
              </TableCell>
              <TableCell className="text-right">
                <Select onValueChange={(value) => handleUpdateStatus(suratJalan.id, value as 'pending' | 'terkirim' | 'diterima')}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Update Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="terkirim">Terkirim</SelectItem>
                    <SelectItem value="diterima">Diterima</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="ghost">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Button>
                <Button variant="ghost" onClick={() => handleDeleteSuratJalan(suratJalan.id)}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default DataSuratJalan;
