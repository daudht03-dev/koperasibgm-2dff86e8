import { supabase } from '@/integrations/supabase/client';

export interface GeneratedBahanBaku {
  id: string;
  petaniId: string;
  pengepulId: string;
  kodePetani: string;
  namaPetani: string;
  namaPengepul: string;
  jumlahMasuk: number;
  tanggalMasuk: string;
  type: 'serbuk' | 'cetak';
  noLot: string;
  totalPerPengepul: number;
  totalKeseluruhan: number;
  createdAt?: string;
}

interface SupabaseBahanBaku {
  id: string;
  petani_id: string;
  pengepul_id: string;
  kode_petani: string;
  nama_petani: string;
  nama_pengepul: string;
  jumlah_masuk: number;
  tanggal_masuk: string;
  type: string;
  no_lot: string;
  total_per_pengepul: number;
  total_keseluruhan: number;
  created_at: string;
  updated_at: string;
}

export class BahanBakuService {
  static async getAllBahanBaku(): Promise<GeneratedBahanBaku[]> {
    try {
      const { data, error } = await (supabase as any)
        .from('data_bahan_baku')
        .select('*')
        .order('tanggal_masuk', { ascending: false });

      if (error) throw error;

      return data.map((item: SupabaseBahanBaku) => this.transformFromSupabase(item));
    } catch (error) {
      console.error('Error fetching bahan baku data:', error);
      throw error;
    }
  }

  static async saveBahanBaku(bahanBakuData: GeneratedBahanBaku[]): Promise<void> {
    try {
      // Delete all existing records first
      await this.deleteAllBahanBaku();

      // Insert new records
      const supabaseData = bahanBakuData.map(item => this.transformToSupabase(item));
      
      const { error } = await (supabase as any)
        .from('data_bahan_baku')
        .insert(supabaseData);

      if (error) throw error;
    } catch (error) {
      console.error('Error saving bahan baku data:', error);
      throw error;
    }
  }

  static async deleteAllBahanBaku(): Promise<void> {
    try {
      const { error } = await (supabase as any)
        .from('data_bahan_baku')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all records

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting bahan baku data:', error);
      throw error;
    }
  }

  private static transformFromSupabase(item: SupabaseBahanBaku): GeneratedBahanBaku {
    return {
      id: item.id,
      petaniId: item.petani_id,
      pengepulId: item.pengepul_id,
      kodePetani: item.kode_petani,
      namaPetani: item.nama_petani,
      namaPengepul: item.nama_pengepul,
      jumlahMasuk: Number(item.jumlah_masuk),
      tanggalMasuk: item.tanggal_masuk,
      type: item.type as 'serbuk' | 'cetak',
      noLot: item.no_lot,
      totalPerPengepul: Number(item.total_per_pengepul),
      totalKeseluruhan: Number(item.total_keseluruhan),
      createdAt: item.created_at
    };
  }

  private static transformToSupabase(item: GeneratedBahanBaku): any {
    return {
      id: item.id,
      petani_id: item.petaniId,
      pengepul_id: item.pengepulId,
      kode_petani: item.kodePetani,
      nama_petani: item.namaPetani,
      nama_pengepul: item.namaPengepul,
      jumlah_masuk: item.jumlahMasuk,
      tanggal_masuk: item.tanggalMasuk,
      type: item.type,
      no_lot: item.noLot,
      total_per_pengepul: item.totalPerPengepul,
      total_keseluruhan: item.totalKeseluruhan
    };
  }
}