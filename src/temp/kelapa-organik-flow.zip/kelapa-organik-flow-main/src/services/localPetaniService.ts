import { localDB, LocalPetani, generateId, getCurrentTimestamp } from '@/lib/localDatabase';
import { Petani } from '@/types';

export class LocalPetaniService {
  static async getAllPetani(): Promise<Petani[]> {
    try {
      const data = await localDB.petani.orderBy('namaPetani').toArray();
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching petani data:', error);
      throw error;
    }
  }

  static async addPetani(petaniData: Omit<Petani, 'id' | 'createdAt'>): Promise<Petani> {
    try {
      // Check for duplicate kode_petani
      const existing = await localDB.petani.where('kodePetani').equals(petaniData.kode).first();
      if (existing) {
        throw new Error(`Kode petani "${petaniData.kode}" sudah ada. Gunakan kode yang berbeda.`);
      }

      const id = generateId();
      const timestamp = getCurrentTimestamp();
      
      const newPetani: LocalPetani = {
        id,
        kodePetani: petaniData.kode,
        namaPetani: petaniData.nama,
        alamat: petaniData.alamat,
        nomorTelepon: petaniData.telepon,
        rataRataPanen: petaniData.rataRataPanen,
        createdAt: timestamp,
        updatedAt: timestamp
      };

      await localDB.petani.add(newPetani);
      return this.transformFromLocal(newPetani);
    } catch (error) {
      console.error('Error adding petani:', error);
      throw error;
    }
  }

  static async updatePetani(id: string, petaniData: Omit<Petani, 'id' | 'createdAt'>): Promise<void> {
    try {
      // Check for duplicate kode_petani (excluding current record)
      const existing = await localDB.petani.where('kodePetani').equals(petaniData.kode).and(item => item.id !== id).first();
      if (existing) {
        throw new Error(`Kode petani "${petaniData.kode}" sudah ada. Gunakan kode yang berbeda.`);
      }

      const timestamp = getCurrentTimestamp();
      
      await localDB.petani.update(id, {
        kodePetani: petaniData.kode,
        namaPetani: petaniData.nama,
        alamat: petaniData.alamat,
        nomorTelepon: petaniData.telepon,
        rataRataPanen: petaniData.rataRataPanen,
        updatedAt: timestamp
      });
    } catch (error) {
      console.error('Error updating petani:', error);
      throw error;
    }
  }

  static async deletePetani(id: string): Promise<void> {
    try {
      await localDB.petani.delete(id);
    } catch (error) {
      console.error('Error deleting petani:', error);
      throw error;
    }
  }

  private static transformFromLocal(item: LocalPetani): Petani {
    return {
      id: item.id,
      kode: item.kodePetani,
      nama: item.namaPetani,
      alamat: item.alamat,
      telepon: item.nomorTelepon || '',
      rataRataPanen: item.rataRataPanen || 0,
      createdAt: item.createdAt
    };
  }
}