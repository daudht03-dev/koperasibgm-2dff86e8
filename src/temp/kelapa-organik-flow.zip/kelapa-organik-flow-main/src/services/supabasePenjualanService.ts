import { supabase } from '@/integrations/supabase/client';
import { Penjualan } from '../types';

export class SupabasePenjualanService {
  static async getAllPenjualan(): Promise<Penjualan[]> {
    const { data, error } = await supabase
      .from('penjualan')
      .select('*')
      .order('tanggal_jual', { ascending: false });

    if (error) throw error;

    return (data || []).map(this.transformFromSupabase);
  }

  static async savePenjualan(penjualanData: Penjualan[]): Promise<void> {
    // Delete existing records
    await supabase
      .from('penjualan')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (penjualanData.length === 0) return;

    // Transform and insert new data
    const transformedData = penjualanData.map(this.transformToSupabase);
    
    const { error } = await supabase
      .from('penjualan')
      .insert(transformedData);

    if (error) throw error;
  }

  static async deleteAllPenjualan(): Promise<void> {
    const { error } = await supabase
      .from('penjualan')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (error) throw error;
  }

  static async deletePenjualan(id: string): Promise<void> {
    const { error } = await supabase
      .from('penjualan')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }

  private static transformFromSupabase(item: any): Penjualan {
    return {
      id: item.id,
      petaniId: item.petani_id || '',
      pengepulId: item.pengepul_id || '',
      kodePetani: item.kode_petani,
      namaPetani: item.nama_petani,
      namaPengepul: item.nama_pengepul,
      jumlahJual: item.jumlah_jual || 0,
      hargaPerKg: item.harga_per_kg || 0,
      totalHarga: item.total_harga || 0,
      tanggalJual: item.tanggal_jual,
      type: item.type as 'serbuk' | 'cetak',
      metodePembayaran: item.metode_pembayaran as 'tunai' | 'transfer' | 'tempo',
      statusPembayaran: item.status_pembayaran as 'lunas' | 'belum_lunas',
      tanggalJatuhTempo: item.tanggal_jatuh_tempo || undefined,
      keterangan: item.keterangan || undefined,
      createdAt: item.created_at
    };
  }

  private static transformToSupabase(item: Penjualan): any {
    return {
      petani_id: item.petaniId || null,
      pengepul_id: item.pengepulId || null,
      kode_petani: item.kodePetani,
      nama_petani: item.namaPetani,
      nama_pengepul: item.namaPengepul,
      jumlah_jual: item.jumlahJual,
      harga_per_kg: item.hargaPerKg,
      total_harga: item.totalHarga,
      tanggal_jual: item.tanggalJual,
      type: item.type,
      metode_pembayaran: item.metodePembayaran,
      status_pembayaran: item.statusPembayaran,
      tanggal_jatuh_tempo: item.tanggalJatuhTempo || null,
      keterangan: item.keterangan || null
    };
  }
}
