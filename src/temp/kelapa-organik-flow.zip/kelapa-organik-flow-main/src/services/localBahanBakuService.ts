import { localDB, LocalBahanBaku, generateId, getCurrentTimestamp } from '@/lib/localDatabase';

export interface GeneratedBahanBaku {
  id: string;
  petaniId: string;
  pengepulId: string;
  kodePetani: string;
  namaPetani: string;
  namaPengepul: string;
  jumlahMasuk: number;
  tanggalMasuk: string;
  type: 'serbuk' | 'cetak';
  noLot: string;
  totalPerPengepul: number;
  totalKeseluruhan: number;
  createdAt?: string;
}

export class LocalBahanBakuService {
  static async getAllBahanBaku(): Promise<GeneratedBahanBaku[]> {
    try {
      const data = await localDB.bahanBaku.orderBy('tanggalMasuk').reverse().toArray();
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching bahan baku data:', error);
      throw error;
    }
  }

  static async saveBahanBaku(bahanBakuData: GeneratedBahanBaku[]): Promise<void> {
    try {
      // Clear existing data
      await this.deleteAllBahanBaku();

      // Insert new data
      const localData = bahanBakuData.map(item => this.transformToLocal(item));
      await localDB.bahanBaku.bulkAdd(localData);
    } catch (error) {
      console.error('Error saving bahan baku data:', error);
      throw error;
    }
  }

  static async deleteAllBahanBaku(): Promise<void> {
    try {
      await localDB.bahanBaku.clear();
    } catch (error) {
      console.error('Error deleting bahan baku data:', error);
      throw error;
    }
  }

  private static transformFromLocal(item: LocalBahanBaku): GeneratedBahanBaku {
    return {
      id: item.id,
      petaniId: item.petaniId,
      pengepulId: item.pengepulId,
      kodePetani: item.kodePetani,
      namaPetani: item.namaPetani,
      namaPengepul: item.namaPengepul,
      jumlahMasuk: item.jumlahMasuk,
      tanggalMasuk: item.tanggalMasuk,
      type: item.type,
      noLot: item.noLot,
      totalPerPengepul: item.totalPerPengepul,
      totalKeseluruhan: item.totalKeseluruhan,
      createdAt: item.createdAt
    };
  }

  private static transformToLocal(item: GeneratedBahanBaku): LocalBahanBaku {
    return {
      id: item.id,
      petaniId: item.petaniId,
      pengepulId: item.pengepulId,
      kodePetani: item.kodePetani,
      namaPetani: item.namaPetani,
      namaPengepul: item.namaPengepul,
      jumlahMasuk: item.jumlahMasuk,
      tanggalMasuk: item.tanggalMasuk,
      type: item.type,
      noLot: item.noLot,
      totalPerPengepul: item.totalPerPengepul,
      totalKeseluruhan: item.totalKeseluruhan,
      createdAt: item.createdAt || getCurrentTimestamp()
    };
  }
}