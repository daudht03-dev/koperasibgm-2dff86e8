import { localDB, LocalPanenData, generateId, getCurrentTimestamp } from '@/lib/localDatabase';
import { PanenData } from '@/types';

export class LocalCatatanPenjualanService {
  static async getAllCatatanPenjualan(): Promise<PanenData[]> {
    try {
      const data = await localDB.catatanPenjualan.orderBy('tanggalMulai').reverse().toArray();
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching catatan penjualan data:', error);
      throw error;
    }
  }

  static async getCatatanPenjualanByType(type: 'serbuk' | 'cetak'): Promise<PanenData[]> {
    try {
      const data = await localDB.catatanPenjualan
        .where('jenisPanen')
        .equals(type)
        .reverse()
        .sortBy('tanggalMulai');
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching catatan penjualan by type:', error);
      throw error;
    }
  }

  static async saveCatatanPenjualan(catatanData: PanenData[]): Promise<void> {
    try {
      // Clear existing data
      await this.deleteAllCatatanPenjualan();

      // Insert new data
      const localData = catatanData.map(item => this.transformToLocal(item));
      await localDB.catatanPenjualan.bulkAdd(localData);
    } catch (error) {
      console.error('Error saving catatan penjualan data:', error);
      throw error;
    }
  }

  static async deleteAllCatatanPenjualan(): Promise<void> {
    try {
      await localDB.catatanPenjualan.clear();
    } catch (error) {
      console.error('Error deleting catatan penjualan data:', error);
      throw error;
    }
  }

  private static transformFromLocal(item: LocalPanenData): PanenData {
    return {
      id: item.id,
      petaniId: item.petaniId,
      kodePetani: item.kodePetani,
      namaPetani: item.namaPetani,
      rataRataPanen: item.rataRataPanen,
      tanggalMulai: item.tanggalMulai,
      hari1: item.hari1,
      hari2: item.hari2,
      hari3: item.hari3,
      hari4: item.hari4,
      hari5: item.hari5,
      hari6: item.hari6,
      hari7: item.hari7,
      totalPanen: item.totalPanen,
      tanggalPengambilan: item.tanggalPengambilan,
      hariLibur: item.hariLibur,
      weekNumber: item.weekNumber,
      dynamicData: item.dynamicData,
      dynamicHariLibur: item.dynamicHariLibur,
      type: item.jenisPanen
    };
  }

  private static transformToLocal(item: PanenData): LocalPanenData {
    return {
      id: item.id,
      petaniId: item.petaniId,
      kodePetani: item.kodePetani,
      namaPetani: item.namaPetani,
      rataRataPanen: item.rataRataPanen,
      tanggalMulai: item.tanggalMulai,
      hari1: item.hari1,
      hari2: item.hari2,
      hari3: item.hari3,
      hari4: item.hari4,
      hari5: item.hari5,
      hari6: item.hari6,
      hari7: item.hari7,
      totalPanen: item.totalPanen,
      tanggalPengambilan: item.tanggalPengambilan,
      hariLibur: item.hariLibur,
      weekNumber: item.weekNumber,
      dynamicData: item.dynamicData,
      dynamicHariLibur: item.dynamicHariLibur,
      jenisPanen: item.type,
      createdAt: getCurrentTimestamp(),
      updatedAt: getCurrentTimestamp()
    };
  }
}