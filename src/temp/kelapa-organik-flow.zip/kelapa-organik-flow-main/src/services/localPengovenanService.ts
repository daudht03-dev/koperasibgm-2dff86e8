import { localDB, LocalPengovenan, generateId, getCurrentTimestamp } from '@/lib/localDatabase';
import { PengovenanData } from '@/types/pengovenan';

export class LocalPengovenanService {
  static async savePengovenan(data: Omit<PengovenanData, 'id' | 'created_at' | 'updated_at'>[]): Promise<PengovenanData[]> {
    try {
      const localData = data.map(item => this.transformToLocal(item));
      await localDB.pengovenan.bulkAdd(localData);
      
      // Return the saved data
      return localData.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error saving pengovenan data:', error);
      throw error;
    }
  }

  static async getAllPengovenan(): Promise<PengovenanData[]> {
    try {
      const data = await localDB.pengovenan.orderBy('createdAt').reverse().toArray();
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching pengovenan data:', error);
      throw error;
    }
  }

  static async deletePengovenan(id: string): Promise<void> {
    try {
      await localDB.pengovenan.delete(id);
    } catch (error) {
      console.error('Error deleting pengovenan record:', error);
      throw error;
    }
  }

  static async getPengovenanByDateRange(startDate: string, endDate: string): Promise<PengovenanData[]> {
    try {
      const data = await localDB.pengovenan
        .where('tanggalPengovenan')
        .between(startDate, endDate, true, true)
        .toArray();
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching pengovenan by date range:', error);
      throw error;
    }
  }

  static getPublicEndpointUrl(): string {
    // For local storage, we can't provide a public endpoint URL
    // Return a placeholder or implement export functionality differently
    return 'local://pengovenan-data';
  }

  static convertToExcelCSV(data: PengovenanData[]): string {
    const headers = [
      'Tanggal Pengovenan',
      'Tanggal Bahan Baku',
      'Batch Number',
      'Jumlah Bahan Baku (kg)',
      'Susut (%)',
      'QC Off (%)',
      'Setelah Kering (kg)',
      'Nomor Lot',
      'Kode Petani',
      'Nama Petani',
      'Jenis Gula'
    ];

    const csvContent = [
      headers.join(','),
      ...data.map(row => [
        row.tanggal_pengovenan,
        row.tanggal_bahan_baku,
        row.batch_number,
        row.jumlah_bahan_baku,
        row.susut,
        row.qc_off,
        row.setelah_kering,
        row.nomor_lot,
        row.kode_petani,
        row.nama_petani,
        row.jenis_gula
      ].join(','))
    ].join('\n');

    return csvContent;
  }

  private static transformFromLocal(item: LocalPengovenan): PengovenanData {
    return {
      id: item.id,
      tanggal_pengovenan: item.tanggalPengovenan,
      tanggal_bahan_baku: item.tanggalBahanBaku,
      batch_number: item.batchNumber,
      jumlah_bahan_baku: item.jumlahBahanBaku,
      susut: item.susut,
      qc_off: item.qcOff,
      setelah_kering: item.setelahKering,
      nomor_lot: item.nomorLot,
      kode_petani: item.kodePetani,
      nama_petani: item.namaPetani,
      jenis_gula: item.jenisGula,
      created_at: item.createdAt,
      updated_at: item.updatedAt
    };
  }

  private static transformToLocal(item: Omit<PengovenanData, 'id' | 'created_at' | 'updated_at'>): LocalPengovenan {
    const timestamp = getCurrentTimestamp();
    return {
      id: generateId(),
      tanggalPengovenan: item.tanggal_pengovenan,
      tanggalBahanBaku: item.tanggal_bahan_baku,
      batchNumber: item.batch_number,
      jumlahBahanBaku: item.jumlah_bahan_baku,
      susut: item.susut,
      qcOff: item.qc_off,
      setelahKering: item.setelah_kering,
      nomorLot: item.nomor_lot,
      kodePetani: item.kode_petani,
      namaPetani: item.nama_petani,
      jenisGula: item.jenis_gula,
      createdAt: timestamp,
      updatedAt: timestamp
    };
  }
}