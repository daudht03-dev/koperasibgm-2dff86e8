import { supabase } from '@/integrations/supabase/client';
import { PanenData } from '../types';
import { Json } from '@/integrations/supabase/types';

export class DataPanenService {
  static async getAllDataPanen(): Promise<PanenData[]> {
    const { data, error } = await supabase
      .from('data_panen')
      .select('*')
      .order('tanggal_mulai', { ascending: false });

    if (error) throw error;

    return (data || []).map(this.transformFromSupabase);
  }

  static async getDataPanenByType(type: 'serbuk' | 'cetak'): Promise<PanenData[]> {
    const { data, error } = await supabase
      .from('data_panen')
      .select('*')
      .eq('type', type)
      .order('tanggal_mulai', { ascending: false });

    if (error) throw error;

    return (data || []).map(this.transformFromSupabase);
  }

  static async saveDataPanen(panenData: PanenData[]): Promise<void> {
    // Delete existing records
    await supabase
      .from('data_panen')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (panenData.length === 0) return;

    // Transform and insert new data
    const transformedData = panenData.map(this.transformToSupabase);
    
    const { error } = await supabase
      .from('data_panen')
      .insert(transformedData);

    if (error) throw error;
  }

  static async deleteAllDataPanen(): Promise<void> {
    const { error } = await supabase
      .from('data_panen')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');

    if (error) throw error;
  }

  private static transformFromSupabase(item: any): PanenData {
    return {
      id: item.id,
      petaniId: item.petani_id || '',
      kodePetani: item.kode_petani,
      namaPetani: item.nama_petani,
      rataRataPanen: item.rata_rata_panen || 0,
      tanggalMulai: item.tanggal_mulai,
      hari1: item.hari1 || 0,
      hari2: item.hari2 || 0,
      hari3: item.hari3 || 0,
      hari4: item.hari4 || 0,
      hari5: item.hari5 || 0,
      hari6: item.hari6 || 0,
      hari7: item.hari7 || 0,
      totalPanen: item.total_panen || 0,
      tanggalPengambilan: item.tanggal_pengambilan || '',
      hariLibur: item.hari_libur || [],
      type: item.type as 'serbuk' | 'cetak',
      weekNumber: item.week_number,
      dynamicData: item.dynamic_data as { [date: string]: number } | undefined,
      dynamicHariLibur: item.dynamic_hari_libur as { [date: string]: boolean } | undefined
    };
  }

  private static transformToSupabase(item: PanenData): any {
    return {
      petani_id: item.petaniId || null,
      kode_petani: item.kodePetani,
      nama_petani: item.namaPetani,
      rata_rata_panen: item.rataRataPanen,
      tanggal_mulai: item.tanggalMulai,
      hari1: item.hari1,
      hari2: item.hari2,
      hari3: item.hari3,
      hari4: item.hari4,
      hari5: item.hari5,
      hari6: item.hari6,
      hari7: item.hari7,
      total_panen: item.totalPanen,
      tanggal_pengambilan: item.tanggalPengambilan || null,
      hari_libur: item.hariLibur || [],
      week_number: item.weekNumber || null,
      dynamic_data: (item.dynamicData || {}) as Json,
      dynamic_hari_libur: (item.dynamicHariLibur || {}) as Json,
      type: item.type
    };
  }
}
