import { localDB, LocalPengepul, generateId, getCurrentTimestamp } from '@/lib/localDatabase';
import { Pengepul } from '@/types';

export class LocalPengepulService {
  static async getAllPengepul(): Promise<Pengepul[]> {
    try {
      const data = await localDB.pengepul.orderBy('namaPengepul').toArray();
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching pengepul data:', error);
      throw error;
    }
  }

  static async addPengepul(pengepulData: Omit<Pengepul, 'id' | 'createdAt'>): Promise<Pengepul> {
    try {
      // Check for duplicate kode_pengepul
      const existing = await localDB.pengepul.where('kodePengepul').equals(pengepulData.kode).first();
      if (existing) {
        throw new Error(`Kode pengepul "${pengepulData.kode}" sudah ada. Gunakan kode yang berbeda.`);
      }

      const id = generateId();
      const timestamp = getCurrentTimestamp();
      
      const newPengepul: LocalPengepul = {
        id,
        kodePengepul: pengepulData.kode,
        namaPengepul: pengepulData.nama,
        alamat: pengepulData.alamat,
        nomorTelepon: pengepulData.telepon,
        petaniKodes: pengepulData.petaniTerkait || [],
        harga: [pengepulData.hargaPerKg],
        createdAt: timestamp,
        updatedAt: timestamp
      };

      await localDB.pengepul.add(newPengepul);
      return this.transformFromLocal(newPengepul);
    } catch (error) {
      console.error('Error adding pengepul:', error);
      throw error;
    }
  }

  static async updatePengepul(id: string, pengepulData: Omit<Pengepul, 'id' | 'createdAt'>): Promise<void> {
    try {
      // Check for duplicate kode_pengepul (excluding current record)
      const existing = await localDB.pengepul.where('kodePengepul').equals(pengepulData.kode).and(item => item.id !== id).first();
      if (existing) {
        throw new Error(`Kode pengepul "${pengepulData.kode}" sudah ada. Gunakan kode yang berbeda.`);
      }

      const timestamp = getCurrentTimestamp();
      
      await localDB.pengepul.update(id, {
        kodePengepul: pengepulData.kode,
        namaPengepul: pengepulData.nama,
        alamat: pengepulData.alamat,
        nomorTelepon: pengepulData.telepon,
        petaniKodes: pengepulData.petaniTerkait || [],
        harga: [pengepulData.hargaPerKg],
        updatedAt: timestamp
      });
    } catch (error) {
      console.error('Error updating pengepul:', error);
      throw error;
    }
  }

  static async deletePengepul(id: string): Promise<void> {
    try {
      await localDB.pengepul.delete(id);
    } catch (error) {
      console.error('Error deleting pengepul:', error);
      throw error;
    }
  }

  private static transformFromLocal(item: LocalPengepul): Pengepul {
    return {
      id: item.id,
      kode: item.kodePengepul,
      nama: item.namaPengepul,
      alamat: item.alamat,
      telepon: item.nomorTelepon || '',
      hargaPerKg: item.harga?.[0] || 0,
      petaniTerkait: item.petaniKodes || [],
      createdAt: item.createdAt
    };
  }
}