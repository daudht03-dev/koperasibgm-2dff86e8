import { supabase } from '@/integrations/supabase/client';
import { Petani } from '../types';

export class SupabasePetaniService {
  static async getAllPetani(): Promise<Petani[]> {
    const { data, error } = await supabase
      .from('petani')
      .select('*')
      .order('nama', { ascending: true });

    if (error) throw error;

    return (data || []).map(item => ({
      id: item.id,
      kode: item.kode,
      nama: item.nama,
      alamat: item.alamat,
      telepon: item.telepon,
      rataRataPanen: item.rata_rata_panen || 0,
      createdAt: item.created_at
    }));
  }

  static async addPetani(petaniData: Omit<Petani, 'id' | 'createdAt'>): Promise<Petani> {
    // Check for duplicate kode
    const { data: existing } = await supabase
      .from('petani')
      .select('id')
      .eq('kode', petaniData.kode)
      .maybeSingle();

    if (existing) {
      throw new Error(`Kode petani "${petaniData.kode}" sudah ada. Gunakan kode yang berbeda.`);
    }

    const { data, error } = await supabase
      .from('petani')
      .insert({
        kode: petaniData.kode,
        nama: petaniData.nama,
        alamat: petaniData.alamat,
        telepon: petaniData.telepon,
        rata_rata_panen: petaniData.rataRataPanen
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      kode: data.kode,
      nama: data.nama,
      alamat: data.alamat,
      telepon: data.telepon,
      rataRataPanen: data.rata_rata_panen || 0,
      createdAt: data.created_at
    };
  }

  static async updatePetani(id: string, petaniData: Omit<Petani, 'id' | 'createdAt'>): Promise<void> {
    // Check for duplicate kode (excluding current record)
    const { data: existing } = await supabase
      .from('petani')
      .select('id')
      .eq('kode', petaniData.kode)
      .neq('id', id)
      .maybeSingle();

    if (existing) {
      throw new Error(`Kode petani "${petaniData.kode}" sudah ada. Gunakan kode yang berbeda.`);
    }

    const { error } = await supabase
      .from('petani')
      .update({
        kode: petaniData.kode,
        nama: petaniData.nama,
        alamat: petaniData.alamat,
        telepon: petaniData.telepon,
        rata_rata_panen: petaniData.rataRataPanen
      })
      .eq('id', id);

    if (error) throw error;
  }

  static async deletePetani(id: string): Promise<void> {
    const { error } = await supabase
      .from('petani')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
}
