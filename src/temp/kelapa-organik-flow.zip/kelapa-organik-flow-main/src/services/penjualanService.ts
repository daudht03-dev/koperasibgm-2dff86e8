import { supabase } from '@/integrations/supabase/client';
import { Penjualan } from '../types';

interface SupabasePenjualan {
  id: string;
  petani_id: string;
  pengepul_id: string;
  kode_petani: string;
  nama_petani: string;
  nama_pengepul: string;
  jumlah_jual: number;
  harga_per_kg: number;
  total_harga: number;
  tanggal_jual: string;
  type: string;
  metode_pembayaran: string;
  status_pembayaran: string;
  tanggal_jatuh_tempo: string | null;
  keterangan: string | null;
  created_at: string;
  updated_at: string;
}

export class PenjualanService {
  static async getAllPenjualan(): Promise<Penjualan[]> {
    try {
      const { data, error } = await (supabase as any)
        .from('data_penjualan')
        .select('*')
        .order('tanggal_jual', { ascending: false });

      if (error) throw error;

      return data.map((item: SupabasePenjualan) => this.transformFromSupabase(item));
    } catch (error) {
      console.error('Error fetching penjualan data:', error);
      throw error;
    }
  }

  static async savePenjualan(penjualanData: Penjualan[]): Promise<void> {
    try {
      // Delete all existing records first
      await this.deleteAllPenjualan();

      // Insert new records
      const supabaseData = penjualanData.map(item => this.transformToSupabase(item));
      
      const { error } = await (supabase as any)
        .from('data_penjualan')
        .insert(supabaseData);

      if (error) throw error;
    } catch (error) {
      console.error('Error saving penjualan data:', error);
      throw error;
    }
  }

  static async deleteAllPenjualan(): Promise<void> {
    try {
      const { error } = await (supabase as any)
        .from('data_penjualan')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all records

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting penjualan data:', error);
      throw error;
    }
  }

  static async deletePenjualan(id: string): Promise<void> {
    try {
      const { error } = await (supabase as any)
        .from('data_penjualan')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting penjualan record:', error);
      throw error;
    }
  }

  private static transformFromSupabase(item: SupabasePenjualan): Penjualan {
    return {
      id: item.id,
      petaniId: item.petani_id,
      pengepulId: item.pengepul_id,
      kodePetani: item.kode_petani,
      namaPetani: item.nama_petani,
      namaPengepul: item.nama_pengepul,
      jumlahJual: Number(item.jumlah_jual),
      hargaPerKg: Number(item.harga_per_kg),
      totalHarga: Number(item.total_harga),
      tanggalJual: item.tanggal_jual,
      type: item.type as 'serbuk' | 'cetak',
      metodePembayaran: item.metode_pembayaran as 'tunai' | 'transfer' | 'tempo',
      statusPembayaran: item.status_pembayaran as 'lunas' | 'belum_lunas',
      tanggalJatuhTempo: item.tanggal_jatuh_tempo,
      keterangan: item.keterangan,
      createdAt: item.created_at
    };
  }

  private static transformToSupabase(item: Penjualan): any {
    return {
      id: item.id,
      petani_id: item.petaniId,
      pengepul_id: item.pengepulId,
      kode_petani: item.kodePetani,
      nama_petani: item.namaPetani,
      nama_pengepul: item.namaPengepul,
      jumlah_jual: item.jumlahJual,
      harga_per_kg: item.hargaPerKg,
      total_harga: item.totalHarga,
      tanggal_jual: item.tanggalJual,
      type: item.type,
      metode_pembayaran: item.metodePembayaran,
      status_pembayaran: item.statusPembayaran,
      tanggal_jatuh_tempo: item.tanggalJatuhTempo,
      keterangan: item.keterangan
    };
  }
}