import { supabase } from '@/integrations/supabase/client';
import { Pengepul } from '../types';

export class SupabasePengepulService {
  static async getAllPengepul(): Promise<Pengepul[]> {
    const { data, error } = await supabase
      .from('pengepul')
      .select('*')
      .order('nama', { ascending: true });

    if (error) throw error;

    return (data || []).map(item => ({
      id: item.id,
      kode: item.kode,
      nama: item.nama,
      alamat: item.alamat,
      telepon: item.telepon,
      email: item.email || undefined,
      bankAccount: item.bank_account || undefined,
      hargaPerKg: item.harga_per_kg || 0,
      petaniTerkait: item.petani_terkait || [],
      createdAt: item.created_at
    }));
  }

  static async addPengepul(pengepulData: Omit<Pengepul, 'id' | 'createdAt'>): Promise<Pengepul> {
    // Check for duplicate kode
    const { data: existing } = await supabase
      .from('pengepul')
      .select('id')
      .eq('kode', pengepulData.kode)
      .maybeSingle();

    if (existing) {
      throw new Error(`Kode pengepul "${pengepulData.kode}" sudah ada. Gunakan kode yang berbeda.`);
    }

    const { data, error } = await supabase
      .from('pengepul')
      .insert({
        kode: pengepulData.kode,
        nama: pengepulData.nama,
        alamat: pengepulData.alamat,
        telepon: pengepulData.telepon,
        email: pengepulData.email || null,
        bank_account: pengepulData.bankAccount || null,
        harga_per_kg: pengepulData.hargaPerKg,
        petani_terkait: pengepulData.petaniTerkait || []
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      kode: data.kode,
      nama: data.nama,
      alamat: data.alamat,
      telepon: data.telepon,
      email: data.email || undefined,
      bankAccount: data.bank_account || undefined,
      hargaPerKg: data.harga_per_kg || 0,
      petaniTerkait: data.petani_terkait || [],
      createdAt: data.created_at
    };
  }

  static async updatePengepul(id: string, pengepulData: Omit<Pengepul, 'id' | 'createdAt'>): Promise<void> {
    // Check for duplicate kode (excluding current record)
    const { data: existing } = await supabase
      .from('pengepul')
      .select('id')
      .eq('kode', pengepulData.kode)
      .neq('id', id)
      .maybeSingle();

    if (existing) {
      throw new Error(`Kode pengepul "${pengepulData.kode}" sudah ada. Gunakan kode yang berbeda.`);
    }

    const { error } = await supabase
      .from('pengepul')
      .update({
        kode: pengepulData.kode,
        nama: pengepulData.nama,
        alamat: pengepulData.alamat,
        telepon: pengepulData.telepon,
        email: pengepulData.email || null,
        bank_account: pengepulData.bankAccount || null,
        harga_per_kg: pengepulData.hargaPerKg,
        petani_terkait: pengepulData.petaniTerkait || []
      })
      .eq('id', id);

    if (error) throw error;
  }

  static async deletePengepul(id: string): Promise<void> {
    const { error } = await supabase
      .from('pengepul')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
}
