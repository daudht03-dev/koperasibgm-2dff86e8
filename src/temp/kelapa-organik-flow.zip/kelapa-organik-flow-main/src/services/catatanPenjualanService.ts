import { supabase } from '@/integrations/supabase/client';
import { PanenData } from '../types';

export interface SupabaseCatatanPenjualan {
  id: string;
  petani_id: string;
  kode_petani: string;
  nama_petani: string;
  rata_rata_panen: number;
  tanggal_mulai: string;
  hari_1: number;
  hari_2: number;
  hari_3: number;
  hari_4: number;
  hari_5: number;
  hari_6: number;
  hari_7: number;
  total_panen: number;
  tanggal_pengambilan: string;
  hari_libur: number[];
  week_number: number;
  dynamic_data: any;
  dynamic_hari_libur: any;
  jenis_panen: string;
  created_at: string;
  updated_at: string;
}

export class CatatanPenjualanService {
  static async getAllCatatanPenjualan(): Promise<PanenData[]> {
    try {
      const { data, error } = await (supabase as any)
        .from('catatan_penjualan')
        .select('*')
        .order('tanggal_mulai', { ascending: false });

      if (error) throw error;

      return (data || []).map(this.transformFromSupabase);
    } catch (error) {
      console.error('Error fetching catatan penjualan:', error);
      return [];
    }
  }

  static async getCatatanPenjualanByType(type: 'serbuk' | 'cetak'): Promise<PanenData[]> {
    try {
      const { data, error } = await (supabase as any)
        .from('catatan_penjualan')
        .select('*')
        .eq('jenis_panen', type)
        .order('tanggal_mulai', { ascending: false });

      if (error) throw error;

      return (data || []).map(this.transformFromSupabase);
    } catch (error) {
      console.error('Error fetching catatan penjualan by type:', error);
      return [];
    }
  }

  static async saveCatatanPenjualan(catatanData: PanenData[]): Promise<void> {
    try {
      // First, delete existing records to avoid duplicates
      await (supabase as any)
        .from('catatan_penjualan')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all records

      // Transform and insert new data
      const transformedData = catatanData.map(this.transformToSupabase);
      
      if (transformedData.length > 0) {
        const { error } = await (supabase as any)
          .from('catatan_penjualan')
          .insert(transformedData);

        if (error) throw error;
      }
    } catch (error) {
      console.error('Error saving catatan penjualan:', error);
      throw error;
    }
  }

  static async deleteAllCatatanPenjualan(): Promise<void> {
    try {
      const { error } = await (supabase as any)
        .from('catatan_penjualan')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all records

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting all catatan penjualan:', error);
      throw error;
    }
  }

  private static transformFromSupabase(item: SupabaseCatatanPenjualan): PanenData {
    return {
      id: item.id,
      petaniId: item.petani_id,
      kodePetani: item.kode_petani,
      namaPetani: item.nama_petani,
      rataRataPanen: item.rata_rata_panen,
      tanggalMulai: item.tanggal_mulai,
      hari1: item.hari_1,
      hari2: item.hari_2,
      hari3: item.hari_3,
      hari4: item.hari_4,
      hari5: item.hari_5,
      hari6: item.hari_6,
      hari7: item.hari_7,
      totalPanen: item.total_panen,
      tanggalPengambilan: item.tanggal_pengambilan,
      hariLibur: item.hari_libur || [],
      type: item.jenis_panen as 'serbuk' | 'cetak',
      weekNumber: item.week_number,
      dynamicData: item.dynamic_data,
      dynamicHariLibur: item.dynamic_hari_libur
    };
  }

  private static transformToSupabase(item: PanenData): any {
    return {
      id: item.id,
      petani_id: item.petaniId,
      kode_petani: item.kodePetani,
      nama_petani: item.namaPetani,
      rata_rata_panen: item.rataRataPanen,
      tanggal_mulai: item.tanggalMulai,
      hari_1: item.hari1,
      hari_2: item.hari2,
      hari_3: item.hari3,
      hari_4: item.hari4,
      hari_5: item.hari5,
      hari_6: item.hari6,
      hari_7: item.hari7,
      total_panen: item.totalPanen,
      tanggal_pengambilan: item.tanggalPengambilan,
      hari_libur: item.hariLibur || [],
      week_number: item.weekNumber,
      dynamic_data: item.dynamicData || null,
      dynamic_hari_libur: item.dynamicHariLibur || null,
      jenis_panen: item.type
    };
  }
}