import { localDB, LocalPenjualan, generateId, getCurrentTimestamp } from '@/lib/localDatabase';
import { Penjualan } from '@/types';

export class LocalPenjualanService {
  static async getAllPenjualan(): Promise<Penjualan[]> {
    try {
      const data = await localDB.penjualan.orderBy('tanggalJual').reverse().toArray();
      return data.map(item => this.transformFromLocal(item));
    } catch (error) {
      console.error('Error fetching penjualan data:', error);
      throw error;
    }
  }

  static async savePenjualan(penjualanData: Penjualan[]): Promise<void> {
    try {
      // Clear existing data
      await this.deleteAllPenjualan();

      // Insert new data
      const localData = penjualanData.map(item => this.transformToLocal(item));
      await localDB.penjualan.bulkAdd(localData);
    } catch (error) {
      console.error('Error saving penjualan data:', error);
      throw error;
    }
  }

  static async deleteAllPenjualan(): Promise<void> {
    try {
      await localDB.penjualan.clear();
    } catch (error) {
      console.error('Error deleting penjualan data:', error);
      throw error;
    }
  }

  static async deletePenjualan(id: string): Promise<void> {
    try {
      await localDB.penjualan.delete(id);
    } catch (error) {
      console.error('Error deleting penjualan record:', error);
      throw error;
    }
  }

  private static transformFromLocal(item: LocalPenjualan): Penjualan {
    return {
      id: item.id,
      petaniId: item.petaniId,
      pengepulId: item.pengepulId,
      kodePetani: item.kodePetani,
      namaPetani: item.namaPetani,
      namaPengepul: item.namaPengepul,
      jumlahJual: item.jumlahJual,
      hargaPerKg: item.hargaPerKg,
      totalHarga: item.totalHarga,
      tanggalJual: item.tanggalJual,
      type: item.type,
      metodePembayaran: item.metodePembayaran,
      statusPembayaran: item.statusPembayaran,
      tanggalJatuhTempo: item.tanggalJatuhTempo,
      keterangan: item.keterangan,
      createdAt: item.createdAt
    };
  }

  private static transformToLocal(item: Penjualan): LocalPenjualan {
    return {
      id: item.id,
      petaniId: item.petaniId,
      pengepulId: item.pengepulId,
      kodePetani: item.kodePetani,
      namaPetani: item.namaPetani,
      namaPengepul: item.namaPengepul,
      jumlahJual: item.jumlahJual,
      hargaPerKg: item.hargaPerKg,
      totalHarga: item.totalHarga,
      tanggalJual: item.tanggalJual,
      type: item.type,
      metodePembayaran: item.metodePembayaran,
      statusPembayaran: item.statusPembayaran,
      tanggalJatuhTempo: item.tanggalJatuhTempo,
      keterangan: item.keterangan,
      createdAt: item.createdAt || getCurrentTimestamp()
    };
  }
}