export interface Petani {
  id: string;
  kode: string;
  nama: string;
  alamat: string;
  telepon: string;
  rataRataPanen: number;
  createdAt: string;
}

// Simple data structure that matches Supabase generate_panen table
export interface GeneratePanenData {
  id: string;
  kodePetani: string;
  namaPetani: string;
  tanggalPanen: string;
  rataRata: number;
  jumlahPanen: string;
  jenisPanen: 'serbuk' | 'cetak';
  // Make it compatible with existing components
  type?: 'serbuk' | 'cetak';
}

export interface PanenData {
  id: string;
  petaniId: string;
  kodePetani: string;
  namaPetani: string;
  rataRataPanen: number;
  tanggalMulai: string;
  hari1: number;
  hari2: number;
  hari3: number;
  hari4: number;
  hari5: number;
  hari6: number;
  hari7: number;
  totalPanen: number;
  tanggalPengambilan: string;
  hariLibur: number[];
  type: 'serbuk' | 'cetak';
  weekNumber?: number; // New field for week tracking
  // New fields for dynamic columns
  dynamicData?: { [date: string]: number };
  dynamicHariLibur?: { [date: string]: boolean };
}

export interface Pengepul {
  id: string;
  kode: string;
  nama: string;
  alamat: string;
  telepon: string;
  email?: string;
  bankAccount?: string;
  hargaPerKg: number;
  petaniTerkait: string[];
  createdAt: string;
}

export interface BahanBaku {
  id: string;
  petaniId: string;
  pengepulId: string;
  kodePetani: string;
  namaPetani: string;
  namaPengepul: string;
  jumlahMasuk: number;
  tanggalMasuk: string;
  type: 'serbuk' | 'cetak';
  createdAt?: string;
}

export interface Gudang {
  id: string;
  tanggal: string;
  jenis: 'masuk' | 'keluar';
  bahanBaku: string;
  jumlah: number;
  satuan: string;
  sumberTujuan: string;
  penanggungJawab: string;
  keterangan?: string;
  createdAt: string;
}

export interface Pengovenan {
  id: string;
  tanggal: string;
  batchNumber: string;
  jenisGula: 'serbuk' | 'cetak';
  jumlahBahan: number;
  suhu: number;
  waktuMasak: number;
  hasilJadi: number;
  kualitas: 'A' | 'B' | 'C';
  operator: string;
  keterangan?: string;
  createdAt: string;
}

// New LotPengovenan interface
export interface LotPengovenan {
  id: string;
  kodeLot: string;
  namaLot: string;
  tanggalProses: string;
  jumlahBahanBaku: number;
  jumlahKering: number;
  bahanBakuIds: string[];
}

// New BatchPengovenan interface for the new functionality
export interface BatchPengovenan {
  id: string;
  tanggalOven: string;
  batch: number;
  kodePetani: string;
  namaPetani: string;
  jumlahBahanBaku: number;
  susut: number;
  qcOff: number;
  setelahKering: number;
  tanggalGenerate: string;
}

// Updated StokGudang interface with packing
export interface StokGudang {
  id: string;
  lotId: string;
  lotPengovenan: string;
  kodeLot: string;
  namaLot: string;
  jumlahMasuk: number;
  jumlahKeluar: number;
  stokSisa: number;
  tanggalMasukGudang: string;
  tanggalUpdate: string;
  status: 'tersedia' | 'dikemas' | 'terjual';
}

// New Packing interface
export interface Packing {
  id: string;
  stokGudangId: string;
  lotAsal: string;
  lotPacking: string;
  jumlahKemasan: number;
  ukuranKemasan: number; // 10 or 25 kg
  totalBerat: number;
  sisaBerat: number;
  tanggalPacking: string;
  operator: string;
  keterangan?: string;
}

// Updated Penjualan interface to match component usage
export interface Penjualan {
  id: string;
  petaniId: string;
  pengepulId: string;
  kodePetani: string;
  namaPetani: string;
  namaPengepul: string;
  jumlahJual: number;
  hargaPerKg: number;
  totalHarga: number;
  tanggalJual: string;
  type: 'serbuk' | 'cetak';
  metodePembayaran: 'tunai' | 'transfer' | 'tempo';
  statusPembayaran: 'lunas' | 'belum_lunas';
  tanggalJatuhTempo?: string;
  keterangan?: string;
  createdAt: string;
}

// New PurchaseOrder interface
export interface PurchaseOrder {
  id: string;
  nomorPO: string;
  customer: string;
  alamatKirim: string;
  tanggalOrder: string;
  items: {
    nama: string;
    jumlah: number;
    satuan: string;
    kondisi: string;
  }[];
  status: 'pending' | 'processing' | 'completed' | 'shipped';
  createdAt: string;
}

// Updated SuratJalan interface to match component usage
export interface SuratJalan {
  id: string;
  nomorSurat: string;
  tanggal: string;
  pengirim: string;
  penerima: string;
  alamatTujuan: string;
  driverName: string;
  vehicleNumber: string;
  // Updated items structure to match the original interface
  items: {
    nama: string;
    jumlah: number;
    satuan: string;
    kondisi: string;
  }[];
  keterangan?: string;
  status: 'pending' | 'terkirim' | 'diterima';
  createdAt: string;
  // Additional properties that components expect
  poId?: string;
  nomorPO?: string;
  customer?: string;
  alamatKirim?: string;
  tanggalKirim?: string;
}
