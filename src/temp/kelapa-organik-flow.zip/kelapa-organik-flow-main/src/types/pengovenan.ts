export interface PengovenanData {
  id: string;
  nomor_lot: string;
  tanggal_pengovenan: string;
  tanggal_bahan_baku: string;
  batch_number: number;
  kode_petani: string;
  nama_petani: string;
  jumlah_bahan_baku: number;
  susut: number;
  qc_off: number;
  setelah_kering: number;
  jenis_gula: string;
  created_at: string;
  updated_at: string;
}

export interface PengovenanFormData {
  tanggal_pengovenan: Date | undefined;
  tanggal_bahan_baku: string;
  selected_petani: string[];
}

export interface PetaniForBatch {
  kode_petani: string;
  nama_petani: string;
  jumlah_bahan_baku: number;
  available: boolean;
}

export interface BatchCalculation {
  susut: number;
  qc_off: number;
  setelah_kering: number;
}