import React, { createContext, useContext, ReactNode } from 'react';
import { useLocalRealtimeData, RealtimeDataState } from '../hooks/useLocalRealtimeData';

interface DataContextType extends RealtimeDataState {
  refreshData: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useDataContext = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useDataContext must be used within a DataProvider');
  }
  return context;
};

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const realtimeData = useLocalRealtimeData();

  return (
    <DataContext.Provider value={realtimeData}>
      {children}
    </DataContext.Provider>
  );
};