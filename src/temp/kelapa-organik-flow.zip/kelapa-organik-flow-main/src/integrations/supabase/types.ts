export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      data_panen: {
        Row: {
          created_at: string
          dynamic_data: Json | null
          dynamic_hari_libur: Json | null
          hari_libur: number[] | null
          hari1: number | null
          hari2: number | null
          hari3: number | null
          hari4: number | null
          hari5: number | null
          hari6: number | null
          hari7: number | null
          id: string
          kode_petani: string
          nama_petani: string
          petani_id: string | null
          rata_rata_panen: number | null
          tanggal_mulai: string
          tanggal_pengambilan: string | null
          total_panen: number | null
          type: Database["public"]["Enums"]["jenis_type"]
          week_number: number | null
        }
        Insert: {
          created_at?: string
          dynamic_data?: Json | null
          dynamic_hari_libur?: Json | null
          hari_libur?: number[] | null
          hari1?: number | null
          hari2?: number | null
          hari3?: number | null
          hari4?: number | null
          hari5?: number | null
          hari6?: number | null
          hari7?: number | null
          id?: string
          kode_petani: string
          nama_petani: string
          petani_id?: string | null
          rata_rata_panen?: number | null
          tanggal_mulai: string
          tanggal_pengambilan?: string | null
          total_panen?: number | null
          type?: Database["public"]["Enums"]["jenis_type"]
          week_number?: number | null
        }
        Update: {
          created_at?: string
          dynamic_data?: Json | null
          dynamic_hari_libur?: Json | null
          hari_libur?: number[] | null
          hari1?: number | null
          hari2?: number | null
          hari3?: number | null
          hari4?: number | null
          hari5?: number | null
          hari6?: number | null
          hari7?: number | null
          id?: string
          kode_petani?: string
          nama_petani?: string
          petani_id?: string | null
          rata_rata_panen?: number | null
          tanggal_mulai?: string
          tanggal_pengambilan?: string | null
          total_panen?: number | null
          type?: Database["public"]["Enums"]["jenis_type"]
          week_number?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "data_panen_petani_id_fkey"
            columns: ["petani_id"]
            isOneToOne: false
            referencedRelation: "petani"
            referencedColumns: ["id"]
          },
        ]
      }
      pengepul: {
        Row: {
          alamat: string
          bank_account: string | null
          created_at: string
          email: string | null
          harga_per_kg: number
          id: string
          kode: string
          nama: string
          petani_terkait: string[] | null
          telepon: string
        }
        Insert: {
          alamat: string
          bank_account?: string | null
          created_at?: string
          email?: string | null
          harga_per_kg?: number
          id?: string
          kode: string
          nama: string
          petani_terkait?: string[] | null
          telepon: string
        }
        Update: {
          alamat?: string
          bank_account?: string | null
          created_at?: string
          email?: string | null
          harga_per_kg?: number
          id?: string
          kode?: string
          nama?: string
          petani_terkait?: string[] | null
          telepon?: string
        }
        Relationships: []
      }
      penjualan: {
        Row: {
          created_at: string
          harga_per_kg: number
          id: string
          jumlah_jual: number
          keterangan: string | null
          kode_petani: string
          metode_pembayaran: Database["public"]["Enums"]["metode_pembayaran"]
          nama_pengepul: string
          nama_petani: string
          pengepul_id: string | null
          petani_id: string | null
          status_pembayaran: Database["public"]["Enums"]["status_pembayaran"]
          tanggal_jatuh_tempo: string | null
          tanggal_jual: string
          total_harga: number
          type: Database["public"]["Enums"]["jenis_type"]
        }
        Insert: {
          created_at?: string
          harga_per_kg?: number
          id?: string
          jumlah_jual?: number
          keterangan?: string | null
          kode_petani: string
          metode_pembayaran?: Database["public"]["Enums"]["metode_pembayaran"]
          nama_pengepul: string
          nama_petani: string
          pengepul_id?: string | null
          petani_id?: string | null
          status_pembayaran?: Database["public"]["Enums"]["status_pembayaran"]
          tanggal_jatuh_tempo?: string | null
          tanggal_jual: string
          total_harga?: number
          type?: Database["public"]["Enums"]["jenis_type"]
        }
        Update: {
          created_at?: string
          harga_per_kg?: number
          id?: string
          jumlah_jual?: number
          keterangan?: string | null
          kode_petani?: string
          metode_pembayaran?: Database["public"]["Enums"]["metode_pembayaran"]
          nama_pengepul?: string
          nama_petani?: string
          pengepul_id?: string | null
          petani_id?: string | null
          status_pembayaran?: Database["public"]["Enums"]["status_pembayaran"]
          tanggal_jatuh_tempo?: string | null
          tanggal_jual?: string
          total_harga?: number
          type?: Database["public"]["Enums"]["jenis_type"]
        }
        Relationships: [
          {
            foreignKeyName: "penjualan_pengepul_id_fkey"
            columns: ["pengepul_id"]
            isOneToOne: false
            referencedRelation: "pengepul"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "penjualan_petani_id_fkey"
            columns: ["petani_id"]
            isOneToOne: false
            referencedRelation: "petani"
            referencedColumns: ["id"]
          },
        ]
      }
      petani: {
        Row: {
          alamat: string
          created_at: string
          id: string
          kode: string
          nama: string
          rata_rata_panen: number | null
          telepon: string
        }
        Insert: {
          alamat: string
          created_at?: string
          id?: string
          kode: string
          nama: string
          rata_rata_panen?: number | null
          telepon: string
        }
        Update: {
          alamat?: string
          created_at?: string
          id?: string
          kode?: string
          nama?: string
          rata_rata_panen?: number | null
          telepon?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      jenis_type: "serbuk" | "cetak"
      metode_pembayaran: "tunai" | "transfer" | "tempo"
      status_pembayaran: "lunas" | "belum_lunas"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      jenis_type: ["serbuk", "cetak"],
      metode_pembayaran: ["tunai", "transfer", "tempo"],
      status_pembayaran: ["lunas", "belum_lunas"],
    },
  },
} as const
