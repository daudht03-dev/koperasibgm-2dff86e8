import Dexie, { Table } from 'dexie';

// Define interfaces for local database
export interface LocalPetani {
  id: string;
  kodePetani: string;
  namaPetani: string;
  alamat: string;
  nomorTelepon?: string;
  rataRataPanen?: number;
  createdAt: string;
  updatedAt: string;
}

export interface LocalPengepul {
  id: string;
  kodePengepul: string;
  namaPengepul: string;
  alamat: string;
  nomorTelepon?: string;
  petaniKodes: string[];
  harga?: number[];
  createdAt: string;
  updatedAt: string;
}

export interface LocalPanenData {
  id: string;
  petaniId: string;
  kodePetani: string;
  namaPetani: string;
  rataRataPanen: number;
  tanggalMulai: string;
  hari1: number;
  hari2: number;
  hari3: number;
  hari4: number;
  hari5: number;
  hari6: number;
  hari7: number;
  totalPanen: number;
  tanggalPengambilan: string;
  hariLibur: number[];
  weekNumber: number;
  dynamicData?: any;
  dynamicHariLibur?: any;
  jenisPanen: 'serbuk' | 'cetak';
  createdAt: string;
  updatedAt: string;
}

export interface LocalPenjualan {
  id: string;
  petaniId: string;
  pengepulId: string;
  kodePetani: string;
  namaPetani: string;
  namaPengepul: string;
  jumlahJual: number;
  hargaPerKg: number;
  totalHarga: number;
  tanggalJual: string;
  type: 'serbuk' | 'cetak';
  metodePembayaran: 'tunai' | 'transfer' | 'tempo';
  statusPembayaran: 'lunas' | 'belum_lunas';
  tanggalJatuhTempo?: string;
  keterangan?: string;
  createdAt: string;
}

export interface LocalBahanBaku {
  id: string;
  petaniId: string;
  pengepulId: string;
  kodePetani: string;
  namaPetani: string;
  namaPengepul: string;
  jumlahMasuk: number;
  tanggalMasuk: string;
  type: 'serbuk' | 'cetak';
  noLot: string;
  totalPerPengepul: number;
  totalKeseluruhan: number;
  createdAt: string;
}

export interface LocalPengovenan {
  id: string;
  tanggalPengovenan: string;
  tanggalBahanBaku: string;
  batchNumber: number;
  jumlahBahanBaku: number;
  susut: number;
  qcOff: number;
  setelahKering: number;
  nomorLot: string;
  kodePetani: string;
  namaPetani: string;
  jenisGula: string;
  createdAt: string;
  updatedAt: string;
}

// Define the database
export class LocalDB extends Dexie {
  petani!: Table<LocalPetani>;
  pengepul!: Table<LocalPengepul>;
  panenData!: Table<LocalPanenData>;
  catatanPenjualan!: Table<LocalPanenData>;
  penjualan!: Table<LocalPenjualan>;
  bahanBaku!: Table<LocalBahanBaku>;
  pengovenan!: Table<LocalPengovenan>;

  constructor() {
    super('AgriculturalManagementDB');
    
    this.version(1).stores({
      petani: '++id, kodePetani, namaPetani, alamat, nomorTelepon, rataRataPanen, createdAt, updatedAt',
      pengepul: '++id, kodePengepul, namaPengepul, alamat, nomorTelepon, petaniKodes, harga, createdAt, updatedAt',
      panenData: '++id, petaniId, kodePetani, namaPetani, tanggalMulai, jenisPanen, weekNumber, createdAt, updatedAt',
      catatanPenjualan: '++id, petaniId, kodePetani, namaPetani, tanggalMulai, jenisPanen, weekNumber, createdAt, updatedAt',
      penjualan: '++id, petaniId, pengepulId, kodePetani, namaPetani, namaPengepul, tanggalJual, type, createdAt',
      bahanBaku: '++id, petaniId, pengepulId, kodePetani, namaPetani, namaPengepul, tanggalMasuk, type, noLot, createdAt',
      pengovenan: '++id, tanggalPengovenan, tanggalBahanBaku, batchNumber, nomorLot, kodePetani, namaPetani, jenisGula, createdAt, updatedAt'
    });
  }
}

export const localDB = new LocalDB();

// Utility functions
export const generateId = () => {
  return crypto.randomUUID();
};

export const getCurrentTimestamp = () => {
  return new Date().toISOString();
};