import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { Petani, Pengepul, PanenData, Penjualan } from '../types';

export interface RealtimeDataState {
  petaniData: Petani[];
  pengepulData: Pengepul[];
  panenData: PanenData[];
  penjualanData: Penjualan[];
  bahanBakuData: any[];
  pengovenanData: any[];
  loading: boolean;
  error: string | null;
}

const transformPetani = (item: any): Petani => ({
  id: item.id,
  kode: item.kode,
  nama: item.nama,
  alamat: item.alamat,
  telepon: item.telepon,
  rataRataPanen: item.rata_rata_panen || 0,
  createdAt: item.created_at
});

const transformPengepul = (item: any): Pengepul => ({
  id: item.id,
  kode: item.kode,
  nama: item.nama,
  alamat: item.alamat,
  telepon: item.telepon,
  email: item.email || undefined,
  bankAccount: item.bank_account || undefined,
  hargaPerKg: item.harga_per_kg || 0,
  petaniTerkait: item.petani_terkait || [],
  createdAt: item.created_at
});

const transformPanen = (item: any): PanenData => ({
  id: item.id,
  petaniId: item.petani_id || '',
  kodePetani: item.kode_petani,
  namaPetani: item.nama_petani,
  rataRataPanen: item.rata_rata_panen || 0,
  tanggalMulai: item.tanggal_mulai,
  hari1: item.hari1 || 0,
  hari2: item.hari2 || 0,
  hari3: item.hari3 || 0,
  hari4: item.hari4 || 0,
  hari5: item.hari5 || 0,
  hari6: item.hari6 || 0,
  hari7: item.hari7 || 0,
  totalPanen: item.total_panen || 0,
  tanggalPengambilan: item.tanggal_pengambilan || '',
  hariLibur: item.hari_libur || [],
  type: item.type as 'serbuk' | 'cetak',
  weekNumber: item.week_number,
  dynamicData: item.dynamic_data,
  dynamicHariLibur: item.dynamic_hari_libur
});

const transformPenjualan = (item: any): Penjualan => ({
  id: item.id,
  petaniId: item.petani_id || '',
  pengepulId: item.pengepul_id || '',
  kodePetani: item.kode_petani,
  namaPetani: item.nama_petani,
  namaPengepul: item.nama_pengepul,
  jumlahJual: item.jumlah_jual || 0,
  hargaPerKg: item.harga_per_kg || 0,
  totalHarga: item.total_harga || 0,
  tanggalJual: item.tanggal_jual,
  type: item.type as 'serbuk' | 'cetak',
  metodePembayaran: item.metode_pembayaran as 'tunai' | 'transfer' | 'tempo',
  statusPembayaran: item.status_pembayaran as 'lunas' | 'belum_lunas',
  tanggalJatuhTempo: item.tanggal_jatuh_tempo || undefined,
  keterangan: item.keterangan || undefined,
  createdAt: item.created_at
});

export const useRealtimeData = () => {
  const [state, setState] = useState<RealtimeDataState>({
    petaniData: [],
    pengepulData: [],
    panenData: [],
    penjualanData: [],
    bahanBakuData: [],
    pengovenanData: [],
    loading: true,
    error: null
  });

  const { toast } = useToast();

  const fetchAllData = async () => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));

      const [
        petaniResult,
        pengepulResult,
        panenResult,
        penjualanResult
      ] = await Promise.all([
        supabase.from('petani').select('*').order('created_at', { ascending: false }),
        supabase.from('pengepul').select('*').order('created_at', { ascending: false }),
        supabase.from('data_panen').select('*').order('tanggal_mulai', { ascending: false }),
        supabase.from('penjualan').select('*').order('tanggal_jual', { ascending: false })
      ]);

      const errors = [
        petaniResult.error,
        pengepulResult.error,
        panenResult.error,
        penjualanResult.error
      ].filter(Boolean);

      if (errors.length > 0) {
        throw new Error(`Database errors: ${errors.map(e => e?.message).join(', ')}`);
      }

      setState(prev => ({
        ...prev,
        petaniData: (petaniResult.data || []).map(transformPetani),
        pengepulData: (pengepulResult.data || []).map(transformPengepul),
        panenData: (panenResult.data || []).map(transformPanen),
        penjualanData: (penjualanResult.data || []).map(transformPenjualan),
        bahanBakuData: [],
        pengovenanData: [],
        loading: false
      }));

    } catch (error: any) {
      console.error('Error fetching data:', error);
      setState(prev => ({
        ...prev,
        error: error.message,
        loading: false
      }));
      
      toast({
        title: "Error",
        description: "Gagal memuat data: " + error.message,
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchAllData();

    const subscriptions = [
      supabase
        .channel('petani-changes')
        .on('postgres_changes', 
          { event: '*', schema: 'public', table: 'petani' },
          () => fetchAllData()
        )
        .subscribe(),

      supabase
        .channel('pengepul-changes')
        .on('postgres_changes',
          { event: '*', schema: 'public', table: 'pengepul' },
          () => fetchAllData()
        )
        .subscribe(),

      supabase
        .channel('panen-changes')
        .on('postgres_changes',
          { event: '*', schema: 'public', table: 'data_panen' },
          () => fetchAllData()
        )
        .subscribe(),

      supabase
        .channel('penjualan-changes')
        .on('postgres_changes',
          { event: '*', schema: 'public', table: 'penjualan' },
          () => fetchAllData()
        )
        .subscribe()
    ];

    return () => {
      subscriptions.forEach(subscription => {
        supabase.removeChannel(subscription);
      });
    };
  }, [toast]);

  const refreshData = () => {
    fetchAllData();
  };

  return {
    ...state,
    refreshData
  };
};
