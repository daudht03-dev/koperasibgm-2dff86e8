import { Penjualan } from '../types';
import { SupabasePenjualanService } from '../services/supabasePenjualanService';
import { useDataContext } from '../contexts/DataContext';
import { toast } from 'sonner';

export const usePenjualan = () => {
  const { pengepulData, panenData, catatanPenjualanData, penjualanData, refreshData } = useDataContext();

  const saveSales = async (salesData: Penjualan[]) => {
    try {
      await SupabasePenjualanService.savePenjualan(salesData);
      toast.success(`${salesData.length} data penjualan berhasil disimpan`);
      refreshData();
    } catch (error) {
      console.error('Error saving sales data:', error);
      toast.error('Gagal menyimpan data penjualan');
      throw error;
    }
  };

  const generateSalesFromHarvest = (): Penjualan[] => {
    if (catatanPenjualanData.length === 0) {
      throw new Error('Mohon generate catatan penjualan terlebih dahulu');
    }

    if (pengepulData.length === 0) {
      throw new Error('Mohon tambahkan data pengepul terlebih dahulu');
    }

    const salesData: Penjualan[] = [];

    catatanPenjualanData.forEach(catatan => {
      const relatedPengepul = pengepulData.find(pengepul => {
        return pengepul.petaniTerkait && pengepul.petaniTerkait.includes(catatan.kodePetani);
      });

      if (relatedPengepul) {
        const newSale: Penjualan = {
          id: `sale-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          petaniId: catatan.petaniId || '',
          pengepulId: relatedPengepul.id,
          kodePetani: catatan.kodePetani,
          namaPetani: catatan.namaPetani,
          namaPengepul: relatedPengepul.nama,
          jumlahJual: Number(catatan.totalPanen.toFixed(1)),
          hargaPerKg: relatedPengepul.hargaPerKg || 15000,
          totalHarga: Number((catatan.totalPanen * (relatedPengepul.hargaPerKg || 15000)).toFixed(0)),
          tanggalJual: catatan.tanggalPengambilan || new Date().toISOString().split('T')[0],
          type: catatan.type || 'serbuk',
          metodePembayaran: 'tunai',
          statusPembayaran: 'lunas',
          createdAt: new Date().toISOString()
        };
        salesData.push(newSale);
      }
    });

    if (salesData.length === 0) {
      throw new Error('Tidak ada data penjualan yang dapat di-generate. Pastikan petani sudah terkait dengan pengepul dan catatan penjualan tersedia.');
    }

    return salesData;
  };

  const deleteSales = async (id: string) => {
    try {
      await SupabasePenjualanService.deletePenjualan(id);
      toast.success('Data penjualan berhasil dihapus');
      refreshData();
    } catch (error) {
      console.error('Error deleting sales record:', error);
      toast.error('Gagal menghapus data penjualan');
      throw error;
    }
  };

  const groupSalesByPengepul = (sales: Penjualan[]) => {
    return sales.reduce((groups, sale) => {
      const pengepulName = sale.namaPengepul;
      if (!groups[pengepulName]) {
        groups[pengepulName] = [];
      }
      groups[pengepulName].push(sale);
      return groups;
    }, {} as Record<string, Penjualan[]>);
  };

  const getSalesByPengepul = (pengepulId: string) => {
    return penjualanData.filter(sale => sale.pengepulId === pengepulId);
  };

  const getTotalSalesByPengepul = (pengepulId: string) => {
    const pengepulSales = getSalesByPengepul(pengepulId);
    return {
      totalQuantity: pengepulSales.reduce((sum, sale) => sum + sale.jumlahJual, 0),
      totalValue: pengepulSales.reduce((sum, sale) => sum + sale.totalHarga, 0),
      totalTransactions: pengepulSales.length
    };
  };

  return {
    salesList: penjualanData,
    pengepulList: pengepulData,
    panenData,
    catatanPenjualanData,
    saveSales,
    generateSalesFromHarvest,
    deleteSales,
    groupSalesByPengepul,
    getSalesByPengepul,
    getTotalSalesByPengepul
  };
};
