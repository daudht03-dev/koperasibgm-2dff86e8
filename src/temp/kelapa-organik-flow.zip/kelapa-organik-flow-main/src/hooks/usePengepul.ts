import { useState } from 'react';
import { Pengepul, Petani } from '../types';
import { SupabasePengepulService } from '../services/supabasePengepulService';
import { toast } from 'sonner';

export const usePengepul = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const addPengepul = async (pengepulData: Omit<Pengepul, 'id' | 'createdAt'>) => {
    try {
      await SupabasePengepulService.addPengepul(pengepulData);
      toast.success('Data pengepul berhasil ditambahkan');
    } catch (error) {
      console.error('Error adding pengepul:', error);
      toast.error(error instanceof Error ? error.message : 'Gagal menambahkan pengepul');
      throw error;
    }
  };

  const updatePengepul = async (id: string, pengepulData: Omit<Pengepul, 'id' | 'createdAt'>) => {
    try {
      await SupabasePengepulService.updatePengepul(id, pengepulData);
      toast.success('Data pengepul berhasil diperbarui');
    } catch (error) {
      console.error('Error updating pengepul:', error);
      toast.error(error instanceof Error ? error.message : 'Gagal memperbarui pengepul');
      throw error;
    }
  };

  const deletePengepul = async (id: string) => {
    try {
      await SupabasePengepulService.deletePengepul(id);
      toast.success('Data pengepul berhasil dihapus');
    } catch (error) {
      console.error('Error deleting pengepul:', error);
      toast.error('Gagal menghapus pengepul');
      throw error;
    }
  };

  const getPetaniByKode = (petaniList: Petani[], kodePetani: string) => {
    return petaniList.find(petani => petani.kode === kodePetani);
  };

  const getPetaniTerkaitPengepul = (petaniList: Petani[], petaniKodes: string[]) => {
    return petaniKodes.map(kode => getPetaniByKode(petaniList, kode)).filter(Boolean) as Petani[];
  };

  return {
    searchTerm,
    setSearchTerm,
    addPengepul,
    updatePengepul,
    deletePengepul,
    getPetaniTerkaitPengepul
  };
};
