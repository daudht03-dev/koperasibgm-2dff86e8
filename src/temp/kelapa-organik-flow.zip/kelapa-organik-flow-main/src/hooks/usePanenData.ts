import { useState, useEffect } from 'react';
import { Petani, PanenData } from '../types';
import { supabase } from '@/integrations/supabase/client';
import { SupabasePanenService } from '../services/supabasePanenService';
import { SupabasePetaniService } from '../services/supabasePetaniService';
import { LocalCatatanPenjualanService } from '../services/localCatatanPenjualanService';

export const usePanenData = () => {
  const [petaniList, setPetaniList] = useState<Petani[]>([]);
  const [panenData, setPanenData] = useState<PanenData[]>([]);
  const [catatanPenjualanData, setCatatanPenjualanData] = useState<PanenData[]>([]);
  const [dynamicColumns, setDynamicColumns] = useState<string[]>([]);

  useEffect(() => {
    fetchPetaniData();
    fetchPanenData();
    fetchCatatanPenjualanData();
    loadDynamicColumns();

    // Set up real-time subscriptions
    const dataPanenChannel = supabase
      .channel('data_panen_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'data_panen'
        },
        () => {
          fetchPanenData();
        }
      )
      .subscribe();

    const petaniChannel = supabase
      .channel('petani_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'petani'
        },
        () => {
          fetchPetaniData();
        }
      )
      .subscribe();

    const catatanPenjualanChannel = supabase
      .channel('catatan_penjualan_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'catatan_penjualan'
        },
        () => {
          fetchCatatanPenjualanData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(dataPanenChannel);
      supabase.removeChannel(petaniChannel);
      supabase.removeChannel(catatanPenjualanChannel);
    };
  }, []);

  const fetchPetaniData = async () => {
    try {
      const data = await SupabasePetaniService.getAllPetani();
      setPetaniList(data);
    } catch (error) {
      console.error('Error fetching petani data:', error);
    }
  };

  const fetchPanenData = async () => {
    try {
      const data = await SupabasePanenService.getAllDataPanen();
      setPanenData(data);
    } catch (error) {
      console.error('Error fetching panen data:', error);
    }
  };

  const fetchCatatanPenjualanData = async () => {
    try {
      const data = await LocalCatatanPenjualanService.getAllCatatanPenjualan();
      setCatatanPenjualanData(data);
    } catch (error) {
      console.error('Error fetching catatan penjualan data:', error);
    }
  };

  const loadDynamicColumns = () => {
    const savedDynamicColumns = localStorage.getItem('dynamicColumns');
    if (savedDynamicColumns) {
      setDynamicColumns(JSON.parse(savedDynamicColumns));
    }
  };

  const savePanenData = async (data: PanenData[]) => {
    try {
      await SupabasePanenService.saveDataPanen(data);
      setPanenData(data);
      localStorage.setItem('panenData', JSON.stringify(data));
    } catch (error) {
      console.error('Error saving panen data:', error);
      throw error;
    }
  };

  const saveCatatanPenjualanData = async (data: PanenData[]) => {
    try {
      await LocalCatatanPenjualanService.saveCatatanPenjualan(data);
      setCatatanPenjualanData(data);
      localStorage.setItem('catatanPenjualanData', JSON.stringify(data));
    } catch (error) {
      console.error('Error saving catatan penjualan data:', error);
      throw error;
    }
  };

  const saveDynamicColumns = (columns: string[]) => {
    setDynamicColumns(columns);
    localStorage.setItem('dynamicColumns', JSON.stringify(columns));
  };

  const resetAllData = async () => {
    try {
      await SupabasePanenService.deleteAllDataPanen();
      await LocalCatatanPenjualanService.deleteAllCatatanPenjualan();
      setPanenData([]);
      setCatatanPenjualanData([]);
      setDynamicColumns([]);
      localStorage.removeItem('panenData');
      localStorage.removeItem('catatanPenjualanData');
      localStorage.removeItem('dynamicColumns');
    } catch (error) {
      console.error('Error resetting data:', error);
      throw error;
    }
  };

  return {
    petaniList,
    panenData,
    catatanPenjualanData,
    dynamicColumns,
    savePanenData,
    saveCatatanPenjualanData,
    saveDynamicColumns,
    resetAllData
  };
};
