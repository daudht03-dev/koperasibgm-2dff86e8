import { useState, useEffect } from 'react';
import { BahanBaku } from '../types';
import { usePenjualan } from './usePenjualan';
import { LocalBahanBakuService, GeneratedBahanBaku } from '../services/localBahanBakuService';
import { generateId } from '../lib/localDatabase';

export type { GeneratedBahanBaku } from '../services/localBahanBakuService';

export const useBahanBaku = (realtimeBahanBakuData?: any[], realtimePenjualanData?: any[]) => {
  console.log('useBahanBaku hook started', { 
    realtimeBahanBakuData: realtimeBahanBakuData?.length, 
    realtimePenjualanData: realtimePenjualanData?.length 
  });
  const [bahanBakuList, setBahanBakuList] = useState<GeneratedBahanBaku[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'serbuk' | 'cetak'>('all');
  const [noLot, setNoLot] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedPengepul, setSelectedPengepul] = useState('');
  
  console.log('About to call usePenjualan');
  const { groupSalesByPengepul } = usePenjualan();
  const salesList = realtimePenjualanData || [];
  console.log('usePenjualan called successfully, salesList:', salesList);

  useEffect(() => {
    // Use real-time data if provided, otherwise fetch from API
    if (realtimeBahanBakuData && realtimeBahanBakuData.length > 0) {
      // Data from local services is already in the correct format
      setBahanBakuList(realtimeBahanBakuData);
    } else {
      fetchBahanBakuData();
    }
  }, [realtimeBahanBakuData]);

  const fetchBahanBakuData = async () => {
    try {
      const data = await LocalBahanBakuService.getAllBahanBaku();
      setBahanBakuList(data);
    } catch (error) {
      console.error('Error fetching bahan baku data:', error);
    }
  };

  const saveToLocalStorage = async (data: GeneratedBahanBaku[]) => {
    try {
      await LocalBahanBakuService.saveBahanBaku(data);
      setBahanBakuList(data);
    } catch (error) {
      console.error('Error saving bahan baku data:', error);
      throw error;
    }
  };

  // Get unique dates from sales data
  const availableDates = [...new Set(salesList.map(sale => sale.tanggalJual))].sort();

  // Get sales for selected date
  const salesForDate = salesList.filter(sale => sale.tanggalJual === selectedDate);
  const groupedSalesForDate = groupSalesByPengepul(salesForDate);

  const generateBahanBaku = async () => {
    if (!selectedDate || !noLot) {
      alert('Mohon pilih tanggal dan masukkan nomor lot');
      return false;
    }

    if (salesForDate.length === 0) {
      alert('Tidak ada data penjualan untuk tanggal yang dipilih');
      return false;
    }

    const generatedData: GeneratedBahanBaku[] = [];

    // Calculate totals per pengepul
    const pengepulTotals: Record<string, number> = {};
    Object.entries(groupedSalesForDate).forEach(([pengepulName, sales]) => {
      pengepulTotals[pengepulName] = sales.reduce((sum, sale) => sum + sale.jumlahJual, 0);
    });

    // Calculate overall total for the date
    const totalKeseluruhan = Object.values(pengepulTotals).reduce((sum, total) => sum + total, 0);

    // If "ALL_PENGEPUL" is selected, generate for all pengepul
    // If specific pengepul is selected, generate only for that pengepul
    // If no specific pengepul is selected, generate for all (default behavior)
    const pengepulToGenerate = selectedPengepul === 'ALL_PENGEPUL' || !selectedPengepul 
      ? Object.keys(groupedSalesForDate) 
      : [selectedPengepul];

    console.log('Generating for pengepul:', pengepulToGenerate);

    // Generate data for selected pengepul(s)
    pengepulToGenerate.forEach(pengepulName => {
      const sales = groupedSalesForDate[pengepulName] || [];
      
      sales.forEach(sale => {
        const newBahanBaku: GeneratedBahanBaku = {
          id: generateId(),
          petaniId: sale.petaniId,
          pengepulId: sale.pengepulId,
          kodePetani: sale.kodePetani,
          namaPetani: sale.namaPetani,
          namaPengepul: sale.namaPengepul,
          jumlahMasuk: sale.jumlahJual,
          tanggalMasuk: sale.tanggalJual,
          type: sale.type,
          noLot: noLot,
          totalPerPengepul: pengepulTotals[pengepulName],
          totalKeseluruhan: totalKeseluruhan,
          createdAt: new Date().toISOString()
        };
        generatedData.push(newBahanBaku);
      });
    });

    try {
      const updatedList = [...bahanBakuList, ...generatedData];
      await saveToLocalStorage(updatedList);

      const pengepulCount = pengepulToGenerate.length;
      const message = selectedPengepul === 'ALL_PENGEPUL' 
        ? `Data bahan baku berhasil di-generate untuk semua pengepul (${pengepulCount} pengepul)! ${generatedData.length} record dibuat.`
        : `Data bahan baku berhasil di-generate! ${generatedData.length} record dibuat.`;
      
      alert(message);
      setNoLot('');
      setSelectedDate('');
      setSelectedPengepul('');
      return true;
    } catch (error) {
      alert('Terjadi kesalahan saat menyimpan data bahan baku');
      return false;
    }
  };

  const filteredBahanBaku = bahanBakuList.filter(bahan => {
    const matchesSearch = bahan.namaPetani.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bahan.kodePetani.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         bahan.namaPengepul.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || bahan.type === filterType;
    return matchesSearch && matchesType;
  });

  const totalBahanBaku = filteredBahanBaku.reduce((sum, b) => sum + b.jumlahMasuk, 0);

  // Get pengepul info for selected date and pengepul
  const selectedPengepulData = selectedPengepul && selectedDate ? 
    (selectedPengepul === 'ALL_PENGEPUL' 
      ? salesForDate // Show all sales for the date
      : groupedSalesForDate[selectedPengepul] || []
    ) : [];

  return {
    // State
    bahanBakuList,
    filteredBahanBaku,
    searchTerm,
    filterType,
    noLot,
    selectedDate,
    selectedPengepul,
    
    // Computed values
    availableDates,
    salesForDate,
    groupedSalesForDate,
    selectedPengepulData,
    totalBahanBaku,
    
    // Actions
    setSearchTerm,
    setFilterType,
    setNoLot,
    setSelectedDate,
    setSelectedPengepul,
    generateBahanBaku
  };
};

