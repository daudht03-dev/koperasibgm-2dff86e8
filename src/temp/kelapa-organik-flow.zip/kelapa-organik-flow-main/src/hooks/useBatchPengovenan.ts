import { useState, useEffect } from 'react';
import { BatchPengovenan } from '../types';

export const useBatchPengovenan = () => {
  const [batchPengovenan, setBatchPengovenan] = useState<BatchPengovenan[]>([]);

  useEffect(() => {
    const savedBatches = localStorage.getItem('batchPengovenanData');
    if (savedBatches) {
      setBatchPengovenan(JSON.parse(savedBatches));
    }
  }, []);

  const saveBatchPengovenan = (data: BatchPengovenan[]) => {
    setBatchPengovenan(data);
    localStorage.setItem('batchPengovenanData', JSON.stringify(data));
  };

  const addBatchPengovenan = (batchData: Omit<BatchPengovenan, 'id'>) => {
    const newBatch: BatchPengovenan = {
      ...batchData,
      id: Date.now().toString()
    };

    const updatedList = [...batchPengovenan, newBatch];
    saveBatchPengovenan(updatedList);
    return newBatch;
  };

  const addMultipleBatchPengovenan = (batchDataList: Omit<BatchPengovenan, 'id'>[]) => {
    const newBatches: BatchPengovenan[] = batchDataList.map((batchData, index) => ({
      ...batchData,
      id: `${Date.now()}-${index}`
    }));

    const updatedList = [...batchPengovenan, ...newBatches];
    saveBatchPengovenan(updatedList);
    return newBatches;
  };

  const deleteBatchPengovenan = (id: string) => {
    const updatedList = batchPengovenan.filter(batch => batch.id !== id);
    saveBatchPengovenan(updatedList);
  };

  const clearAllBatchPengovenan = () => {
    setBatchPengovenan([]);
    localStorage.removeItem('batchPengovenanData');
  };

  return {
    batchPengovenan,
    addBatchPengovenan,
    addMultipleBatchPengovenan,
    deleteBatchPengovenan,
    clearAllBatchPengovenan,
    saveBatchPengovenan
  };
};