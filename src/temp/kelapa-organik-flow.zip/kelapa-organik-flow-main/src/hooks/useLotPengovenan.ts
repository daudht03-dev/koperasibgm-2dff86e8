import { useState, useEffect } from 'react';
import { LotPengovenan } from '../types';

export const useLotPengovenan = () => {
  const [lotPengovenan, setLotPengovenan] = useState<LotPengovenan[]>([]);

  useEffect(() => {
    const savedLots = localStorage.getItem('lotPengovenanData');
    if (savedLots) {
      setLotPengovenan(JSON.parse(savedLots));
    }
  }, []);

  const saveLotPengovenan = (data: LotPengovenan[]) => {
    setLotPengovenan(data);
    localStorage.setItem('lotPengovenanData', JSON.stringify(data));
  };

  const addLotPengovenan = (lotData: Omit<LotPengovenan, 'id'>) => {
    const newLot: LotPengovenan = {
      ...lotData,
      id: Date.now().toString()
    };

    const updatedList = [...lotPengovenan, newLot];
    saveLotPengovenan(updatedList);
    return newLot;
  };

  const updateLotPengovenan = (id: string, lotData: Omit<LotPengovenan, 'id'>) => {
    const updatedList = lotPengovenan.map(lot =>
      lot.id === id ? { ...lot, ...lotData } : lot
    );
    saveLotPengovenan(updatedList);
  };

  const deleteLotPengovenan = (id: string) => {
    const updatedList = lotPengovenan.filter(lot => lot.id !== id);
    saveLotPengovenan(updatedList);
  };

  return {
    lotPengovenan,
    addLotPengovenan,
    updateLotPengovenan,
    deleteLotPengovenan,
    saveLotPengovenan
  };
};