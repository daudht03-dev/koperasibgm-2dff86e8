import { useState, useEffect } from 'react';
import { PengovenanData, PengovenanFormData, PetaniForBatch } from '../types/pengovenan';
import { LocalPengovenanService } from '../services/localPengovenanService';
import { calculateBatchValues, generateLotNumber } from '../utils/pengovenanCalculations';
import { toast } from './use-toast';

export const usePengovenan = (realtimePengovenanData?: PengovenanData[], bahanBakuData?: any[]) => {
  const [pengovenanData, setPengovenanData] = useState<PengovenanData[]>([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<PengovenanFormData>({
    tanggal_pengovenan: undefined,
    tanggal_bahan_baku: '',
    selected_petani: []
  });

  // Filter data bahan baku untuk jenis gula serbuk saja
  const dataPanenSerbuk = (bahanBakuData || []).filter(item => 
    item.type === 'serbuk' // Use the correct property name for local bahan baku data
  );

  // Get unique dates from bahan baku
  const availableDates = [...new Set(dataPanenSerbuk.map((bb: any) => bb.tanggalMasuk))].sort();

  // Get farmers for selected date and check availability
  const farmersForDate = dataPanenSerbuk
    .filter((bb: any) => bb.tanggalMasuk === formData.tanggal_bahan_baku)
    .reduce((acc: PetaniForBatch[], bb: any) => {
      const existing = acc.find(f => f.kode_petani === bb.kodePetani);
      if (existing) {
        existing.jumlah_bahan_baku += bb.jumlahMasuk;
      } else {
        // Check if farmer is already processed in existing batches for the same raw material date
        const alreadyProcessed = pengovenanData.some(
          pd => pd.kode_petani === bb.kodePetani && pd.tanggal_bahan_baku === formData.tanggal_bahan_baku
        );
        
        acc.push({
          kode_petani: bb.kodePetani,
          nama_petani: bb.namaPetani,
          jumlah_bahan_baku: bb.jumlahMasuk,
          available: !alreadyProcessed && !formData.selected_petani.includes(bb.kodePetani)
        });
      }
      return acc;
    }, [] as PetaniForBatch[]);

  const loadPengovenanData = async () => {
    try {
      setLoading(true);
      const data = await LocalPengovenanService.getAllPengovenan();
      setPengovenanData(data);
    } catch (error) {
      console.error('Error loading pengovenan data:', error);
      toast({
        title: "Error",
        description: "Gagal memuat data pengovenan",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Generate pengovenan batches
  const generatePengovenan = async () => {
    if (!formData.tanggal_pengovenan || !formData.tanggal_bahan_baku || formData.selected_petani.length === 0) {
      toast({
        title: "Error",
        description: "Mohon lengkapi semua field yang diperlukan",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const pengovenanBatches: Omit<PengovenanData, 'id' | 'created_at' | 'updated_at'>[] = [];

      formData.selected_petani.forEach((kodePetani, index) => {
        const farmer = farmersForDate.find(f => f.kode_petani === kodePetani);
        if (!farmer) return;

        const calculations = calculateBatchValues(farmer.jumlah_bahan_baku);
        const lotNumber = generateLotNumber(formData.tanggal_pengovenan!, index + 1);

        pengovenanBatches.push({
          nomor_lot: lotNumber,
          tanggal_pengovenan: formData.tanggal_pengovenan!.toISOString().split('T')[0],
          tanggal_bahan_baku: formData.tanggal_bahan_baku,
          batch_number: index + 1,
          kode_petani: farmer.kode_petani,
          nama_petani: farmer.nama_petani,
          jumlah_bahan_baku: farmer.jumlah_bahan_baku,
          susut: calculations.susut,
          qc_off: calculations.qc_off,
          setelah_kering: calculations.setelah_kering,
          jenis_gula: 'Gula Serbuk'
        });
      });

      await LocalPengovenanService.savePengovenan(pengovenanBatches);
      
      toast({
        title: "Berhasil",
        description: `${pengovenanBatches.length} batch pengovenan berhasil dibuat`
      });
      
      // Refresh data
      await loadPengovenanData();

      // Reset form
      setFormData({
        tanggal_pengovenan: undefined,
        tanggal_bahan_baku: '',
        selected_petani: []
      });

    } catch (error) {
      console.error('Error generating pengovenan:', error);
      toast({
        title: "Error",
        description: "Gagal menyimpan data pengovenan",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const deletePengovenan = async (id: string) => {
    try {
      setLoading(true);
      await LocalPengovenanService.deletePengovenan(id);
      
      toast({
        title: "Berhasil",
        description: "Batch pengovenan berhasil dihapus"
      });
      
      await loadPengovenanData();
    } catch (error) {
      console.error('Error deleting pengovenan:', error);
      toast({
        title: "Error",
        description: "Gagal menghapus batch pengovenan",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Auto next batch functionality
  const generateNextBatch = async () => {
    if (!formData.tanggal_bahan_baku) {
      toast({
        title: "Error",
        description: "Mohon pilih tanggal bahan baku terlebih dahulu",
        variant: "destructive"
      });
      return;
    }

    // Find available farmers (not yet processed)
    const availableFarmers = farmersForDate.filter(f => f.available);
    
    if (availableFarmers.length === 0) {
      toast({
        title: "Info",
        description: "Tidak ada petani yang tersedia untuk batch berikutnya",
        variant: "default"
      });
      return;
    }

    // Get the latest processing date from existing data for this raw material date
    const existingBatches = pengovenanData.filter(
      pd => pd.tanggal_bahan_baku === formData.tanggal_bahan_baku
    );
    
    let nextDate = formData.tanggal_pengovenan || new Date();
    if (existingBatches.length > 0) {
      const latestDate = new Date(Math.max(...existingBatches.map(b => new Date(b.tanggal_pengovenan).getTime())));
      nextDate = new Date(latestDate);
      nextDate.setDate(nextDate.getDate() + 1);
    }

    // Auto-select all available farmers and set next processing date
    setFormData({
      ...formData,
      tanggal_pengovenan: nextDate,
      selected_petani: availableFarmers.map(f => f.kode_petani)
    });

    toast({
      title: "Berhasil!",
      description: `Auto-generated batch untuk ${availableFarmers.length} petani pada ${nextDate.toLocaleDateString('id-ID')}`,
    });
  };

  const exportToCSV = () => {
    const csvContent = LocalPengovenanService.convertToExcelCSV(pengovenanData);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `data_pengovenan_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Load initial data
  useEffect(() => {
    if (realtimePengovenanData) {
      setPengovenanData(realtimePengovenanData);
    } else {
      loadPengovenanData();
    }
  }, [realtimePengovenanData]);

  return {
    pengovenanData,
    loading,
    formData,
    setFormData,
    availableDates,
    farmersForDate,
    dataPanenSerbuk,
    generatePengovenan,
    generateNextBatch,
    deletePengovenan,
    exportToCSV,
    loadPengovenanData
  };
};