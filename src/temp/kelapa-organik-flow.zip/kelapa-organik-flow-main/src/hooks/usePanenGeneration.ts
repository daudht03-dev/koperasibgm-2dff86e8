
import { useState } from 'react';
import { Petani, PanenData } from '../types';
import { generateHariLiburRandom, generatePanenData, generateNextWeekData } from '../utils/panenUtils';
import { generateCatatanPenjualan } from '../utils/catatanPenjualanUtils';

interface UsePanenGenerationProps {
  petaniList: Petani[];
  panenData: PanenData[];
  savePanenData: (data: PanenData[]) => void;
  saveCatatanPenjualanData: (data: PanenData[]) => void;
  saveDynamicColumns: (columns: string[]) => void;
  catatanPenjualanData: PanenData[];
  dynamicColumns: string[];
  refreshData?: () => void;
}

export const usePanenGeneration = ({
  petaniList,
  panenData,
  savePanenData,
  saveCatatanPenjualanData,
  saveDynamicColumns,
  catatanPenjualanData,
  dynamicColumns,
  refreshData
}: UsePanenGenerationProps) => {
  const [hariLiburSettings, setHariLiburSettings] = useState<{[key: string]: number[]}>({});

  const handleGenerate = (tanggalMulai: string, selectedPetani: string[]) => {
    if (!tanggalMulai || selectedPetani.length === 0) {
      alert('Mohon lengkapi tanggal mulai dan pilih petani');
      return;
    }

    const currentHariLibur = Object.keys(hariLiburSettings).length > 0 
      ? hariLiburSettings 
      : generateHariLiburRandom(selectedPetani);
    setHariLiburSettings(currentHariLibur);

    const allPanenData = generatePanenData(
      selectedPetani,
      petaniList,
      tanggalMulai,
      currentHariLibur,
      panenData
    );

    savePanenData(allPanenData);
    alert('Data panen berhasil di-generate!');
  };

  const handleGenerateNextWeek = (tanggalMulai: string, selectedPetani: string[], activeTab: 'serbuk' | 'cetak') => {
    if (selectedPetani.length === 0) {
      alert('Mohon pilih petani terlebih dahulu');
      return;
    }

    const currentWeekData = panenData.filter(p => p.type === activeTab);
    if (currentWeekData.length === 0) {
      alert('Mohon generate data panen terlebih dahulu');
      return;
    }

    const currentHariLibur = Object.keys(hariLiburSettings).length > 0 
      ? hariLiburSettings 
      : generateHariLiburRandom(selectedPetani);

    const updatedPanenData = generateNextWeekData(
      selectedPetani,
      petaniList,
      panenData,
      currentHariLibur,
      activeTab
    );

    savePanenData(updatedPanenData);
    
    const maxWeek = Math.max(...currentWeekData.map(p => p.weekNumber || 1));
    alert(`Data panen minggu ke-${maxWeek + 1} berhasil di-generate!`);
  };

  const handleGenerateCatatanPenjualan = async (activeTab: 'serbuk' | 'cetak') => {
    console.log('=== GENERATING CATATAN PENJUALAN ===');
    console.log('Active tab:', activeTab);
    console.log('Panen data available:', panenData.length);
    
    const currentWeekData = panenData.filter(p => p.type === activeTab);
    console.log('Current week data for type:', currentWeekData.length);
    
    if (currentWeekData.length === 0) {
      alert('Mohon generate data panen terlebih dahulu');
      return;
    }

    const salesNotesData = generateCatatanPenjualan(panenData, activeTab);
    console.log('Generated sales notes data:', salesNotesData.length);
    
    // Remove existing sales notes for this type and add new ones
    const otherTypesSalesNotes = catatanPenjualanData.filter(item => item.type !== activeTab);
    const updatedCatatanPenjualan = [...otherTypesSalesNotes, ...salesNotesData];
    
    console.log('Saving catatan penjualan data:', updatedCatatanPenjualan.length);
    
    // Save the data and wait for it to complete
    await saveCatatanPenjualanData(updatedCatatanPenjualan);
    
    console.log('Catatan penjualan saved, refreshing data...');
    
    // Refresh global data context with a longer delay
    if (refreshData) {
      setTimeout(async () => {
        await refreshData();
        console.log('Data refreshed after catatan penjualan generation');
      }, 500);
    }
    
    alert(`Catatan penjualan ${activeTab === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'} berhasil di-generate!`);
  };

  const handleResetDynamicColumns = () => {
    if (confirm('Apakah Anda yakin ingin menghapus semua kolom minggu berikutnya?')) {
      saveDynamicColumns([]);
      
      // Remove dynamic data from panen data
      const resetPanenData = panenData.map(panen => ({
        ...panen,
        dynamicData: undefined,
        dynamicHariLibur: undefined
      }));
      
      savePanenData(resetPanenData);
      alert('Header minggu berikutnya berhasil direset!');
    }
  };

  const handleGenerateAllWeeks = (tanggalMulai: string, selectedPetani: string[], activeTab: 'serbuk' | 'cetak', weekCount: number = 4) => {
    if (!tanggalMulai || selectedPetani.length === 0) {
      alert('Mohon lengkapi tanggal mulai dan pilih petani');
      return;
    }

    // Generate initial week
    handleGenerate(tanggalMulai, selectedPetani);

    // Generate subsequent weeks
    for (let i = 1; i < weekCount; i++) {
      setTimeout(() => {
        handleGenerateNextWeek(tanggalMulai, selectedPetani, activeTab);
      }, i * 100); // Small delay to ensure proper sequencing
    }

    alert(`Data panen untuk ${weekCount} minggu berhasil di-generate!`);
  };

  return {
    hariLiburSettings,
    setHariLiburSettings,
    handleGenerate,
    handleGenerateNextWeek,
    handleGenerateCatatanPenjualan,
    handleResetDynamicColumns,
    handleGenerateAllWeeks
  };
};
