import { useState, useEffect } from 'react';
import { Petani, Pengepul, PanenData, Penjualan } from '@/types';
import { SupabasePetaniService } from '@/services/supabasePetaniService';
import { SupabasePengepulService } from '@/services/supabasePengepulService';
import { SupabasePanenService } from '@/services/supabasePanenService';
import { SupabasePenjualanService } from '@/services/supabasePenjualanService';
import { LocalCatatanPenjualanService } from '@/services/localCatatanPenjualanService';
import { LocalBahanBakuService, GeneratedBahanBaku } from '@/services/localBahanBakuService';
import { LocalPengovenanService } from '@/services/localPengovenanService';
import { PengovenanData } from '@/types/pengovenan';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface RealtimeDataState {
  petaniData: Petani[];
  pengepulData: Pengepul[];
  panenData: PanenData[];
  catatanPenjualanData: PanenData[];
  penjualanData: Penjualan[];
  bahanBakuData: GeneratedBahanBaku[];
  pengovenanData: PengovenanData[];
  loading: boolean;
  error: string | null;
}

export const useLocalRealtimeData = () => {
  const [state, setState] = useState<RealtimeDataState>({
    petaniData: [],
    pengepulData: [],
    panenData: [],
    catatanPenjualanData: [],
    penjualanData: [],
    bahanBakuData: [],
    pengovenanData: [],
    loading: true,
    error: null
  });

  const fetchAllData = async () => {
    try {
      setState(prev => ({ ...prev, loading: true }));
      
      const [
        petaniData,
        pengepulData, 
        panenData,
        catatanPenjualanData,
        penjualanData,
        bahanBakuData,
        pengovenanData
      ] = await Promise.all([
        SupabasePetaniService.getAllPetani(),
        SupabasePengepulService.getAllPengepul(),
        SupabasePanenService.getAllDataPanen(),
        LocalCatatanPenjualanService.getAllCatatanPenjualan(),
        SupabasePenjualanService.getAllPenjualan(),
        LocalBahanBakuService.getAllBahanBaku(),
        LocalPengovenanService.getAllPengovenan()
      ]);

      setState(prev => ({
        ...prev,
        petaniData,
        pengepulData,
        panenData,
        catatanPenjualanData,
        penjualanData,
        bahanBakuData,
        pengovenanData,
        loading: false,
        error: null
      }));
    } catch (error) {
      console.error('Error fetching data:', error);
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : 'Failed to fetch data'
      }));
      toast.error('Gagal memuat data. Silakan coba lagi.');
    }
  };

  useEffect(() => {
    fetchAllData();

    // Set up real-time subscriptions for Supabase tables
    const petaniChannel = supabase
      .channel('petani-realtime')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'petani' },
        () => fetchAllData()
      )
      .subscribe();

    const pengepulChannel = supabase
      .channel('pengepul-realtime')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'pengepul' },
        () => fetchAllData()
      )
      .subscribe();

    const panenChannel = supabase
      .channel('panen-realtime')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'data_panen' },
        () => fetchAllData()
      )
      .subscribe();

    const penjualanChannel = supabase
      .channel('penjualan-realtime')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'penjualan' },
        () => fetchAllData()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(petaniChannel);
      supabase.removeChannel(pengepulChannel);
      supabase.removeChannel(panenChannel);
      supabase.removeChannel(penjualanChannel);
    };
  }, []);

  return {
    ...state,
    refreshData: fetchAllData
  };
};
