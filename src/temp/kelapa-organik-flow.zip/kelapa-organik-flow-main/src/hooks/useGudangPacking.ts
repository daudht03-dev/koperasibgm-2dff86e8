import { useState, useEffect } from 'react';
import { StokGudang, Packing } from '../types';

export const useGudangPacking = () => {
  const [stokGudang, setStokGudang] = useState<StokGudang[]>([]);
  const [packingList, setPackingList] = useState<Packing[]>([]);

  useEffect(() => {
    // Load stok gudang
    const savedStok = localStorage.getItem('stokGudangData');
    if (savedStok) {
      setStokGudang(JSON.parse(savedStok));
    }

    // Load packing list
    const savedPacking = localStorage.getItem('packingData');
    if (savedPacking) {
      setPackingList(JSON.parse(savedPacking));
    }
  }, []);

  const saveStokGudang = (data: StokGudang[]) => {
    setStokGudang(data);
    localStorage.setItem('stokGudangData', JSON.stringify(data));
  };

  const savePackingList = (data: Packing[]) => {
    setPackingList(data);
    localStorage.setItem('packingData', JSON.stringify(data));
  };

  const addStokMasuk = (data: Omit<StokGudang, 'id' | 'tanggalUpdate'>) => {
    const newStok: StokGudang = {
      ...data,
      id: Date.now().toString(),
      tanggalUpdate: new Date().toISOString().split('T')[0]
    };

    const updatedStok = [...stokGudang, newStok];
    saveStokGudang(updatedStok);
    return newStok;
  };

  const createPacking = (
    stokId: string, 
    ukuranKemasan: number, 
    jumlahKemasan: number, 
    operator: string, 
    keterangan?: string
  ) => {
    const stok = stokGudang.find(s => s.id === stokId);
    if (!stok) return null;

    const totalBerat = ukuranKemasan * jumlahKemasan;
    const sisaBerat = stok.stokSisa - totalBerat;

    if (sisaBerat < 0) {
      throw new Error('Jumlah kemasan melebihi stok yang tersedia');
    }

    // Generate lot packing
    const tanggalPacking = new Date().toISOString().split('T')[0];
    const packingNumber = String(packingList.length + 1).padStart(3, '0');
    const lotPacking = `PACK-${tanggalPacking.replace(/-/g, '')}-${packingNumber}`;

    const newPacking: Packing = {
      id: Date.now().toString(),
      stokGudangId: stokId,
      lotAsal: stok.kodeLot,
      lotPacking,
      jumlahKemasan,
      ukuranKemasan,
      totalBerat,
      sisaBerat,
      tanggalPacking,
      operator,
      keterangan
    };

    // Update stok gudang
    const updatedStok = stokGudang.map(s => 
      s.id === stokId 
        ? { ...s, stokSisa: sisaBerat, status: sisaBerat > 0 ? 'tersedia' as const : 'dikemas' as const }
        : s
    );

    // Add to packing list
    const updatedPacking = [...packingList, newPacking];

    saveStokGudang(updatedStok);
    savePackingList(updatedPacking);

    return newPacking;
  };

  const deletePacking = (packingId: string) => {
    const packing = packingList.find(p => p.id === packingId);
    if (!packing) return;

    // Restore stok
    const updatedStok = stokGudang.map(s => 
      s.id === packing.stokGudangId 
        ? { ...s, stokSisa: s.stokSisa + packing.totalBerat, status: 'tersedia' as const }
        : s
    );

    // Remove from packing list
    const updatedPacking = packingList.filter(p => p.id !== packingId);

    saveStokGudang(updatedStok);
    savePackingList(updatedPacking);
  };

  return {
    stokGudang,
    packingList,
    addStokMasuk,
    createPacking,
    deletePacking,
    saveStokGudang,
    savePackingList
  };
};