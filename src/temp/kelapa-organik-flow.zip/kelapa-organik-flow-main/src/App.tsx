
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { DataProvider } from './contexts/DataContext';

// Layout Components
import Sidebar from './components/Layout/Sidebar';
import Header from './components/Layout/Header';
import Login from './components/Auth/Login';

// Page Components
import DashboardOverview from './components/Dashboard/DashboardOverview';
import DataPetani from './components/Petani/DataPetani';
import GeneratePanen from './components/Panen/GeneratePanen';
import DataPengepul from './components/Pengepul/DataPengepul';
import DataPenjualan from './components/Penjualan/DataPenjualan';
import DataBahanBaku from './components/BahanBaku/DataBahanBaku';
import DataPengovenan from './components/Pengovenan/DataPengovenan';
import KegiatanGudang from './components/Gudang/KegiatanGudang';
import DataSuratJalan from './components/SuratJalan/DataSuratJalan';
import ExcelEndpointPanel from './components/ExcelIntegration/ExcelEndpointPanel';

const queryClient = new QueryClient();

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user is already logged in
    const authStatus = localStorage.getItem('isAuthenticated');
    if (authStatus === 'true') {
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = () => {
    setIsAuthenticated(true);
    localStorage.setItem('isAuthenticated', 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('isAuthenticated');
  };

  if (!isAuthenticated) {
    return (
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <Login onLogin={handleLogin} />
        </TooltipProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <DataProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <div className="flex h-screen bg-gray-50">
              <Sidebar onLogout={handleLogout} />
              <div className="flex-1 flex flex-col overflow-hidden">
                <Header />
                <main className="flex-1 overflow-y-auto">
                  <Routes>
                    <Route path="/" element={<Navigate to="/dashboard" replace />} />
                    <Route path="/dashboard" element={<DashboardOverview />} />
                    <Route path="/petani" element={<DataPetani />} />
                    <Route path="/panen" element={<GeneratePanen />} />
                    <Route path="/pengepul" element={<DataPengepul />} />
                    <Route path="/penjualan" element={<DataPenjualan />} />
                    <Route path="/bahan-baku" element={<DataBahanBaku />} />
                    <Route path="/pengovenan" element={<DataPengovenan />} />
                    <Route path="/gudang" element={<KegiatanGudang />} />
                    <Route path="/surat-jalan" element={<DataSuratJalan />} />
                    <Route path="/export" element={<ExcelEndpointPanel />} />
                  </Routes>
                </main>
              </div>
            </div>
          </BrowserRouter>
        </DataProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
