import { BatchCalculation } from '../types/pengovenan';

/**
 * Calculate susut (3% - 5.5% of bahan baku)
 */
export const calculateSusut = (jumlahBahanBaku: number): number => {
  const minPercentage = 0.03; // 3%
  const maxPercentage = 0.055; // 5.5%
  const randomPercentage = minPercentage + (Math.random() * (maxPercentage - minPercentage));
  return Math.round(jumlahBahanBaku * randomPercentage * 100) / 100;
};

/**
 * Calculate QC Off (2% - 3.5% of remaining after susut)
 */
export const calculateQcOff = (jumlahBahanBaku: number, susut: number): number => {
  const remainingAfterSusut = jumlahBahanBaku - susut;
  const minPercentage = 0.02; // 2%
  const maxPercentage = 0.035; // 3.5%
  const randomPercentage = minPercentage + (Math.random() * (maxPercentage - minPercentage));
  return Math.round(remainingAfterSusut * randomPercentage * 100) / 100;
};

/**
 * Calculate setelah kering (bahan baku - susut - qc off)
 */
export const calculateSetelahKering = (jumlahBahanBaku: number, susut: number, qcOff: number): number => {
  return Math.round((jumlahBahanBaku - susut - qcOff) * 100) / 100;
};

/**
 * Calculate all batch values at once
 */
export const calculateBatchValues = (jumlahBahanBaku: number): BatchCalculation => {
  const susut = calculateSusut(jumlahBahanBaku);
  const qc_off = calculateQcOff(jumlahBahanBaku, susut);
  const setelah_kering = calculateSetelahKering(jumlahBahanBaku, susut, qc_off);

  return {
    susut,
    qc_off,
    setelah_kering
  };
};

/**
 * Generate automatic lot number: LOT-YYYYMMDD-BB
 */
export const generateLotNumber = (tanggalPengovenan: Date, batchNumber: number): string => {
  const year = tanggalPengovenan.getFullYear();
  const month = String(tanggalPengovenan.getMonth() + 1).padStart(2, '0');
  const day = String(tanggalPengovenan.getDate()).padStart(2, '0');
  const batch = String(batchNumber).padStart(2, '0');
  
  return `LOT-${year}${month}${day}-${batch}`;
};

/**
 * Format number for display (remove unnecessary decimals)
 */
export const formatNumber = (value: number): string => {
  const rounded = Math.round(value * 100) / 100;
  return rounded % 1 === 0 ? rounded.toString() : rounded.toFixed(2);
};