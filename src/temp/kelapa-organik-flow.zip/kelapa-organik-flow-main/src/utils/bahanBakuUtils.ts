import { GeneratedBahanBaku } from '../hooks/useBahanBaku';

export const exportBahanBakuToCSV = (data: GeneratedBahanBaku[]) => {
  if (data.length === 0) {
    alert('Tidak ada data untuk diekspor');
    return;
  }

  const headers = [
    'Tanggal Masuk', 
    'No. Lot', 
    'Nama Pengepul', 
    'Kode Petani', 
    'Nama Petani', 
    'Jumlah Barang Petani', 
    'Total per Pengepul', 
    'Total Keseluruhan', 
    'Jenis'
  ];
  
  const csvData = [
    headers,
    ...data.map(bahan => [
      new Date(bahan.tanggalMasuk).toLocaleDateString('id-ID'),
      bahan.noLot,
      bahan.namaPengepul,
      bahan.kodePetani,
      bahan.namaPetani,
      bahan.jumlahMasuk.toString(),
      bahan.totalPerPengepul.toString(),
      bahan.totalKeseluruhan.toString(),
      bahan.type === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'
    ])
  ];

  const csvContent = csvData.map(row => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  const timestamp = new Date().toISOString().split('T')[0];
  link.setAttribute('href', url);
  link.setAttribute('download', `data-bahan-baku-${timestamp}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};