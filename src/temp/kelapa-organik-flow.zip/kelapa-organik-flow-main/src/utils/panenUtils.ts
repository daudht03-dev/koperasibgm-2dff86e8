import { Petani, PanenData } from '../types';

// Generate UUID v4
const generateUUID = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

// Fungsi untuk memformat angka agar konsisten
const formatAngka = (val: number): number => {
  const parsed = parseFloat(val.toString());
  return Number(parsed.toFixed(1));
};

export const generateRandomPanen = (rataRata: number, hariLibur: number[]) => {
  const hasil = [];
  for (let i = 1; i <= 7; i++) {
    if (hariLibur.includes(i)) {
      hasil.push(0);
    } else {
      // Generate random dalam rentang rata-rata ± 1.9
      const min = Math.max(0, rataRata - 1.9);
      const max = rataRata + 1.9;
      const random = Math.random() * (max - min) + min;
      hasil.push(formatAngka(random)); // Format sebagai number dengan 1 desimal
    }
  }
  return hasil;
};

export const generateHariLiburRandom = (petaniIds: string[]) => {
  const settings: {[key: string]: number[]} = {};
  
  petaniIds.forEach(petaniId => {
    // Generate 0-2 hari libur random
    const jumlahLibur = Math.floor(Math.random() * 3); // 0, 1, atau 2 hari
    const hariLibur = [];
    
    if (jumlahLibur > 0) {
      const availableDays = [1, 2, 3, 4, 5, 6, 7];
      for (let i = 0; i < jumlahLibur; i++) {
        const randomIndex = Math.floor(Math.random() * availableDays.length);
        hariLibur.push(availableDays[randomIndex]);
        availableDays.splice(randomIndex, 1);
      }
    }
    
    settings[petaniId] = hariLibur.sort();
  });
  
  return settings;
};

export const generatePanenData = (
  selectedPetani: string[],
  petaniList: Petani[],
  tanggalMulai: string,
  hariLiburSettings: {[key: string]: number[]},
  existingPanenData: PanenData[]
): PanenData[] => {
  const newPanenData: PanenData[] = [];
  const tanggalPengambilan = new Date(tanggalMulai);
  tanggalPengambilan.setDate(tanggalPengambilan.getDate() + 7);

  selectedPetani.forEach(petaniId => {
    const petani = petaniList.find(p => p.id === petaniId);
    if (!petani) return;

    const hariLibur = hariLiburSettings[petaniId] || [];

    // Generate untuk Gula Serbuk
    const hasilSerbuk = generateRandomPanen(petani.rataRataPanen, hariLibur);
    const panenSerbuk: PanenData = {
      id: generateUUID(),
      petaniId: petaniId,
      kodePetani: petani.kode,
      namaPetani: petani.nama,
      rataRataPanen: formatAngka(petani.rataRataPanen),
      tanggalMulai,
      hari1: hasilSerbuk[0],
      hari2: hasilSerbuk[1],
      hari3: hasilSerbuk[2],
      hari4: hasilSerbuk[3],
      hari5: hasilSerbuk[4],
      hari6: hasilSerbuk[5],
      hari7: hasilSerbuk[6],
      totalPanen: formatAngka(hasilSerbuk.reduce((sum, val) => sum + val, 0)),
      tanggalPengambilan: tanggalPengambilan.toISOString().split('T')[0],
      hariLibur,
      type: 'serbuk',
      weekNumber: 1
    };

    // Generate untuk Gula Cetak (+2 kg sebelum pengacakan)
    const hasilCetak = generateRandomPanen(petani.rataRataPanen + 2, hariLibur);
    const panenCetak: PanenData = {
      id: generateUUID(),
      petaniId: petaniId,
      kodePetani: petani.kode,
      namaPetani: petani.nama,
      rataRataPanen: formatAngka(petani.rataRataPanen),
      tanggalMulai,
      hari1: hasilCetak[0],
      hari2: hasilCetak[1],
      hari3: hasilCetak[2],
      hari4: hasilCetak[3],
      hari5: hasilCetak[4],
      hari6: hasilCetak[5],
      hari7: hasilCetak[6],
      totalPanen: formatAngka(hasilCetak.reduce((sum, val) => sum + val, 0)),
      tanggalPengambilan: tanggalPengambilan.toISOString().split('T')[0],
      hariLibur,
      type: 'cetak',
      weekNumber: 1
    };

    newPanenData.push(panenSerbuk, panenCetak);
  });

  return [...existingPanenData, ...newPanenData];
};

// Fungsi untuk generate minggu selanjutnya
export const generateNextWeekData = (
  selectedPetani: string[],
  petaniList: Petani[],
  existingPanenData: PanenData[],
  hariLiburSettings: {[key: string]: number[]},
  activeTab: 'serbuk' | 'cetak'
): PanenData[] => {
  // Cari minggu terakhir untuk tipe yang aktif
  const currentTypeData = existingPanenData.filter(p => p.type === activeTab);
  if (currentTypeData.length === 0) return existingPanenData;

  const maxWeek = Math.max(...currentTypeData.map(p => p.weekNumber || 1));
  const lastWeekData = currentTypeData.filter(p => (p.weekNumber || 1) === maxWeek);
  
  if (lastWeekData.length === 0) return existingPanenData;

  // Hitung tanggal mulai minggu baru
  const lastStartDate = new Date(lastWeekData[0].tanggalMulai);
  const newStartDate = new Date(lastStartDate);
  newStartDate.setDate(lastStartDate.getDate() + 7);
  const newStartDateString = newStartDate.toISOString().split('T')[0];

  // Hitung tanggal pengambilan minggu baru
  const newPickupDate = new Date(newStartDate);
  newPickupDate.setDate(newStartDate.getDate() + 7);
  const newPickupDateString = newPickupDate.toISOString().split('T')[0];

  const newWeekData: PanenData[] = [];

  selectedPetani.forEach(petaniId => {
    const petani = petaniList.find(p => p.id === petaniId);
    if (!petani) return;

    const hariLibur = hariLiburSettings[petaniId] || [];
    const baseRataRata = activeTab === 'cetak' ? petani.rataRataPanen + 2 : petani.rataRataPanen;
    const hasilPanen = generateRandomPanen(baseRataRata, hariLibur);

    const newPanenData: PanenData = {
      id: generateUUID(),
      petaniId: petaniId,
      kodePetani: petani.kode,
      namaPetani: petani.nama,
      rataRataPanen: formatAngka(petani.rataRataPanen),
      tanggalMulai: newStartDateString,
      hari1: hasilPanen[0],
      hari2: hasilPanen[1],
      hari3: hasilPanen[2],
      hari4: hasilPanen[3],
      hari5: hasilPanen[4],
      hari6: hasilPanen[5],
      hari7: hasilPanen[6],
      totalPanen: formatAngka(hasilPanen.reduce((sum, val) => sum + val, 0)),
      tanggalPengambilan: newPickupDateString,
      hariLibur,
      type: activeTab,
      weekNumber: maxWeek + 1
    };

    newWeekData.push(newPanenData);
  });

  return [...existingPanenData, ...newWeekData];
};