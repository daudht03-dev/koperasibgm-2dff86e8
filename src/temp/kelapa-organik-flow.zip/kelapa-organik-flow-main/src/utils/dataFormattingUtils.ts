
import { PanenData } from '../types';

// Fungsi untuk memformat angka dengan aturan decimal yang spesifik
export const formatNumber = (value: any): string => {
  if (typeof value === 'string') {
    value = value.replace(/kg/gi, '').trim(); // hapus satuan "kg" jika ada
  }
  
  const num = parseFloat(String(value || 0));
  if (isNaN(num)) return '0';

  const rounded = Math.round(num * 10) / 10;
  
  // Jika hasil bulat (misalnya 12.0), tampilkan tanpa koma
  if (Number.isInteger(rounded)) {
    return rounded.toString();
  }
  
  // Jika punya koma, tampilkan hanya 1 digit di belakang koma
  return rounded.toFixed(1);
};

// Fungsi untuk memformat angka agar konsisten sebagai number murni tanpa satuan
export const formatAngka = (val: number | string): number => {
  // Jika nilai adalah string, bersihkan dari satuan dan karakter non-numerik
  if (typeof val === 'string') {
    // Hapus satuan seperti 'kg', spasi, dan karakter non-numerik kecuali titik dan koma
    const cleanedVal = val.replace(/[^\d.,\-]/g, '').replace(',', '.');
    const parsed = parseFloat(cleanedVal);
    return isNaN(parsed) ? 0 : Number(parsed.toFixed(2));
  }
  
  // Jika sudah number, pastikan format konsisten
  const parsed = parseFloat(String(val || 0));
  return isNaN(parsed) ? 0 : Number(parsed.toFixed(2));
};

// Fungsi untuk memastikan nilai adalah number murni (bukan string)
export const ensureNumericValue = (value: any): number => {
  if (typeof value === 'number') return Number(value.toFixed(2));
  if (typeof value === 'string') {
    const cleaned = value.replace(/[^\d.,\-]/g, '').replace(',', '.');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : Number(parsed.toFixed(2));
  }
  return 0;
};

// Fungsi untuk mengkonversi data ke format 2D array untuk Google Sheets
export const convertDataTo2DArray = (panenData: PanenData[], isSalesNotes: boolean = false): any[][] => {
  if (panenData.length === 0) return [];

  // Group data by week
  const weekGroups: { [week: number]: PanenData[] } = {};
  panenData.forEach(panen => {
    const week = panen.weekNumber || 1;
    if (!weekGroups[week]) weekGroups[week] = [];
    weekGroups[week].push(panen);
  });

  const result: any[][] = [];
  const weeks = Object.keys(weekGroups).map(Number).sort();

  weeks.forEach((weekNumber, weekIndex) => {
    const weekData = weekGroups[weekNumber];
    if (weekData.length === 0) return;

    // Generate header tanggal untuk minggu ini
    const generateDateHeaders = (tanggalMulai: string) => {
      const headers = [];
      const startDate = new Date(tanggalMulai);
      
      for (let i = 0; i < 7; i++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + i);
        const formattedDate = currentDate.toLocaleDateString('id-ID', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
        headers.push(formattedDate);
      }
      return headers;
    };

    const dateHeaders = generateDateHeaders(weekData[0].tanggalMulai);
    
    // Header row untuk minggu ini
    const headers = [
      'Kode Petani',
      'Nama Petani',
      'Rata-rata',
      ...dateHeaders,
      'TOTAL',
      'TGL AMBIL'
    ];

    // Add empty line before each week (except first)
    if (weekIndex > 0) {
      result.push([]);
    }

    result.push(headers);

    // Data rows untuk minggu ini - FORMAT ANGKA DENGAN formatNumber
    const dataRows = weekData.map(panen => [
      panen.kodePetani,                                    // String
      panen.namaPetani,                                    // String
      formatNumber(panen.rataRataPanen),                  // Formatted number string
      formatNumber(panen.hari1),                          // Formatted number string
      formatNumber(panen.hari2),                          // Formatted number string
      formatNumber(panen.hari3),                          // Formatted number string
      formatNumber(panen.hari4),                          // Formatted number string
      formatNumber(panen.hari5),                          // Formatted number string
      formatNumber(panen.hari6),                          // Formatted number string
      formatNumber(panen.hari7),                          // Formatted number string
      formatNumber(panen.totalPanen),                     // Formatted number string
      new Date(panen.tanggalPengambilan).toLocaleDateString('id-ID', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
      })                                                   // String (formatted date)
    ]);

    result.push(...dataRows);
  });

  return result;
};

// Fungsi untuk export gabungan data panen dan catatan penjualan
export const convertCombinedDataTo2DArray = (
  panenData: PanenData[], 
  catatanPenjualanData: PanenData[]
): any[][] => {
  const combinedData = [];
  
  if (panenData.length > 0) {
    const panenArray = convertDataTo2DArray(panenData, false);
    
    // Add section header for Data Panen
    combinedData.push(['=== DATA PANEN ===']);
    combinedData.push([]); // Empty row
    combinedData.push(...panenArray);
    combinedData.push([]); // Empty row
  }
  
  if (catatanPenjualanData.length > 0) {
    const salesArray = convertDataTo2DArray(catatanPenjualanData, true);
    
    // Add section header for Catatan Penjualan
    combinedData.push(['=== CATATAN PENJUALAN ===']);
    combinedData.push([]); // Empty row
    combinedData.push(...salesArray);
  }
  
  return combinedData;
};
