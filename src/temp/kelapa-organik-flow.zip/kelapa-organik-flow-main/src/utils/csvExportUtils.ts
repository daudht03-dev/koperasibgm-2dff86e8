
import { PanenData } from '../types';
import { convertDataTo2DArray, convertCombinedDataTo2DArray } from './dataFormattingUtils';

// Fungsi untuk mengkonversi array 2D ke CSV - data sudah diformat dengan formatNumber
const convertArrayToCSV = (data2D: any[][]): string => {
  return data2D.map(row => 
    row.map(cell => {
      // Untuk string biasa, cek apakah perlu quotes
      if (typeof cell === 'string' && (cell.includes(',') || cell.includes('"') || cell.includes('\n'))) {
        return `"${cell.replace(/"/g, '""')}"`;
      }
      
      // Return cell as-is untuk nilai lainnya (sudah diformat dengan formatNumber)
      return cell;
    }).join(',')
  ).join('\n');
};

// Fungsi backup - export sebagai CSV
export const exportAsCSVBackup = (
  panenData: PanenData[], 
  activeTab: 'serbuk' | 'cetak', 
  isSalesNotes: boolean = false
) => {
  const data2D = convertDataTo2DArray(panenData, isSalesNotes);
  
  if (data2D.length === 0) {
    alert('Tidak ada data untuk diekspor');
    return;
  }

  // Convert 2D array to CSV (data sudah diformat dengan formatNumber)
  const csvContent = convertArrayToCSV(data2D);

  // Create and download CSV file
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  const filePrefix = isSalesNotes ? 'catatan-penjualan' : 'data-panen';
  const timestamp = new Date().toISOString().split('T')[0];
  link.setAttribute('href', url);
  link.setAttribute('download', `${filePrefix}-${activeTab}-${timestamp}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Fungsi backup - export gabungan sebagai CSV
export const exportCombinedAsCSVBackup = (
  panenData: PanenData[], 
  catatanPenjualanData: PanenData[],
  activeTab: 'serbuk' | 'cetak'
) => {
  const data2D = convertCombinedDataTo2DArray(panenData, catatanPenjualanData);
  
  if (data2D.length === 0) {
    alert('Tidak ada data untuk diekspor');
    return;
  }

  // Convert 2D array to CSV (data sudah diformat dengan formatNumber)
  const csvContent = convertArrayToCSV(data2D);

  // Create and download CSV file
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  const timestamp = new Date().toISOString().split('T')[0];
  link.setAttribute('href', url);
  link.setAttribute('download', `data-lengkap-${activeTab}-${timestamp}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
