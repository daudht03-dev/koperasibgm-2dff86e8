import { PanenData, Penjualan } from '../types';

// Utility function to format numbers for Excel (avoid date conversion)
export const formatNumberForExcel = (value: number): string => {
  if (value === 0) return '0';
  
  const rounded = Math.round(value * 10) / 10;
  
  // If it's a whole number, return without decimal
  if (Number.isInteger(rounded)) {
    return rounded.toString();
  }
  
  // Return with 1 decimal place
  return rounded.toFixed(1);
};

// Format date for Excel (dd/mm/yyyy format)
export const formatDateForExcel = (dateString: string): string => {
  const date = new Date(dateString);
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

// Convert Panen Data to CSV format for Excel
export const convertPanenDataToCSV = (panenData: PanenData[]): string => {
  if (panenData.length === 0) return '';

  // Group data by week
  const weekGroups: { [week: number]: PanenData[] } = {};
  panenData.forEach(panen => {
    const week = panen.weekNumber || 1;
    if (!weekGroups[week]) weekGroups[week] = [];
    weekGroups[week].push(panen);
  });

  const csvRows: string[] = [];
  const weeks = Object.keys(weekGroups).map(Number).sort();

  weeks.forEach((weekNumber, weekIndex) => {
    const weekData = weekGroups[weekNumber];
    if (weekData.length === 0) return;

    // Generate date headers for this week
    const generateDateHeaders = (tanggalMulai: string) => {
      const headers = [];
      const startDate = new Date(tanggalMulai);
      
      for (let i = 0; i < 7; i++) {
        const currentDate = new Date(startDate);
        currentDate.setDate(startDate.getDate() + i);
        headers.push(formatDateForExcel(currentDate.toISOString().split('T')[0]));
      }
      return headers;
    };

    const dateHeaders = generateDateHeaders(weekData[0].tanggalMulai);
    
    // Add empty line before each week (except first)
    if (weekIndex > 0) {
      csvRows.push('');
    }

    // Header row for this week
    const headers = [
      'Kode Petani',
      'Nama Petani', 
      'Rata-rata',
      ...dateHeaders,
      'TOTAL',
      'TGL AMBIL'
    ];
    csvRows.push(headers.join(','));

    // Data rows for this week - FORMAT AS NUMBERS FOR EXCEL
    weekData.forEach(panen => {
      const row = [
        panen.kodePetani,
        `"${panen.namaPetani}"`, // Quoted to handle commas in names
        formatNumberForExcel(panen.rataRataPanen),
        formatNumberForExcel(panen.hari1),
        formatNumberForExcel(panen.hari2),
        formatNumberForExcel(panen.hari3),
        formatNumberForExcel(panen.hari4),
        formatNumberForExcel(panen.hari5),
        formatNumberForExcel(panen.hari6),
        formatNumberForExcel(panen.hari7),
        formatNumberForExcel(panen.totalPanen),
        formatDateForExcel(panen.tanggalPengambilan)
      ];
      csvRows.push(row.join(','));
    });
  });

  return csvRows.join('\n');
};

// Convert Penjualan Data to CSV format for Excel
export const convertPenjualanDataToCSV = (penjualanData: Penjualan[]): string => {
  if (penjualanData.length === 0) return '';

  const headers = [
    'Tanggal Jual',
    'Kode Petani',
    'Nama Petani',
    'Nama Pengepul',
    'Jumlah Jual',
    'Harga Per Kg',
    'Total Harga',
    'Jenis',
    'Status Pembayaran'
  ];

  const csvRows = [headers.join(',')];

  penjualanData.forEach(penjualan => {
    const row = [
      formatDateForExcel(penjualan.tanggalJual),
      penjualan.kodePetani,
      `"${penjualan.namaPetani}"`,
      `"${penjualan.namaPengepul}"`,
      formatNumberForExcel(penjualan.jumlahJual),
      penjualan.hargaPerKg.toString(),
      penjualan.totalHarga.toString(),
      penjualan.type === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak',
      penjualan.statusPembayaran
    ];
    csvRows.push(row.join(','));
  });

  return csvRows.join('\n');
};

// Convert data to JSON format for Excel
export const convertPanenDataToJSON = (panenData: PanenData[]) => {
  return panenData.map(panen => ({
    kodePetani: panen.kodePetani,
    namaPetani: panen.namaPetani,
    rataRataPanen: parseFloat(formatNumberForExcel(panen.rataRataPanen)),
    hari1: parseFloat(formatNumberForExcel(panen.hari1)),
    hari2: parseFloat(formatNumberForExcel(panen.hari2)),
    hari3: parseFloat(formatNumberForExcel(panen.hari3)),
    hari4: parseFloat(formatNumberForExcel(panen.hari4)),
    hari5: parseFloat(formatNumberForExcel(panen.hari5)),
    hari6: parseFloat(formatNumberForExcel(panen.hari6)),
    hari7: parseFloat(formatNumberForExcel(panen.hari7)),
    totalPanen: parseFloat(formatNumberForExcel(panen.totalPanen)),
    tanggalMulai: formatDateForExcel(panen.tanggalMulai),
    tanggalPengambilan: formatDateForExcel(panen.tanggalPengambilan),
    jenis: panen.type === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak',
    mingguKe: panen.weekNumber || 1
  }));
};

export const convertPenjualanDataToJSON = (penjualanData: Penjualan[]) => {
  return penjualanData.map(penjualan => ({
    tanggalJual: formatDateForExcel(penjualan.tanggalJual),
    kodePetani: penjualan.kodePetani,
    namaPetani: penjualan.namaPetani,
    namaPengepul: penjualan.namaPengepul,
    jumlahJual: parseFloat(formatNumberForExcel(penjualan.jumlahJual)),
    hargaPerKg: penjualan.hargaPerKg,
    totalHarga: penjualan.totalHarga,
    jenis: penjualan.type === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak',
    statusPembayaran: penjualan.statusPembayaran
  }));
};

// Create downloadable blob URLs for endpoints
export const createDataEndpoint = (data: string, type: 'csv' | 'json'): string => {
  const mimeType = type === 'csv' ? 'text/csv' : 'application/json';
  const blob = new Blob([data], { type: `${mimeType};charset=utf-8` });
  return URL.createObjectURL(blob);
};

// Generate public endpoint URLs (simulated for demo)
export const generatePublicEndpoints = () => {
  const baseUrl = window.location.origin;
  
  return {
    panenCSV: `${baseUrl}/api/panen-data.csv`,
    panenJSON: `${baseUrl}/api/panen-data.json`,
    penjualanCSV: `${baseUrl}/api/penjualan-data.csv`,
    penjualanJSON: `${baseUrl}/api/penjualan-data.json`
  };
};