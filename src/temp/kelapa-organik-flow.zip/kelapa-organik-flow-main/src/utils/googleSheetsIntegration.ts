
import { PanenData } from '../types';
import { convertDataTo2DArray, convertCombinedDataTo2DArray } from './dataFormattingUtils';

// URL Google Apps Script Web App - UPDATE WITH YOUR ACTUAL URL
const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbw0AxW8m6gKaqZ9Z2ooEaOlmrKXdSy3voJ4esmZHWctAdvSJO_uZZt-XPHbU9qmRPgV/exec';

// Fungsi untuk memformat data dengan number formatting untuk Google Sheets
const prepareDataWithNumberFormat = (data2D: any[][]) => {
  return data2D.map((row, rowIndex) => {
    if (rowIndex === 0) {
      // Header row - return as is
      return row.map(cell => ({
        userEnteredValue: { stringValue: String(cell) },
        userEnteredFormat: {
          textFormat: { bold: true },
          backgroundColor: { red: 0.95, green: 0.95, blue: 0.95 }
        }
      }));
    }
    
    return row.map((cell, colIndex) => {
      // Check if this is a numeric column (columns 2-9 are typically numeric data)
      const isNumericColumn = colIndex >= 2 && colIndex <= 9;
      
      if (isNumericColumn && !isNaN(parseFloat(String(cell)))) {
        // Data sudah diformat dengan formatNumber sebagai string, parse sebagai number
        const numValue = parseFloat(String(cell));
        return {
          userEnteredValue: { numberValue: numValue },
          userEnteredFormat: {
            numberFormat: {
              type: 'NUMBER',
              pattern: '0.0#'  // Format with 1 decimal max, prevents date interpretation
            }
          }
        };
      }
      
      // For non-numeric cells (strings, dates, etc)
      return {
        userEnteredValue: { stringValue: String(cell) }
      };
    });
  });
};

// Fungsi untuk export ke Google Sheets melalui Apps Script
export const exportToGoogleSheets = async (
  panenData: PanenData[], 
  activeTab: 'serbuk' | 'cetak',
  isSalesNotes: boolean = false
): Promise<boolean> => {
  try {
    // Konversi data ke format 2D array dengan nilai numerik murni
    const data2D = convertDataTo2DArray(panenData, isSalesNotes);
    
    if (data2D.length === 0) {
      alert('Tidak ada data untuk diekspor');
      return false;
    }

    const sheetNamePrefix = isSalesNotes ? 'Catatan Penjualan' : 'Data Panen';
    
    // Prepare payload with number formatting
    const formattedData = prepareDataWithNumberFormat(data2D);
    
    const payload = {
      data: data2D, // Keep raw data for compatibility
      formattedData: formattedData, // Add formatted data with number types
      sheetName: `${sheetNamePrefix} ${activeTab === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'}`,
      timestamp: new Date().toISOString(),
      numberFormatting: true // Flag to indicate number formatting is needed
    };

    console.log('Sending data to Google Sheets:', payload);

    const response = await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        data: JSON.stringify(payload)
      }),
      mode: 'no-cors' // Required for Apps Script
    });

    // Since we're using no-cors mode, we assume success if no error is thrown
    return true;
    
  } catch (error) {
    console.error('Error exporting to Google Sheets:', error);
    return false;
  }
};

// Fungsi untuk export gabungan ke Google Sheets
export const exportCombinedToGoogleSheets = async (
  panenData: PanenData[], 
  catatanPenjualanData: PanenData[],
  activeTab: 'serbuk' | 'cetak'
): Promise<boolean> => {
  try {
    // Konversi data gabungan ke format 2D array dengan nilai numerik murni
    const data2D = convertCombinedDataTo2DArray(panenData, catatanPenjualanData);
    
    if (data2D.length === 0) {
      alert('Tidak ada data untuk diekspor');
      return false;
    }

    // Prepare payload with number formatting
    const formattedData = prepareDataWithNumberFormat(data2D);

    const payload = {
      data: data2D, // Keep raw data for compatibility
      formattedData: formattedData, // Add formatted data with number types
      sheetName: `Data Lengkap ${activeTab === 'serbuk' ? 'Gula Serbuk' : 'Gula Cetak'}`,
      timestamp: new Date().toISOString(),
      numberFormatting: true, // Flag to indicate number formatting is needed
      isCombined: true // Flag to indicate this is combined data
    };

    console.log('Sending combined data to Google Sheets:', payload);

    const response = await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        data: JSON.stringify(payload)
      }),
      mode: 'no-cors'
    });

    return true;
    
  } catch (error) {
    console.error('Error exporting combined data to Google Sheets:', error);
    return false;
  }
};
