import { PanenData } from '../types';

// Generate UUID v4
const generateUUID = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

// Fungsi untuk memformat angka agar konsisten dan terbaca sebagai number
const formatAngka = (val: number): number => {
  const parsed = parseFloat(val.toString());
  return Number(parsed.toFixed(1));
};

// Function to generate random combinations that sum to 7
const generateRandomCombination = (): number[] => {
  const combinations = [
    [1, 3, 3], [1, 2, 2, 2], [1, 1, 2, 3], [1, 1, 1, 2, 2],
    [1, 1, 1, 1, 3], [1, 1, 1, 1, 1, 2], [1, 1, 1, 1, 1, 1, 1],
    [2, 2, 3], [2, 3, 2], [3, 2, 2], [3, 3, 1], [3, 2, 1, 1],
    [3, 1, 3], [3, 1, 2, 1], [3, 1, 1, 2], [3, 1, 1, 1, 1],
    [2, 2, 2, 1], [2, 2, 1, 2], [2, 1, 2, 2], [2, 1, 1, 3],
    [2, 1, 1, 1, 2], [2, 1, 1, 1, 1, 1]
  ];
  
  return combinations[Math.floor(Math.random() * combinations.length)];
};

// Function to transform 7-day data into sales blocks
const transformToSalesBlocks = (dailyData: number[]): number[] => {
  const combination = generateRandomCombination();
  const result = [0, 0, 0, 0, 0, 0, 0];
  
  let currentIndex = 0;
  
  combination.forEach(blockSize => {
    let blockSum = 0;
    
    // Sum all days in the current block
    for (let i = 0; i < blockSize; i++) {
      blockSum += dailyData[currentIndex + i];
    }
    
    // Place the sum on the last day of the block - FORMAT SEBAGAI NUMBER MURNI
    const lastDayIndex = currentIndex + blockSize - 1;
    result[lastDayIndex] = formatAngka(blockSum);
    
    currentIndex += blockSize;
  });
  
  return result;
};

// Function to generate sales notes for specific week data
export const generateCatatanPenjualanForWeek = (panenData: PanenData[], weekNumber: number): PanenData[] => {
  const weekData = panenData.filter(p => (p.weekNumber || 1) === weekNumber);
  
  return weekData.map(panen => {
    const dailyData = [
      panen.hari1, panen.hari2, panen.hari3, panen.hari4,
      panen.hari5, panen.hari6, panen.hari7
    ];
    
    const salesBlocks = transformToSalesBlocks(dailyData);
    
    return {
      ...panen,
      id: generateUUID(),
      hari1: salesBlocks[0],
      hari2: salesBlocks[1],
      hari3: salesBlocks[2],
      hari4: salesBlocks[3],
      hari5: salesBlocks[4],
      hari6: salesBlocks[5],
      hari7: salesBlocks[6],
      totalPanen: formatAngka(salesBlocks.reduce((sum, val) => sum + val, 0)),
      weekNumber: weekNumber
    };
  });
};

// Function to generate sales notes for all weeks of active tab
export const generateCatatanPenjualan = (panenData: PanenData[], activeTab: 'serbuk' | 'cetak'): PanenData[] => {
  const currentTypeData = panenData.filter(p => p.type === activeTab);
  if (currentTypeData.length === 0) return [];

  // Get all unique weeks for this type
  const weeks = [...new Set(currentTypeData.map(p => p.weekNumber || 1))].sort();
  
  const allSalesData: PanenData[] = [];
  
  weeks.forEach(weekNumber => {
    const weekSalesData = generateCatatanPenjualanForWeek(currentTypeData, weekNumber);
    allSalesData.push(...weekSalesData);
  });
  
  return allSalesData;
};